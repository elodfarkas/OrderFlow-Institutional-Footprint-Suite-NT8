
#region Using declarations
using System;
using System.Collections.Generic;
using System.Globalization;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

using NinjaTrader.Data;
using NinjaTrader.Gui.Chart;
using NinjaTrader.NinjaScript;
using NinjaTrader.NinjaScript.BarsTypes;

using SharpDX;
using SharpDX.Direct2D1;
using SharpDX.DirectWrite;

using DxBrush = SharpDX.Direct2D1.Brush;
using DxSolidColorBrush = SharpDX.Direct2D1.SolidColorBrush;
using DxColor = SharpDX.Color4;
using DxRect = SharpDX.RectangleF;
using DxRoundedRect = SharpDX.Direct2D1.RoundedRectangle;
#endregion

public enum InstrumentProfile
{
    ES_Standard,
    NQ_HighVolatility,
    Custom
}

namespace NinjaTrader.NinjaScript.Indicators
{
    public class OrderFlowMinuteProV8FootprintSuite_UX_V5 : Indicator
    {
        // Hide NinjaTrader's automatic top-left indicator label/parameter string.
        // The custom legend can still be enabled separately with ShowLegend.
        public override string DisplayName
        {
            get { return string.Empty; }
        }

        private const int MaxHeatmapLevels = 32;
        private const int MaxZoneAlphaLevels = 10;

        private OrderFlowMinuteBarsTypeV8NoOutput ofBars;
        private SharpDX.DirectWrite.Factory dwFactory;
        private TextFormat fontTiny;
        private TextFormat fontSmall;
        private TextFormat fontNormal;
        private TextFormat fontBold;

        private RenderTheme theme = new RenderTheme();
        private RenderSettings rs = new RenderSettings();
        private CacheManager cache = new CacheManager();
        private SignalEngine signals;
        // Instrument-specific price grouping. 1 = native tick resolution; 4 = typical NQ 1-point grouping.
        private int currentTickMultiplier = 1;
        // Legacy DOM Bricks V6 state removed. Use DOMBrickStandaloneOrderFlowV1.cs as the separate DOM module.
        // V6 Core Refactor Phase 1 skeleton modules.
        // These are intentionally lightweight wrappers for controlled modularization.
        // They do not change runtime behavior yet; existing methods remain the execution path.
        private MetricsEngineCore metricsEngineCore;
        private ZoneEngineCore zoneEngineCore;
        private ProfileEngineCore profileEngineCore;
        private FootprintRendererCore footprintRendererCore;
        private ZoneRendererCore zoneRendererCore;
        private ProfileRendererCore profileRendererCore;
        private SignalRendererCore signalRendererCore;
        private BrushCacheCore brushCacheCore;
        private TextFormatCacheCore textFormatCacheCore;

        private DxSolidColorBrush[] bidHeatBrushes = new DxSolidColorBrush[MaxHeatmapLevels];
        private DxSolidColorBrush[] askHeatBrushes = new DxSolidColorBrush[MaxHeatmapLevels];
        private DxSolidColorBrush[] buyZoneBrushes = new DxSolidColorBrush[MaxZoneAlphaLevels];
        private DxSolidColorBrush[] sellZoneBrushes = new DxSolidColorBrush[MaxZoneAlphaLevels];

        private DxSolidColorBrush bidBrush;
        private DxSolidColorBrush askBrush;
        private DxSolidColorBrush bidStrongBrush;
        private DxSolidColorBrush askStrongBrush;
        private DxSolidColorBrush textBrush;
        private DxSolidColorBrush mutedTextBrush;
        private DxSolidColorBrush gridBrush;
        private DxSolidColorBrush panelBrush;
        private DxSolidColorBrush panelBorderBrush;
        private DxSolidColorBrush pocBrush;
        private DxSolidColorBrush valueAreaBrush;
        private DxSolidColorBrush bullBrush;
        private DxSolidColorBrush bearBrush;
        private DxSolidColorBrush goldBrush;
        private DxSolidColorBrush neutralBrush;
        private DxSolidColorBrush profileBgBrush;
        private DxSolidColorBrush lvnBrush;
        private DxSolidColorBrush hvnBrush;
        private DxSolidColorBrush bullReversalBrush;
        private DxSolidColorBrush bearReversalBrush;
        private DxSolidColorBrush reversalGlowBrush;
        private DxSolidColorBrush absorptionBrush;
        private DxSolidColorBrush trapBrush;
        private DxSolidColorBrush divergenceBrush;
        private DxSolidColorBrush pivotBrush;
        private DxSolidColorBrush warningBrush;
        private DxSolidColorBrush profileVolumeBrush;
        private DxSolidColorBrush profileValueAreaBrush;
        private DxSolidColorBrush unclassifiedBrush;
        private DxSolidColorBrush[] internalNeutralHeatBrushes = new DxSolidColorBrush[MaxHeatmapLevels];
        private DxSolidColorBrush[] internalBullHeatBrushes = new DxSolidColorBrush[MaxHeatmapLevels];
        private DxSolidColorBrush[] internalBearHeatBrushes = new DxSolidColorBrush[MaxHeatmapLevels];
        private DxSolidColorBrush internalPocCoreBrush;
        private DxSolidColorBrush persistentCoreBrush;
        private DxSolidColorBrush buyZoneLineBrush;
        private DxSolidColorBrush sellZoneLineBrush;

        #region Internal models

        private class RenderTheme
        {
            public DxColor Bid;
            public DxColor Ask;
            public DxColor BidStrong;
            public DxColor AskStrong;
            public DxColor Bull;
            public DxColor Bear;
            public DxColor Poc;
            public DxColor ValueArea;
            public DxColor Text;
            public DxColor MutedText;
            public DxColor Grid;
            public DxColor Panel;
            public DxColor PanelBorder;
            public DxColor Gold;
            public DxColor Neutral;
            public DxColor ProfileBg;
            public DxColor Hvn;
            public DxColor Lvn;
            public DxColor Absorption;
            public DxColor Trap;
            public DxColor Divergence;
            public DxColor Pivot;
        }

        private class RenderSettings
        {
            public int From;
            public int To;
            public int VisibleBars;
            public float BarWidth;
            public float CellWidth;
            public float CellHeight;
            public float PixelsPerTick;
            public int DensityMode;
            public bool CanDrawFootprint;
            public bool CanDrawHeatmap;
            public bool CanDrawPoc;
            public bool CanDrawImbalance;
            public bool CanDrawStack;
            public bool CanDrawNumbers;
            public bool CanDrawGrid;
            public bool CanDrawProfileNumbers;
            public bool CanDrawSignals;
            public bool CanDrawBarStats;
            public bool CanDrawInternalCore;
            public float ProfileWidth;
            public float DeltaRibbonY;
            public float SignalLaneY;
            public float CompactStatsY;
            public float FullStatsY;
        }

        private class FlowMetrics
        {
            public int BarIndex;
            public long TotalVolume;
            public long ClassifiedVolume;
            public long UnclassifiedVolume;
            public long Delta;
            public double DeltaPercent;
            public double PocPrice;
            public long PocVolume;
            public long MaxNodeVolume;
            public double MinPrice;
            public double MaxPrice;
            public int LevelCount;
            public int AskImbalanceCount;
            public int BidImbalanceCount;
            public int AskStackCount;
            public int BidStackCount;
            public BarSignal PrimarySignal;
            public ReversalScore Reversal;
            public bool Valid;
            public int FootprintLevelCount;
            public long SourceTotalVolume;
            public long SourceBuyVolume;
            public long SourceSellVolume;
            public long SourceUnclassifiedVolume;
            public long SourceMaxNodeVolume;
            public double SourcePocPrice;
            public int SourceTradeCount;
        }

        private class ReversalScore
        {
            public bool IsValid;
            public bool IsBullish;
            public double Price;
            public int Score;
            public int ExhaustionScore;
            public int AbsorptionScore;
            public int TrapScore;
            public int DeltaDivergenceScore;
            public int InitiativeStackScore;
            public int PocShiftScore;
            public int CloseLocationScore;
            public int WickRejectionScore;
            public int VolumeClimaxScore;
            public int FailedAuctionScore;
        }

        private class BarSignal
        {
            public bool HasSignal;
            public int Type;
            public int Direction;
            public int Score;
            public string ShortLabel;
            public double Price;
        }

        private class StackZone
        {
            public int Id;
            public double FromPrice;
            public double ToPrice;
            public bool IsBuy;
            public int StartBar;
            public int EndBar;
            public int CreatedBar;
            public int LastSeenBar;
            public int TouchCount;
            public bool IsPersistent;
            public bool IsVisible;
            public bool IsManuallyExpired;
            public int ReactionBar;
            public double ReactionPrice;
            public bool HasReaction;
            public bool ReactionConfirmed;
            public int ReactionType;       // 0 None, 1 Touch, 2 CloseIntoZone, 3 WickRejection, 4 CloseThrough, 5 Mitigated
            public int FirstTouchBar;
            public int LastTouchBar;
            public long Volume;
            public int StackCount;
            public double AvgRatio;
            public int Strength;
            public bool Invalidated;
            public bool Retested;
            public double MidPrice { get { return (FromPrice + ToPrice) * 0.5; } }
        }
        private class ProfileCache
        {
            public bool Valid;
            public int From;
            public int To;
            public int DataCount;
            public int ProfileMode;
            public int LookbackBars;
            public List<double> Prices = new List<double>();
            public List<long> Volumes = new List<long>();
            public HashSet<double> ValueArea = new HashSet<double>();
            public HashSet<double> HVN = new HashSet<double>();
            public HashSet<double> LVN = new HashSet<double>();
            public double PocPrice;
            public long PocVolume;
            public long MaxVolume;
            public double ValueAreaHigh;
            public double ValueAreaLow;
        }

        private class CacheManager
        {
            public Dictionary<int, FlowMetrics> Metrics = new Dictionary<int, FlowMetrics>();
            // Legacy rendered zone list kept for backward-safe access.
            public List<StackZone> Zones = new List<StackZone>();
            // Persistent storage: independent from visible chart range / zoom state.
            public List<StackZone> AllZones = new List<StackZone>();
            // Render subset selected from AllZones for current chart view.
            public List<StackZone> VisibleZones = new List<StackZone>();
            public ProfileCache Profile = new ProfileCache();
            public int LastZonesFrom = -1;
            public int LastZonesTo = -1;
            public int LastZonesDataCount = -1;
            public int LastProcessedZoneBar = -1;
            public int NextZoneId = 1;
        }

        private class SignalEngine
        {
            private OrderFlowMinuteProV8FootprintSuite_UX_V5 owner;
            public SignalEngine(OrderFlowMinuteProV8FootprintSuite_UX_V5 o) { owner = o; }

            public BarSignal DetectPrimarySignal(int barIndex, OrderFlowMinuteProOrderFlowDataV8NoOutput flow, FlowMetrics m)
            {
                BarSignal s = new BarSignal { HasSignal = false, Type = 0, Direction = 0, Score = 0, ShortLabel = "", Price = 0 };
                if (barIndex < 2 || flow == null || owner.ofBars == null)
                    return s;

                OrderFlowMinuteProOrderFlowDataV8NoOutput prev;
                if (!owner.ofBars.FlowDataByBar.TryGetValue(barIndex - 1, out prev) || prev == null)
                    return s;

                double high = owner.Bars.GetHigh(barIndex);
                double low = owner.Bars.GetLow(barIndex);
                double open = owner.Bars.GetOpen(barIndex);
                double close = owner.Bars.GetClose(barIndex);
                double prevHigh = owner.Bars.GetHigh(barIndex - 1);
                double prevLow = owner.Bars.GetLow(barIndex - 1);

                // Approximation based on tick-rule classified volume, not exchange bid/ask aggressor data.
                bool divBear = high > prevHigh && flow.Delta < prev.Delta;
                bool divBull = low < prevLow && flow.Delta > prev.Delta;
                bool absBear = high >= prevHigh && flow.BuyVolume >= flow.SellVolume && flow.Delta <= prev.Delta && close < high - owner.TickSize * 0.5;
                bool absBull = low <= prevLow && flow.SellVolume >= flow.BuyVolume && flow.Delta >= prev.Delta && close > low + owner.TickSize * 0.5;
                bool trapBear = flow.Delta > 0 && close < open;
                bool trapBull = flow.Delta < 0 && close > open;
                bool piv = (flow.Delta > 0 && prev.Delta < 0) || (flow.Delta < 0 && prev.Delta > 0);

                if (m != null && m.Reversal != null && m.Reversal.IsValid && m.Reversal.Score >= owner.MinReversalScore)
                    return new BarSignal { HasSignal = true, Type = 7, Direction = m.Reversal.IsBullish ? 1 : -1, Score = m.Reversal.Score, ShortLabel = "REV", Price = m.Reversal.Price };
                if (absBull || absBear)
                    return new BarSignal { HasSignal = true, Type = 2, Direction = absBull ? 1 : -1, Score = 60, ShortLabel = "ABS", Price = absBull ? low : high };
                if (trapBull || trapBear)
                    return new BarSignal { HasSignal = true, Type = 3, Direction = trapBull ? 1 : -1, Score = 50, ShortLabel = "TRP", Price = trapBull ? low : high };
                if (divBull || divBear)
                    return new BarSignal { HasSignal = true, Type = 1, Direction = divBull ? 1 : -1, Score = 45, ShortLabel = "DIV", Price = divBull ? low : high };
                if (piv)
                    return new BarSignal { HasSignal = true, Type = 4, Direction = flow.Delta > 0 ? 1 : -1, Score = 35, ShortLabel = "PIV", Price = close };

                return s;
            }

            public ReversalScore DetectReversalCluster(int barIndex, OrderFlowMinuteProOrderFlowDataV8NoOutput flow, FlowMetrics m)
            {
                ReversalScore result = new ReversalScore { IsValid = false, Score = 0 };
                if (barIndex < 2 || flow == null || flow.Footprint == null || flow.Footprint.Count == 0 || m == null || !m.Valid)
                    return result;

                OrderFlowMinuteProOrderFlowDataV8NoOutput prev;
                if (!owner.ofBars.FlowDataByBar.TryGetValue(barIndex - 1, out prev) || prev == null)
                    return result;

                double high = owner.Bars.GetHigh(barIndex);
                double low = owner.Bars.GetLow(barIndex);
                double open = owner.Bars.GetOpen(barIndex);
                double close = owner.Bars.GetClose(barIndex);
                double prevHigh = owner.Bars.GetHigh(barIndex - 1);
                double prevLow = owner.Bars.GetLow(barIndex - 1);
                double range = Math.Max(owner.TickSize, high - low);
                double closeLocation = (close - low) / range;
                double upperWick = high - Math.Max(open, close);
                double lowerWick = Math.Min(open, close) - low;

                double lowPrice = owner.GetNearestPriceFast(flow, low, m.MinPrice, m.MaxPrice);
                double highPrice = owner.GetNearestPriceFast(flow, high, m.MinPrice, m.MaxPrice);
                long lowVol = owner.GetVolumeAtPrice(flow, lowPrice);
                long highVol = owner.GetVolumeAtPrice(flow, highPrice);
                long prevVol = Math.Max(1, prev.BuyVolume + prev.SellVolume);

                int bull = 0;
                int bear = 0;

                // Approximation based on tick-rule classified volume, not exchange bid/ask aggressor data.
                int bullExh = lowVol > 0 && lowVol <= m.PocVolume * (owner.ExtremeExhaustionPercent / 100.0) ? 14 : 0;
                int bearExh = highVol > 0 && highVol <= m.PocVolume * (owner.ExtremeExhaustionPercent / 100.0) ? 14 : 0;
                int bullAbs = low <= prevLow && close > low + owner.TickSize * 0.5 && flow.SellVolume >= flow.BuyVolume && flow.Delta >= prev.Delta ? 18 : 0;
                int bearAbs = high >= prevHigh && close < high - owner.TickSize * 0.5 && flow.BuyVolume >= flow.SellVolume && flow.Delta <= prev.Delta ? 18 : 0;
                int bullTrap = flow.Delta < 0 && close > open ? 12 : 0;
                int bearTrap = flow.Delta > 0 && close < open ? 12 : 0;
                int bullDiv = low < prevLow && flow.Delta > prev.Delta ? 14 : 0;
                int bearDiv = high > prevHigh && flow.Delta < prev.Delta ? 14 : 0;
                int bullStack = owner.HasAskStackAwayFromLow(flow, lowPrice) ? 18 : 0;
                int bearStack = owner.HasBidStackAwayFromHigh(flow, highPrice) ? 18 : 0;
                int bullClose = closeLocation >= 0.62 ? 10 : 0;
                int bearClose = closeLocation <= 0.38 ? 10 : 0;
                int bullWick = lowerWick >= range * 0.28 ? 8 : 0;
                int bearWick = upperWick >= range * 0.28 ? 8 : 0;
                int climax = m.TotalVolume >= prevVol * (owner.VolumeClimaxMultiplier / 100.0) ? 6 : 0;
                int bullPocShift = barIndex >= 2 && m.PocPrice > owner.GetCachedMetrics(barIndex - 1).PocPrice ? 6 : 0;
                int bearPocShift = barIndex >= 2 && m.PocPrice < owner.GetCachedMetrics(barIndex - 1).PocPrice ? 6 : 0;
                int bullFailedAuction = low <= prevLow && close > prevLow ? 6 : 0;
                int bearFailedAuction = high >= prevHigh && close < prevHigh ? 6 : 0;

                bull = bullExh + bullAbs + bullTrap + bullDiv + bullStack + bullClose + bullWick + climax + bullPocShift + bullFailedAuction;
                bear = bearExh + bearAbs + bearTrap + bearDiv + bearStack + bearClose + bearWick + climax + bearPocShift + bearFailedAuction;

                if (bull >= owner.MinReversalScore && bull >= bear)
                {
                    result.IsValid = true;
                    result.IsBullish = true;
                    result.Price = lowPrice;
                    result.Score = Math.Min(100, bull);
                    result.ExhaustionScore = bullExh;
                    result.AbsorptionScore = bullAbs;
                    result.TrapScore = bullTrap;
                    result.DeltaDivergenceScore = bullDiv;
                    result.InitiativeStackScore = bullStack;
                    result.PocShiftScore = bullPocShift;
                    result.CloseLocationScore = bullClose;
                    result.WickRejectionScore = bullWick;
                    result.VolumeClimaxScore = climax;
                    result.FailedAuctionScore = bullFailedAuction;
                }
                else if (bear >= owner.MinReversalScore)
                {
                    result.IsValid = true;
                    result.IsBullish = false;
                    result.Price = highPrice;
                    result.Score = Math.Min(100, bear);
                    result.ExhaustionScore = bearExh;
                    result.AbsorptionScore = bearAbs;
                    result.TrapScore = bearTrap;
                    result.DeltaDivergenceScore = bearDiv;
                    result.InitiativeStackScore = bearStack;
                    result.PocShiftScore = bearPocShift;
                    result.CloseLocationScore = bearClose;
                    result.WickRejectionScore = bearWick;
                    result.VolumeClimaxScore = climax;
                    result.FailedAuctionScore = bearFailedAuction;
                }

                return result;
            }
        }

        #endregion

        #region V6 Core Refactor Phase 1 skeleton modules

        private abstract class ModuleBase
        {
            protected readonly OrderFlowMinuteProV8FootprintSuite_UX_V5 Owner;

            protected ModuleBase(OrderFlowMinuteProV8FootprintSuite_UX_V5 owner)
            {
                Owner = owner;
            }

            public virtual void OnRenderTargetChanged()
            {
            }

            public virtual void Dispose()
            {
            }
        }

        private sealed class MetricsEngineCore : ModuleBase
        {
            public MetricsEngineCore(OrderFlowMinuteProV8FootprintSuite_UX_V5 owner) : base(owner)
            {
            }

            // Phase 1 responsibility boundary:
            // Future home of GetCachedMetrics, BuildMetrics, CountStacks and footprint-derived metrics.
        }

        private sealed class ZoneEngineCore : ModuleBase
        {
            public ZoneEngineCore(OrderFlowMinuteProV8FootprintSuite_UX_V5 owner) : base(owner)
            {
            }

            // Phase 1 responsibility boundary:
            // Future home of persistent stack zone storage, source-to-reaction state,
            // reaction detection, zone merging and lifecycle scoring.
        }

        private sealed class ProfileEngineCore : ModuleBase
        {
            public ProfileEngineCore(OrderFlowMinuteProV8FootprintSuite_UX_V5 owner) : base(owner)
            {
            }

            // Phase 1 responsibility boundary:
            // Future home of profile rebuild/cache, value area and HVN/LVN calculations.
        }

        private sealed class FootprintRendererCore : ModuleBase
        {
            public FootprintRendererCore(OrderFlowMinuteProV8FootprintSuite_UX_V5 owner) : base(owner)
            {
            }

            // Phase 1 responsibility boundary:
            // Future home of footprint heatmap/core/cell rendering.
        }

        private sealed class ZoneRendererCore : ModuleBase
        {
            public ZoneRendererCore(OrderFlowMinuteProV8FootprintSuite_UX_V5 owner) : base(owner)
            {
            }

            // Phase 1 responsibility boundary:
            // Future home of stack zone and reaction marker SharpDX rendering.
        }

        private sealed class ProfileRendererCore : ModuleBase
        {
            public ProfileRendererCore(OrderFlowMinuteProV8FootprintSuite_UX_V5 owner) : base(owner)
            {
            }

            // Phase 1 responsibility boundary:
            // Future home of compact profile and VAH/VAL rendering.
        }

        private sealed class SignalRendererCore : ModuleBase
        {
            public SignalRendererCore(OrderFlowMinuteProV8FootprintSuite_UX_V5 owner) : base(owner)
            {
            }

            // Phase 1 responsibility boundary:
            // Future home of production/research signal rendering and visual gating.
        }

        private sealed class BrushCacheCore : ModuleBase
        {
            public BrushCacheCore(OrderFlowMinuteProV8FootprintSuite_UX_V5 owner) : base(owner)
            {
            }

            // Phase 1 responsibility boundary:
            // Future home of ThemeBrushes, HeatmapBrushes, ZoneBrushes,
            // SignalBrushes and ProfileBrushes. No brushes are created here yet.
        }

        private sealed class TextFormatCacheCore : ModuleBase
        {
            public TextFormatCacheCore(OrderFlowMinuteProV8FootprintSuite_UX_V5 owner) : base(owner)
            {
            }

            // Phase 1 responsibility boundary:
            // Future home of TextFormat lifecycle and text rendering guards.
        }

        private void InitializeCoreModules()
        {
            metricsEngineCore = new MetricsEngineCore(this);
            zoneEngineCore = new ZoneEngineCore(this);
            profileEngineCore = new ProfileEngineCore(this);
            footprintRendererCore = new FootprintRendererCore(this);
            zoneRendererCore = new ZoneRendererCore(this);
            profileRendererCore = new ProfileRendererCore(this);
            signalRendererCore = new SignalRendererCore(this);
            brushCacheCore = new BrushCacheCore(this);
            textFormatCacheCore = new TextFormatCacheCore(this);
        }

        private void DisposeCoreModules()
        {
            if (textFormatCacheCore != null) textFormatCacheCore.Dispose();
            if (brushCacheCore != null) brushCacheCore.Dispose();
            if (signalRendererCore != null) signalRendererCore.Dispose();
            if (profileRendererCore != null) profileRendererCore.Dispose();
            if (zoneRendererCore != null) zoneRendererCore.Dispose();
            if (footprintRendererCore != null) footprintRendererCore.Dispose();
            if (profileEngineCore != null) profileEngineCore.Dispose();
            if (zoneEngineCore != null) zoneEngineCore.Dispose();
            if (metricsEngineCore != null) metricsEngineCore.Dispose();

            textFormatCacheCore = null;
            brushCacheCore = null;
            signalRendererCore = null;
            profileRendererCore = null;
            zoneRendererCore = null;
            footprintRendererCore = null;
            profileEngineCore = null;
            zoneEngineCore = null;
            metricsEngineCore = null;
        }

        #endregion

        #region Properties

        [NinjaScriptProperty]
        [Display(
            Name = "Instrument Profile",
            Description = "ES = native 1-tick resolution. NQ = groups 4 ticks together to compress sparse high-volatility footprints. Custom uses Custom price group ticks.",
            GroupName = "00. Presets / Global UX",
            Order = 0)]
        public InstrumentProfile AssetProfile { get; set; }

        [NinjaScriptProperty]
        [Range(1, 16)]
        [Display(
            Name = "Custom price group ticks",
            Description = "Used only when Instrument Profile = Custom. 1 = native tick resolution.",
            GroupName = "00. Presets / Global UX",
            Order = 1)]
        public int CustomPriceGroupTicks { get; set; }
        // Legacy OrderFlow DOM Bricks V6 properties removed. Use DOMBrickStandaloneOrderFlowV1.cs.
[NinjaScriptProperty]
        [Range(0, 1)]
        [Display(
            Name = "Visual preset",
            Description = "0 = Black background optimized, 1 = White background optimized.",
            GroupName = "00. Presets / Global UX",
            Order = 2)]
        public int UxPresetMode { get; set; }

        [NinjaScriptProperty]
        [Range(0, 1)]
        [Display(Name = "Background theme", Description = "0 = Black/Dark background optimized, 1 = White/Light background optimized.", GroupName = "01. Theme / Colors", Order = 1)]
        public int ThemeMode { get; set; }

        [NinjaScriptProperty]
        [Range(20, 95)]
        [Display(Name = "Panel opacity", Description = "Opacity of legend/profile background panels.", GroupName = "01. Theme / Colors", Order = 2)]
        public int PanelOpacity { get; set; }

        [NinjaScriptProperty]
        [Range(0, 60)]
        [Display(Name = "Grid opacity", Description = "Lower = less visual noise.", GroupName = "01. Theme / Colors", Order = 3)]
        public int GridOpacity { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Enable soft glow", Description = "Adds subtle glow for strong signals only.", GroupName = "01. Theme / Colors", Order = 4)]
        public bool EnableSoftGlow { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Auto density mode", Description = "Automatically adapts footprint detail based on zoom, price scale and visible density.", GroupName = "02. Adaptive Density", Order = 1)]
        public bool AutoDensityMode { get; set; }

        [NinjaScriptProperty]
        [Range(0, 5)]
        [Display(Name = "Force density mode", Description = "0 Hidden, 1 HeatmapOnly, 2 Heatmap+POC, 3 AddImbalance, 4 AddNumbers, 5 FullDetail. Used when AutoDensityMode=false.", GroupName = "02. Adaptive Density", Order = 2)]
        public int ForceDensityMode { get; set; }

        [NinjaScriptProperty]
        [Range(10, 120)]
        [Display(Name = "Hide numbers below bar width", Description = "Numbers are expensive and only drawn when enough room exists.", GroupName = "02. Adaptive Density", Order = 3)]
        public int HideNumbersBelowBarWidth { get; set; }

        [NinjaScriptProperty]
        [Range(10, 120)]
        [Display(Name = "Hide grid below bar width", Description = "Grid is hidden earlier to reduce clutter.", GroupName = "02. Adaptive Density", Order = 4)]
        public int HideGridBelowBarWidth { get; set; }

        [NinjaScriptProperty]
        [Range(10, 120)]
        [Display(Name = "Hide profile numbers below bar width", Description = "Profile labels are hidden on compressed charts.", GroupName = "02. Adaptive Density", Order = 5)]
        public int HideProfileNumbersBelowBarWidth { get; set; }

        [NinjaScriptProperty]
        [Range(1, 20)]
        [Display(Name = "Min pixels per tick for numbers", Description = "Prevents unreadable overlapping footprint numbers.", GroupName = "02. Adaptive Density", Order = 6)]
        public int MinPixelsPerTickForNumbers { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Show footprint", Description = "Main footprint heatmap/cell display.", GroupName = "03. Footprint Cells", Order = 1)]
        public bool ShowFootprintVolume { get; set; }

        [NinjaScriptProperty]
        [Range(8, 32)]
        [Display(Name = "Heatmap levels", Description = "More levels = smoother gradient, still fully brush-cached.", GroupName = "03. Footprint Cells", Order = 2)]
        public int HeatmapLevels { get; set; }

        [NinjaScriptProperty]
        [Range(5, 40)]
        [Display(Name = "Heatmap minimum opacity", Description = "Low-volume nodes fade into the background.", GroupName = "03. Footprint Cells", Order = 3)]
        public int HeatmapMinOpacity { get; set; }

        [NinjaScriptProperty]
        [Range(50, 100)]
        [Display(Name = "Heatmap maximum opacity", Description = "High-volume node intensity.", GroupName = "03. Footprint Cells", Order = 4)]
        public int HeatmapMaxOpacity { get; set; }

        [NinjaScriptProperty]
        [Range(50, 250)]
        [Display(Name = "Heatmap gamma x100", Description = "100 = linear. Higher emphasizes only the largest nodes; lower reveals smaller nodes.", GroupName = "03. Footprint Cells", Order = 5)]
        public int HeatmapGammaX100 { get; set; }

        [NinjaScriptProperty]
        [Range(0, 3)]
        [Display(Name = "Cell style mode", Description = "0 Flat, 1 Rounded, 2 Capsule, 3 MinimalBars.", GroupName = "03. Footprint Cells", Order = 6)]
        public int CellStyleMode { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Enable rounded cells", Description = "Rounded/capsule cell rendering. Flat is fastest.", GroupName = "03. Footprint Cells", Order = 7)]
        public bool EnableRoundedCells { get; set; }

        [NinjaScriptProperty]
        [Range(0, 6)]
        [Display(Name = "Cell corner radius", Description = "Rounded cell corner radius.", GroupName = "03. Footprint Cells", Order = 8)]
        public int CellCornerRadius { get; set; }

        [NinjaScriptProperty]
        [Range(0, 3)]
        [Display(Name = "Heatmap scale mode", Description = "0 PerBar, 1 VisibleRange, 2 Session approximation, 3 Hybrid.", GroupName = "03. Footprint Cells", Order = 9)]
        public int HeatmapScaleMode { get; set; }


        [NinjaScriptProperty]
        [Display(Name = "Show internal heatmap core", Description = "Draws a bar-internal volume/pressure heat spine around the bar center.", GroupName = "03B. Internal Heatmap Core", Order = 1)]
        public bool ShowInternalHeatmapCore { get; set; }

        [NinjaScriptProperty]
        [Range(0, 5)]
        [Display(Name = "Internal heatmap core mode", Description = "0 Off, 1 Total Volume, 2 Delta Weighted, 3 POC/HVN, 4 Persistent Node, 5 Liquidity Pressure.", GroupName = "03B. Internal Heatmap Core", Order = 2)]
        public int InternalHeatmapCoreMode { get; set; }

        [NinjaScriptProperty]
        [Range(5, 80)]
        [Display(Name = "Internal core width percent", Description = "Width of the internal heatmap core relative to bar width.", GroupName = "03B. Internal Heatmap Core", Order = 3)]
        public int InternalHeatmapCoreWidthPercent { get; set; }

        [NinjaScriptProperty]
        [Range(5, 100)]
        [Display(Name = "Internal core max width", Description = "Maximum pixel width of the internal heatmap core.", GroupName = "03B. Internal Heatmap Core", Order = 4)]
        public int InternalHeatmapCoreMaxWidth { get; set; }

        [NinjaScriptProperty]
        [Range(1, 100)]
        [Display(Name = "Internal core opacity", Description = "Base opacity for internal heatmap core.", GroupName = "03B. Internal Heatmap Core", Order = 5)]
        public int InternalHeatmapCoreOpacity { get; set; }

        [NinjaScriptProperty]
        [Range(30, 95)]
        [Display(Name = "Internal HVN percent", Description = "Node volume percent of MaxNodeVolume required for HVN core display.", GroupName = "03B. Internal Heatmap Core", Order = 6)]
        public int InternalHeatmapHvnPercent { get; set; }

        [NinjaScriptProperty]
        [Range(1, 20)]
        [Display(Name = "Persistent node lookback", Description = "Bars used to detect repeated high-volume nodes.", GroupName = "03B. Internal Heatmap Core", Order = 7)]
        public int PersistentNodeLookbackBars { get; set; }

        [NinjaScriptProperty]
        [Range(0, 6)]
        [Display(Name = "Persistent node merge ticks", Description = "Price tolerance for repeated nodes.", GroupName = "03B. Internal Heatmap Core", Order = 8)]
        public int PersistentNodeMergeTicks { get; set; }

        [NinjaScriptProperty]
        [Range(1, 10)]
        [Display(Name = "Persistent node min hits", Description = "Minimum matching previous bars required for persistent-node classification.", GroupName = "03B. Internal Heatmap Core", Order = 9)]
        public int PersistentNodeMinHits { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Hide internal heatmap noise", Description = "Filters weak internal heatmap nodes.", GroupName = "03B. Internal Heatmap Core", Order = 10)]
        public bool HideInternalHeatmapNoise { get; set; }

        [NinjaScriptProperty]
        [Range(1, 100)]
        [Display(Name = "Internal heat noise threshold percent", Description = "Minimum percent of scale max required when noise filter is enabled.", GroupName = "03B. Internal Heatmap Core", Order = 11)]
        public int InternalHeatNoiseThresholdPercent { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Show footprint numbers", Description = "Draws bid/ask volume text only when density allows.", GroupName = "04. Footprint Numbers", Order = 1)]
        public bool ShowFootprintNumbers { get; set; }

        [NinjaScriptProperty]
        [Range(8, 18)]
        [Display(Name = "Font size", Description = "Base Segoe UI font size.", GroupName = "04. Footprint Numbers", Order = 2)]
        public int FontSize { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Show footprint grid", Description = "Thin cell borders. Hidden automatically on dense charts.", GroupName = "04. Footprint Numbers", Order = 3)]
        public bool ShowFootprintGrid { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Show footprint POC", Description = "Highlights the bar-level POC node.", GroupName = "04. Footprint Numbers", Order = 4)]
        public bool ShowFootprintPoc { get; set; }

        [NinjaScriptProperty]
        [Range(1, 8)]
        [Display(Name = "POC marker size", Description = "Size of POC marker/rail.", GroupName = "04. Footprint Numbers", Order = 5)]
        public int PocMarkerSize { get; set; }

        [NinjaScriptProperty]
        [Range(100, 1000)]
        [Display(Name = "Imbalance ratio percent", Description = "Higher = fewer but stronger imbalances.", GroupName = "05. Imbalance", Order = 1)]
        public int ImbalanceRatioPercent { get; set; }

        [NinjaScriptProperty]
        [Range(0, 1000000)]
        [Display(Name = "Min imbalance volume", Description = "Minimum side volume required for imbalance evaluation.", GroupName = "05. Imbalance", Order = 2)]
        public long MinImbalanceVolume { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Show zero-compare imbalance", Description = "Allows imbalance when opposite side is zero. Approximation based on tick-rule classified volume.", GroupName = "05. Imbalance", Order = 3)]
        public bool ShowZeroCompareImbalance { get; set; }

        [NinjaScriptProperty]
        [Range(0, 1000000)]
        [Display(Name = "Zero compare min volume", Description = "Minimum volume when opposite side is zero.", GroupName = "05. Imbalance", Order = 4)]
        public long ZeroCompareMinVolume { get; set; }

        [NinjaScriptProperty]
        [Range(0, 3)]
        [Display(Name = "Imbalance marker style", Description = "0 Border, 1 SideRail, 2 CornerDot, 3 Chevron.", GroupName = "05. Imbalance", Order = 5)]
        public int ImbalanceMarkerStyle { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Show imbalance markers", Description = "Shows/hides the small imbalance markers directly beside footprint cells. Default is false to remove vertical side rails next to bars.", GroupName = "05. Imbalance", Order = 6)]
        public bool ShowImbalanceMarkers { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Show stacks", Description = "Shows stacked imbalance markers.", GroupName = "06. Stacked Imbalance", Order = 1)]
        public bool ShowStacks { get; set; }

        [NinjaScriptProperty]
        [Range(2, 10)]
        [Display(Name = "Stack min count", Description = "Consecutive imbalance count required.", GroupName = "06. Stacked Imbalance", Order = 2)]
        public int StackMinCount { get; set; }

        [NinjaScriptProperty]
        [Range(0, 1000000)]
        [Display(Name = "Stack min volume", Description = "Minimum cell volume for stack evaluation.", GroupName = "06. Stacked Imbalance", Order = 3)]
        public long StackMinVolume { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Show stack zones", Description = "Projects stacked imbalance areas as supply/demand zones.", GroupName = "07. Stack Zones", Order = 1)]
        public bool ShowStackZones { get; set; }

        [NinjaScriptProperty]
        [Range(1, 50)]
        [Display(Name = "Max visible zones", Description = "Limits zone clutter.", GroupName = "07. Stack Zones", Order = 2)]
        public int MaxVisibleStackZones { get; set; }

        [NinjaScriptProperty]
        [Range(1, 5000)]
        [Display(Name = "Zone lookback bars", Description = "Bars scanned for active zones.", GroupName = "07. Stack Zones", Order = 3)]
        public int StackZoneLookbackBars { get; set; }

        [NinjaScriptProperty]
        [Range(1, 5000)]
        [Display(Name = "Zone projection bars", Description = "Forward projection length.", GroupName = "07. Stack Zones", Order = 4)]
        public int StackZoneProjectionBars { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Merge nearby zones", Description = "Merges overlapping or nearby stack zones.", GroupName = "07. Stack Zones", Order = 5)]
        public bool MergeNearbyZones { get; set; }

        [NinjaScriptProperty]
        [Range(0, 10)]
        [Display(Name = "Zone merge ticks", Description = "Zones this close are merged.", GroupName = "07. Stack Zones", Order = 6)]
        public int ZoneMergeTicks { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Enable zone decay", Description = "Older zones fade visually.", GroupName = "07. Stack Zones", Order = 7)]
        public bool EnableZoneDecay { get; set; }

        [NinjaScriptProperty]
        [Range(10, 500)]
        [Display(Name = "Zone decay bars", Description = "Larger = slower fading.", GroupName = "07. Stack Zones", Order = 8)]
        public int ZoneDecayBars { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Invalidate zones on close through", Description = "Invalidates zones when price closes through them.", GroupName = "07. Stack Zones", Order = 9)]
        public bool InvalidateZonesOnCloseThrough { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Show zone retests", Description = "Marks when price retests a zone.", GroupName = "07. Stack Zones", Order = 10)]
        public bool ShowZoneRetests { get; set; }

        [NinjaScriptProperty]
        [Range(0, 2)]
        [Display(Name = "Zone strength mode", Description = "0 Simple, 1 Volume weighted, 2 Recency weighted.", GroupName = "07. Stack Zones", Order = 11)]
        public int ZoneStrengthMode { get; set; }

        [NinjaScriptProperty]
        [Range(0, 1000000)]
        [Display(Name = "Min zone strength", Description = "Filters weak zones.", GroupName = "07. Stack Zones", Order = 12)]
        public int MinZoneStrength { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Keep stack zones persistent", Description = "Keeps stack imbalance horizontal zones visible across zoom/scroll changes.", GroupName = "07. Stack Zones", Order = 13)]
        public bool KeepStackZonesPersistent { get; set; }

        [NinjaScriptProperty]
        [Range(50, 5000)]
        [Display(Name = "Persistent zone max bars", Description = "Maximum historical bars kept for persistent stack zones.", GroupName = "07. Stack Zones", Order = 14)]
        public int PersistentZoneMaxBars { get; set; }

        [NinjaScriptProperty]
        [Range(10, 500)]
        [Display(Name = "Max stored stack zones", Description = "Maximum number of persistent stack zones stored internally.", GroupName = "07. Stack Zones", Order = 15)]
        public int MaxStoredStackZones { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Draw stack zones across visible chart", Description = "Legacy compatibility switch. Source-to-reaction mode takes priority when StackZoneLineSpanMode = 1.", GroupName = "07. Stack Zones", Order = 16)]
        public bool DrawStackZonesAcrossVisibleChart { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Show stack zone center line", Description = "Draws a stable horizontal center line for each stack zone.", GroupName = "07. Stack Zones", Order = 17)]
        public bool ShowStackZoneCenterLine { get; set; }

        [NinjaScriptProperty]
        [Range(1, 5)]
        [Display(Name = "Stack zone line width", Description = "Width of persistent stack imbalance horizontal line.", GroupName = "07. Stack Zones", Order = 18)]
        public int StackZoneLineWidth { get; set; }

        [NinjaScriptProperty]
        [Range(5, 100)]
        [Display(Name = "Stack zone line opacity", Description = "Opacity of persistent stack imbalance horizontal line.", GroupName = "07. Stack Zones", Order = 19)]
        public int StackZoneLineOpacity { get; set; }

        [NinjaScriptProperty]
        [Range(0, 20)]
        [Display(Name = "Zone invalidation ticks", Description = "Tolerance ticks for directional zone invalidation.", GroupName = "07. Stack Zones", Order = 20)]
        public int ZoneInvalidationTicks { get; set; }

        [NinjaScriptProperty]
        [Range(0, 2)]
        [Display(Name = "Stack zone line span mode", Description = "0 SourceToProjection, 1 SourceToFirstReaction, 2 SourceToCurrentVisibleRight.", GroupName = "07. Stack Zones", Order = 21)]
        public int StackZoneLineSpanMode { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Stop stack zone at first reaction", Description = "Ends the horizontal stack imbalance line at the first price reaction/retest.", GroupName = "07. Stack Zones", Order = 22)]
        public bool StopStackZoneAtFirstReaction { get; set; }

        [NinjaScriptProperty]
        [Range(0, 10)]
        [Display(Name = "Reaction tolerance ticks", Description = "Price tolerance for detecting first reaction to stack zone.", GroupName = "07. Stack Zones", Order = 23)]
        public int StackZoneReactionToleranceTicks { get; set; }

        [NinjaScriptProperty]
        [Range(0, 3)]
        [Display(Name = "Reaction detection mode", Description = "0 Touch, 1 CloseIntoZone, 2 WickReject, 3 TouchOrReject.", GroupName = "07. Stack Zones", Order = 24)]
        public int StackZoneReactionDetectionMode { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Show reaction marker", Description = "Draws a small marker where price first reacted to the stack zone.", GroupName = "07. Stack Zones", Order = 25)]
        public bool ShowStackZoneReactionMarker { get; set; }

        [NinjaScriptProperty]
        [Range(1, 8)]
        [Display(Name = "Reaction marker size", Description = "Marker size for first reaction point.", GroupName = "07. Stack Zones", Order = 26)]
        public int StackZoneReactionMarkerSize { get; set; }


        [NinjaScriptProperty]
        [Display(Name = "Show reversal clusters", Description = "Shows high-probability reversal clusters. Tick-rule approximation, not true exchange aggressor data.", GroupName = "08. Reversal Engine", Order = 1)]
        public bool ShowReversalClusters { get; set; }

        [NinjaScriptProperty]
        [Range(0, 1)]
        [Display(Name = "Reversal score mode", Description = "0 Simple, 1 Weighted scoring engine.", GroupName = "08. Reversal Engine", Order = 2)]
        public int ReversalScoreMode { get; set; }

        [NinjaScriptProperty]
        [Range(10, 100)]
        [Display(Name = "Min reversal score", Description = "Higher = fewer but stronger reversal markers.", GroupName = "08. Reversal Engine", Order = 3)]
        public int MinReversalScore { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Show weak reversals", Description = "If false, weak signals remain hidden.", GroupName = "08. Reversal Engine", Order = 4)]
        public bool ShowWeakReversals { get; set; }

        [NinjaScriptProperty]
        [Range(10, 100)]
        [Display(Name = "Strong reversal threshold", Description = "Rail + triangle marker threshold.", GroupName = "08. Reversal Engine", Order = 5)]
        public int StrongReversalThreshold { get; set; }

        [NinjaScriptProperty]
        [Range(10, 100)]
        [Display(Name = "Institutional reversal threshold", Description = "Gold dot/glow threshold.", GroupName = "08. Reversal Engine", Order = 6)]
        public int InstitutionalReversalThreshold { get; set; }

        [NinjaScriptProperty]
        [Range(0, 3)]
        [Display(Name = "Reversal marker style", Description = "0 Rail, 1 Rail+Triangle, 2 Capsule, 3 MinimalDot.", GroupName = "08. Reversal Engine", Order = 7)]
        public int ReversalMarkerStyle { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Use close location", Description = "Adds close-location scoring component.", GroupName = "08. Reversal Engine", Order = 8)]
        public bool ReversalUseCloseLocation { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Use wick rejection", Description = "Adds wick-rejection scoring component.", GroupName = "08. Reversal Engine", Order = 9)]
        public bool ReversalUseWickRejection { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Use delta divergence", Description = "Adds tick-rule delta divergence component.", GroupName = "08. Reversal Engine", Order = 10)]
        public bool ReversalUseDeltaDivergence { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Use initiative stack", Description = "Adds stacked imbalance away from extreme component.", GroupName = "08. Reversal Engine", Order = 11)]
        public bool ReversalUseInitiativeStack { get; set; }

        [NinjaScriptProperty]
        [Range(10, 90)]
        [Display(Name = "Extreme exhaustion percent", Description = "Extreme volume below this percent of POC volume counts as exhaustion. Lower = stricter.", GroupName = "08. Reversal Engine", Order = 12)]
        public int ExtremeExhaustionPercent { get; set; }

        [NinjaScriptProperty]
        [Range(1, 6)]
        [Display(Name = "Reversal extreme ticks", Description = "Distance from high/low used for initiation stack scan.", GroupName = "08. Reversal Engine", Order = 13)]
        public int ReversalExtremeTicks { get; set; }

        [NinjaScriptProperty]
        [Range(110, 500)]
        [Display(Name = "Volume climax multiplier %", Description = "Current volume must exceed previous volume by this percentage.", GroupName = "08. Reversal Engine", Order = 14)]
        public int VolumeClimaxMultiplier { get; set; }

        [NinjaScriptProperty]
        [Range(1, 12)]
        [Display(Name = "Signal marker size", Description = "Base size for signal geometry.", GroupName = "09. Signals", Order = 1)]
        public int SignalMarkerSize { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Show signal stripes", Description = "Vertical signal stripes for peripheral visibility.", GroupName = "09. Signals", Order = 2)]
        public bool ShowSignalStripes { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Show signal lane", Description = "Compact lane at chart bottom for signal priority.", GroupName = "09. Signals", Order = 3)]
        public bool ShowSignalLane { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Show price-level signal marker", Description = "Draws signal marker at the exact rejection price when available.", GroupName = "09. Signals", Order = 4)]
        public bool ShowPriceLevelSignals { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Show profile", Description = "Right/left/floating volume profile.", GroupName = "10. Volume Profile", Order = 1)]
        public bool ShowProfile { get; set; }

        [NinjaScriptProperty]
        [Range(0, 3)]
        [Display(Name = "Profile mode", Description = "0 Visible Range, 1 Session approximation, 2 Lookback Bars, 3 Anchored From Bar.", GroupName = "10. Volume Profile", Order = 2)]
        public int ProfileMode { get; set; }

        [NinjaScriptProperty]
        [Range(0, 2)]
        [Display(Name = "Profile side", Description = "0 Right, 1 Left, 2 Floating.", GroupName = "10. Volume Profile", Order = 3)]
        public int ProfileSide { get; set; }

        [NinjaScriptProperty]
        [Range(10, 1000)]
        [Display(Name = "Profile lookback bars", Description = "Used when ProfileMode = Lookback Bars.", GroupName = "10. Volume Profile", Order = 4)]
        public int ProfileLookbackBars { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Show profile background", Description = "Subtle profile panel background.", GroupName = "10. Volume Profile", Order = 5)]
        public bool ShowProfileBackground { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Show profile numbers", Description = "Profile labels only when enough room exists.", GroupName = "10. Volume Profile", Order = 6)]
        public bool ShowProfileNumbers { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Show profile POC", Description = "Highlights profile POC.", GroupName = "10. Volume Profile", Order = 7)]
        public bool ShowProfilePoc { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Show value area", Description = "Highlights profile value area using POC-expansion algorithm.", GroupName = "10. Volume Profile", Order = 8)]
        public bool ShowValueArea { get; set; }

        [NinjaScriptProperty]
        [Range(50, 95)]
        [Display(Name = "Value area percent", Description = "Typical value: 70.", GroupName = "10. Volume Profile", Order = 9)]
        public int ValueAreaPercent { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Show HVN", Description = "Marks local high-volume nodes.", GroupName = "10. Volume Profile", Order = 10)]
        public bool ShowHVN { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Show LVN", Description = "Marks local low-volume nodes.", GroupName = "10. Volume Profile", Order = 11)]
        public bool ShowLVN { get; set; }

        [NinjaScriptProperty]
        [Range(1, 10)]
        [Display(Name = "HVN/LVN sensitivity", Description = "Higher = fewer local nodes.", GroupName = "10. Volume Profile", Order = 12)]
        public int HvnLvnSensitivity { get; set; }

        [NinjaScriptProperty]
        [Range(5, 80)]
        [Display(Name = "Profile opacity", Description = "Profile bar opacity.", GroupName = "10. Volume Profile", Order = 13)]
        public int ProfileOpacity { get; set; }

        [NinjaScriptProperty]
        [Range(5, 60)]
        [Display(Name = "Value area opacity", Description = "Value area background opacity.", GroupName = "10. Volume Profile", Order = 14)]
        public int ValueAreaOpacity { get; set; }

        [NinjaScriptProperty]
        [Range(5, 40)]
        [Display(Name = "Profile max width percent", Description = "Profile width as percent of chart panel width.", GroupName = "10. Volume Profile", Order = 15)]
        public int ProfileMaxWidthPercent { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Show volume", Description = "Bar stat volume.", GroupName = "11. Bar Stats", Order = 1)]
        public bool ShowVolumeStats { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Show delta", Description = "Tick-rule delta value.", GroupName = "11. Bar Stats", Order = 2)]
        public bool ShowDeltaStats { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Show delta percent", Description = "Tick-rule delta percent.", GroupName = "11. Bar Stats", Order = 3)]
        public bool ShowDeltaPercent { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Show signal label", Description = "Compact signal label in stat area only when density allows.", GroupName = "11. Bar Stats", Order = 4)]
        public bool ShowSignal { get; set; }


        [NinjaScriptProperty]
        [Range(0, 1)]
        [Display(Name = "Delta percent mode", Description = "0 ClassifiedOnly denominator, 1 IncludeUnclassified denominator. Delta itself remains BuyVolume - SellVolume.", GroupName = "11. Bar Stats", Order = 5)]
        public int DeltaPercentMode { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Show unclassified volume", Description = "Includes unclassified tick-rule volume in total-volume based heatmap/profile/stat calculations when available.", GroupName = "04. Footprint Numbers", Order = 6)]
        public bool ShowUnclassifiedVolume { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Show unclassified in stats", Description = "Displays unclassified volume in bar stats when available.", GroupName = "11. Bar Stats", Order = 6)]
        public bool ShowUnclassifiedInStats { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Show unclassified node marker", Description = "Draws a small neutral center marker on price levels containing unclassified volume.", GroupName = "04. Footprint Numbers", Order = 7)]
        public bool ShowUnclassifiedNodeMarker { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Show chart legend", Description = "Shows/hides the custom top-left overlay legend. Default is false to keep the chart clean.", GroupName = "12. Legend / Panels", Order = 1)]
        public bool ShowLegend { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Show extended legend details", Description = "Shows/hides the second legend row with density/heatmap/core/tick-rule details.", GroupName = "12. Legend / Panels", Order = 2)]
        public bool ShowExtendedLegend { get; set; }

        [NinjaScriptProperty]
        [Range(0, 3)]
        [Display(Name = "Legend position", Description = "0 TopLeft, 1 TopRight, 2 BottomLeft, 3 BottomRight.", GroupName = "12. Legend / Panels", Order = 3)]
        public int LegendPosition { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Auto-hide legend on small chart", Description = "Avoids covering the chart when the panel is too small.", GroupName = "12. Legend / Panels", Order = 4)]
        public bool AutoHideLegendOnSmallChart { get; set; }

        [NinjaScriptProperty]
        [Range(20, 95)]
        [Display(Name = "Legend opacity", Description = "Legend background opacity.", GroupName = "12. Legend / Panels", Order = 5)]
        public int LegendOpacity { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Show compact hint", Description = "Shows a small hint when footprint is hidden due to density.", GroupName = "12. Legend / Panels", Order = 6)]
        public bool ShowZoomHint { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Cache profile", Description = "Rebuilds visible profile only when invalidated.", GroupName = "90. Performance", Order = 1)]
        public bool CacheProfile { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Cache bar metrics", Description = "Caches POC/max node/range/signal metrics per bar.", GroupName = "90. Performance", Order = 2)]
        public bool CacheBarMetrics { get; set; }


        [NinjaScriptProperty]
        [Display(Name = "Show delta ribbon", Description = "Small bottom ribbon colored by tick-rule delta percent.", GroupName = "09. Signals", Order = 5)]
        public bool ShowDeltaRibbon { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Show POC migration", Description = "Draws small connecting markers when POC migrates between consecutive bars.", GroupName = "09. Signals", Order = 6)]
        public bool ShowPocMigration { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Show imbalance ladder", Description = "Connects stacked imbalance levels with a thin rail when density allows.", GroupName = "09. Signals", Order = 7)]
        public bool ShowImbalanceLadder { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Show micro labels", Description = "Shows score/delta/stack count only at high zoom.", GroupName = "09. Signals", Order = 8)]
        public bool ShowMicroLabels { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Show VAH/VAL lines", Description = "Draws visible-profile value area high/low boundaries.", GroupName = "10. Volume Profile", Order = 16)]
        public bool ShowValueAreaBoundaryLines { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Debug mode", Description = "No Print output unless enabled. Research visual labels may appear in Debug/Research preset.", GroupName = "99. Debug", Order = 1)]
        public bool DebugMode { get; set; }

        #endregion

        #region Strategy API / objective outputs

        public bool HasBuyStack(int barIndex)
        {
            FlowMetrics m = GetCachedMetrics(barIndex);
            return m != null && m.Valid && m.AskStackCount > 0;
        }

        public bool HasSellStack(int barIndex)
        {
            FlowMetrics m = GetCachedMetrics(barIndex);
            return m != null && m.Valid && m.BidStackCount > 0;
        }

        public double GetFootprintPocPrice(int barIndex)
        {
            FlowMetrics m = GetCachedMetrics(barIndex);
            return m != null && m.Valid ? m.PocPrice : double.NaN;
        }

        public long GetFootprintDelta(int barIndex)
        {
            FlowMetrics m = GetCachedMetrics(barIndex);
            return m != null && m.Valid ? m.Delta : 0;
        }

        public double GetFootprintDeltaPercent(int barIndex)
        {
            FlowMetrics m = GetCachedMetrics(barIndex);
            return m != null && m.Valid ? m.DeltaPercent : 0;
        }

        public int GetAskImbalanceCount(int barIndex)
        {
            FlowMetrics m = GetCachedMetrics(barIndex);
            return m != null && m.Valid ? m.AskImbalanceCount : 0;
        }

        public int GetBidImbalanceCount(int barIndex)
        {
            FlowMetrics m = GetCachedMetrics(barIndex);
            return m != null && m.Valid ? m.BidImbalanceCount : 0;
        }

        public bool IsInBuyZone(double price)
        {
            if (cache == null || cache.AllZones == null)
                return false;
            for (int i = 0; i < cache.AllZones.Count; i++)
            {
                StackZone z = cache.AllZones[i];
                if (z == null || !z.IsBuy || z.Invalidated || z.IsManuallyExpired)
                    continue;
                if (price >= Math.Min(z.FromPrice, z.ToPrice) && price <= Math.Max(z.FromPrice, z.ToPrice))
                    return true;
            }
            return false;
        }

        public bool IsInSellZone(double price)
        {
            if (cache == null || cache.AllZones == null)
                return false;
            for (int i = 0; i < cache.AllZones.Count; i++)
            {
                StackZone z = cache.AllZones[i];
                if (z == null || z.IsBuy || z.Invalidated || z.IsManuallyExpired)
                    continue;
                if (price >= Math.Min(z.FromPrice, z.ToPrice) && price <= Math.Max(z.FromPrice, z.ToPrice))
                    return true;
            }
            return false;
        }

        public string GetMetricsSnapshot(int barIndex)
        {
            FlowMetrics m = GetCachedMetrics(barIndex);
            if (m == null || !m.Valid)
                return string.Empty;
            return string.Format(System.Globalization.CultureInfo.InvariantCulture,
                "bar={0};profile={1};groupTicks={2};vol={3};delta={4};deltaPct={5:0.00};poc={6};askImb={7};bidImb={8};askStacks={9};bidStacks={10}",
                m.BarIndex, AssetProfile, currentTickMultiplier, m.TotalVolume, m.Delta, m.DeltaPercent, m.PocPrice, m.AskImbalanceCount, m.BidImbalanceCount, m.AskStackCount, m.BidStackCount);
        }

        #endregion

        #region State / resources

        protected override void OnStateChange()
        {
            if (State == State.SetDefaults)
            {
                Name = "OrderFlow Minute PRO V8 Footprint Suite UX V5";
                Description = "OrderFlow Minute PRO V8 Footprint Suite UX V5 - premium institutional order-flow/footprint overlay. " +
                              "Requires BarsType: OrderFlow Minute PRO V8 / OrderFlowMinuteBarsTypeV8NoOutput. " +
                              "Data model: tick-rule approximation, not real exchange bid/ask aggressor tape. " +
                              "Main setup groups: 00 UX Preset, 01 Theme, 02 Adaptive Density, 03 Footprint Cells, 03B Internal Heatmap Core, 04 Footprint Numbers, 05 Imbalance, 06 Stacked Imbalance, 07 Stack Zones, 08 Reversal Engine, 09 Signals, 10 Volume Profile, 11 Bar Stats, 12 Legend/Panels, 90 Performance, 99 Debug. " +
                              "Key parameters: UxPresetMode 0 Black Background / 1 White Background; " +
                              "ThemeMode 0 Black/Dark background / 1 White/Light background; " +
                              "AutoDensityMode and ForceDensityMode 0 Hidden to 5 FullDetail; HeatmapLevels 8-32; HeatmapGammaX100; HeatmapScaleMode 0 PerBar / 1 VisibleRange / 2 SessionApprox / 3 Hybrid; InternalHeatmapCoreMode 0 Off / 1 Total / 2 DeltaWeighted / 3 POC-HVN / 4 Persistent / 5 LiquidityPressure; " +
                              "ImbalanceRatioPercent, MinImbalanceVolume, ShowZeroCompareImbalance, ZeroCompareMinVolume; StackMinCount, StackMinVolume, ShowStackZones, MergeNearbyZones, ZoneMergeTicks, EnableZoneDecay; " +
                              "ReversalScoreMode 0 Simple / 1 Weighted, MinReversalScore, StrongReversalThreshold, InstitutionalReversalThreshold, ReversalUseCloseLocation, ReversalUseWickRejection, ReversalUseDeltaDivergence, ReversalUseInitiativeStack; " +
                              "Signals: ShowDeltaRibbon, ShowSignalLane, ShowSignalStripes, ShowPocMigration, ShowImbalanceLadder, ShowMicroLabels; " +
                              "Profile: ProfileMode 0 Visible / 1 SessionApprox / 2 Lookback / 3 Anchored, ProfileLookbackBars, ProfileAnchorBarsBack if available, ValueAreaPercent, ShowHVN, ShowLVN, ProfileOpacity, ValueAreaOpacity; " +
                              "Unclassified/tick-rule: DeltaPercentMode if available, ShowUnclassifiedVolume/InStats/NodeMarker if available. " +
                              "Performance: CacheProfile, CacheBarMetrics, EnableVisualBudget/MaxVisualElementsPerBar if available. Debug output only when DebugMode is enabled.";
                Calculate = Calculate.OnEachTick;
                IsOverlay = true;
                DrawOnPricePanel = true;
                DisplayInDataBox = false;
                PaintPriceMarkers = false;
                IsSuspendedWhileInactive = true;

                AssetProfile = InstrumentProfile.ES_Standard;
                CustomPriceGroupTicks = 1;
                UxPresetMode = 1;
                ThemeMode = 1;
                PanelOpacity = 68;
                GridOpacity = 4;
                EnableSoftGlow = true;

                AutoDensityMode = true;
                ForceDensityMode = 3;
                HideNumbersBelowBarWidth = 34;
                HideGridBelowBarWidth = 90;
                HideProfileNumbersBelowBarWidth = 55;
                MinPixelsPerTickForNumbers = 6;

                ShowFootprintVolume = true;
                HeatmapLevels = 30;
                HeatmapMinOpacity = 7;
                HeatmapMaxOpacity = 98;
                HeatmapGammaX100 = 82;
                CellStyleMode = 3;
                EnableRoundedCells = true;
                CellCornerRadius = 2;
                HeatmapScaleMode = 3;
                ShowInternalHeatmapCore = true;
                InternalHeatmapCoreMode = 5;
                InternalHeatmapCoreWidthPercent = 34;
                InternalHeatmapCoreMaxWidth = 22;
                InternalHeatmapCoreOpacity = 78;
                InternalHeatmapHvnPercent = 68;
                PersistentNodeLookbackBars = 5;
                PersistentNodeMergeTicks = 1;
                PersistentNodeMinHits = 2;
                HideInternalHeatmapNoise = true;
                InternalHeatNoiseThresholdPercent = 12;

                ShowFootprintNumbers = true;
                FontSize = 10;
                ShowFootprintGrid = false;
                ShowFootprintPoc = true;
                PocMarkerSize = 4;

                ImbalanceRatioPercent = 300;
                MinImbalanceVolume = 0;
                ShowZeroCompareImbalance = true;
                ZeroCompareMinVolume = 1;
                ImbalanceMarkerStyle = 2;
                ShowImbalanceMarkers = false;

                ShowStacks = true;
                StackMinCount = 3;
                StackMinVolume = 0;

                ShowStackZones = true;
                MaxVisibleStackZones = 12;
                StackZoneLookbackBars = 300;
                StackZoneProjectionBars = 300;
                MergeNearbyZones = true;
                ZoneMergeTicks = 2;
                EnableZoneDecay = false;
                ZoneDecayBars = 140;
                InvalidateZonesOnCloseThrough = false;
                ShowZoneRetests = true;
                ZoneStrengthMode = 1;
                MinZoneStrength = 0;
                KeepStackZonesPersistent = true;
                PersistentZoneMaxBars = 1200;
                MaxStoredStackZones = 150;
                DrawStackZonesAcrossVisibleChart = false;
                ShowStackZoneCenterLine = true;
                StackZoneLineWidth = 2;
                StackZoneLineOpacity = 80;
                ZoneInvalidationTicks = 2;
                StackZoneLineSpanMode = 1;
                StopStackZoneAtFirstReaction = true;
                StackZoneReactionToleranceTicks = 1;
                StackZoneReactionDetectionMode = 3;
                ShowStackZoneReactionMarker = true;
                StackZoneReactionMarkerSize = 4;

                ShowReversalClusters = true;
                ReversalScoreMode = 1;
                MinReversalScore = 48;
                ShowWeakReversals = false;
                StrongReversalThreshold = 62;
                InstitutionalReversalThreshold = 78;
                ReversalMarkerStyle = 0;
                ReversalUseCloseLocation = true;
                ReversalUseWickRejection = true;
                ReversalUseDeltaDivergence = true;
                ReversalUseInitiativeStack = true;
                ExtremeExhaustionPercent = 42;
                ReversalExtremeTicks = 2;
                VolumeClimaxMultiplier = 155;
                SignalMarkerSize = 5;
                ShowSignalStripes = false;
                ShowSignalLane = true;
                ShowPriceLevelSignals = true;
                ShowDeltaRibbon = true;
                ShowPocMigration = true;
                ShowImbalanceLadder = false;
                ShowMicroLabels = false;

                ShowProfile = true;
                ProfileMode = 0;
                ProfileSide = 0;
                ProfileLookbackBars = 140;
                ShowProfileBackground = true;
                ShowProfileNumbers = false;
                ShowProfilePoc = true;
                ShowValueArea = true;
                ValueAreaPercent = 70;
                ShowHVN = false;
                ShowLVN = false;
                HvnLvnSensitivity = 3;
                ProfileOpacity = 18;
                ValueAreaOpacity = 8;
                ProfileMaxWidthPercent = 14;
                ShowValueAreaBoundaryLines = true;

                ShowVolumeStats = false;
                ShowDeltaStats = false;
                ShowDeltaPercent = true;
                DeltaPercentMode = 1;
                ShowUnclassifiedVolume = true;
                ShowUnclassifiedInStats = false;
                ShowUnclassifiedNodeMarker = true;
                ShowSignal = true;

                ShowLegend = false;
                ShowExtendedLegend = false;
                LegendPosition = 0;
                AutoHideLegendOnSmallChart = true;
                LegendOpacity = 62;
                ShowZoomHint = true;

                CacheProfile = true;
                CacheBarMetrics = true;
                DebugMode = false;
            }
            else if (State == State.DataLoaded)
            {
                ofBars = Bars != null ? Bars.BarsType as OrderFlowMinuteBarsTypeV8NoOutput : null;
                signals = new SignalEngine(this);
                // Legacy DOM load removed
                InitializeCoreModules();
                CreateTextFormats();
            }
            else if (State == State.Terminated)
            {
                // Legacy DOM save removed
                DisposeCoreModules();
                DisposeDx();
                DisposeTextFormats();
                if (dwFactory != null)
                    dwFactory.Dispose();
                dwFactory = null;
            }
        }

        private void CreateTextFormats()
        {
            DisposeTextFormats();
            if (dwFactory == null)
                dwFactory = new SharpDX.DirectWrite.Factory();

            float s = Math.Max(8f, FontSize);
            fontTiny = new TextFormat(dwFactory, "Segoe UI", SharpDX.DirectWrite.FontWeight.Normal, SharpDX.DirectWrite.FontStyle.Normal, Math.Max(8f, s - 2f));
            fontSmall = new TextFormat(dwFactory, "Segoe UI", SharpDX.DirectWrite.FontWeight.Normal, SharpDX.DirectWrite.FontStyle.Normal, s);
            fontNormal = new TextFormat(dwFactory, "Segoe UI", SharpDX.DirectWrite.FontWeight.Normal, SharpDX.DirectWrite.FontStyle.Normal, s + 1f);
            fontBold = new TextFormat(dwFactory, "Segoe UI", SharpDX.DirectWrite.FontWeight.SemiBold, SharpDX.DirectWrite.FontStyle.Normal, s + 1f);
        }

        public override void OnRenderTargetChanged()
        {
            DisposeDx();
            if (RenderTarget == null)
                return;

            ConfigureTheme();
            CreateBrushes();
        }

        private void ConfigureTheme()
        {
            float panelAlpha = Clamp01(PanelOpacity / 100f);
            float gridAlpha = Clamp01(GridOpacity / 100f);
            float vaAlpha = Clamp01(ValueAreaOpacity / 100f);

            // Two primary background-optimized themes only.
            if (ThemeMode == 1 || UxPresetMode == 1) // White / light chart background
            {
                theme.Bid = new DxColor(0.48f, 0.10f, 0.62f, 1f);
                theme.Ask = new DxColor(0.00f, 0.35f, 0.75f, 1f);
                theme.Bull = new DxColor(0.00f, 0.42f, 0.68f, 1f);
                theme.Bear = new DxColor(0.56f, 0.12f, 0.42f, 1f);
                theme.BidStrong = new DxColor(0.42f, 0.05f, 0.52f, 0.95f);
                theme.AskStrong = new DxColor(0.00f, 0.30f, 0.62f, 0.95f);
                theme.Poc = new DxColor(0.08f, 0.09f, 0.11f, 0.95f);
                theme.ValueArea = new DxColor(0.66f, 0.70f, 0.76f, Math.Max(0.08f, vaAlpha));
                theme.Text = new DxColor(0.08f, 0.09f, 0.11f, 0.96f);
                theme.MutedText = new DxColor(0.30f, 0.32f, 0.36f, 0.88f);
                theme.Grid = new DxColor(0.38f, 0.40f, 0.44f, Math.Max(0.06f, gridAlpha));
                theme.Panel = new DxColor(0.94f, 0.95f, 0.97f, Math.Max(0.80f, panelAlpha));
                theme.PanelBorder = new DxColor(0.30f, 0.32f, 0.36f, 0.22f);
                theme.Gold = new DxColor(0.72f, 0.48f, 0.05f, 0.96f);
                theme.Neutral = new DxColor(0.42f, 0.45f, 0.50f, 0.74f);
                theme.ProfileBg = new DxColor(0.92f, 0.94f, 0.96f, Math.Max(0.72f, Clamp01((PanelOpacity - 8) / 100f)));
                theme.Hvn = new DxColor(0.62f, 0.42f, 0.08f, 0.82f);
                theme.Lvn = new DxColor(0.18f, 0.42f, 0.66f, 0.76f);
                theme.Absorption = new DxColor(0.18f, 0.18f, 0.20f, 0.86f);
                theme.Trap = new DxColor(0.74f, 0.32f, 0.06f, 0.92f);
                theme.Divergence = new DxColor(0.72f, 0.48f, 0.05f, 0.92f);
                theme.Pivot = new DxColor(0.30f, 0.32f, 0.36f, 0.80f);
            }
            else // Black / dark chart background
            {
                theme.Bid = new DxColor(0.70f, 0.28f, 0.85f, 1f);
                theme.Ask = new DxColor(0.05f, 0.62f, 0.95f, 1f);
                theme.Bull = new DxColor(0.12f, 0.78f, 0.72f, 1f);
                theme.Bear = new DxColor(0.88f, 0.28f, 0.72f, 1f);
                theme.BidStrong = new DxColor(0.82f, 0.22f, 0.96f, 0.92f);
                theme.AskStrong = new DxColor(0.02f, 0.78f, 1.00f, 0.92f);
                theme.Poc = new DxColor(0.96f, 0.96f, 0.92f, 0.98f);
                theme.ValueArea = new DxColor(0.78f, 0.78f, 0.78f, Math.Max(0.06f, vaAlpha));
                theme.Text = new DxColor(0.92f, 0.94f, 0.96f, 0.96f);
                theme.MutedText = new DxColor(0.64f, 0.68f, 0.74f, 0.88f);
                theme.Grid = new DxColor(0.72f, 0.74f, 0.78f, Math.Max(0.03f, gridAlpha));
                theme.Panel = new DxColor(0.025f, 0.032f, 0.045f, panelAlpha);
                theme.PanelBorder = new DxColor(1.00f, 1.00f, 1.00f, 0.10f);
                theme.Gold = new DxColor(1.00f, 0.78f, 0.18f, 0.96f);
                theme.Neutral = new DxColor(0.62f, 0.66f, 0.70f, 0.74f);
                theme.ProfileBg = new DxColor(0.02f, 0.025f, 0.035f, Clamp01((PanelOpacity - 18) / 100f));
                theme.Hvn = new DxColor(0.95f, 0.86f, 0.40f, 0.82f);
                theme.Lvn = new DxColor(0.48f, 0.78f, 0.95f, 0.76f);
                theme.Absorption = new DxColor(0.92f, 0.92f, 0.88f, 0.92f);
                theme.Trap = new DxColor(1.00f, 0.58f, 0.22f, 0.92f);
                theme.Divergence = new DxColor(1.00f, 0.78f, 0.18f, 0.92f);
                theme.Pivot = new DxColor(0.62f, 0.68f, 0.76f, 0.80f);
            }
        }

        private void CreateBrushes()
        {
            float fillAlpha = Clamp01(HeatmapMaxOpacity / 100f);
            bidBrush = new DxSolidColorBrush(RenderTarget, new DxColor(theme.Bid.Red, theme.Bid.Green, theme.Bid.Blue, fillAlpha * 0.45f));
            askBrush = new DxSolidColorBrush(RenderTarget, new DxColor(theme.Ask.Red, theme.Ask.Green, theme.Ask.Blue, fillAlpha * 0.45f));
            bidStrongBrush = new DxSolidColorBrush(RenderTarget, theme.BidStrong);
            askStrongBrush = new DxSolidColorBrush(RenderTarget, theme.AskStrong);
            textBrush = new DxSolidColorBrush(RenderTarget, theme.Text);
            mutedTextBrush = new DxSolidColorBrush(RenderTarget, theme.MutedText);
            gridBrush = new DxSolidColorBrush(RenderTarget, theme.Grid);
            panelBrush = new DxSolidColorBrush(RenderTarget, theme.Panel);
            panelBorderBrush = new DxSolidColorBrush(RenderTarget, theme.PanelBorder);
            pocBrush = new DxSolidColorBrush(RenderTarget, theme.Poc);
            valueAreaBrush = new DxSolidColorBrush(RenderTarget, theme.ValueArea);
            bullBrush = new DxSolidColorBrush(RenderTarget, theme.Bull);
            bearBrush = new DxSolidColorBrush(RenderTarget, theme.Bear);
            goldBrush = new DxSolidColorBrush(RenderTarget, theme.Gold);
            neutralBrush = new DxSolidColorBrush(RenderTarget, theme.Neutral);
            profileBgBrush = new DxSolidColorBrush(RenderTarget, theme.ProfileBg);
            hvnBrush = new DxSolidColorBrush(RenderTarget, theme.Hvn);
            lvnBrush = new DxSolidColorBrush(RenderTarget, theme.Lvn);
            bullReversalBrush = new DxSolidColorBrush(RenderTarget, theme.Bull);
            bearReversalBrush = new DxSolidColorBrush(RenderTarget, theme.Bear);
            reversalGlowBrush = new DxSolidColorBrush(RenderTarget, new DxColor(theme.Gold.Red, theme.Gold.Green, theme.Gold.Blue, 0.22f));
            absorptionBrush = new DxSolidColorBrush(RenderTarget, theme.Absorption);
            trapBrush = new DxSolidColorBrush(RenderTarget, theme.Trap);
            divergenceBrush = new DxSolidColorBrush(RenderTarget, theme.Divergence);
            pivotBrush = new DxSolidColorBrush(RenderTarget, theme.Pivot);
            warningBrush = new DxSolidColorBrush(RenderTarget, theme.Gold);
            profileVolumeBrush = new DxSolidColorBrush(RenderTarget, new DxColor(theme.Ask.Red, theme.Ask.Green, theme.Ask.Blue, Clamp01(ProfileOpacity / 100f)));
            profileValueAreaBrush = new DxSolidColorBrush(RenderTarget, new DxColor(theme.ValueArea.Red, theme.ValueArea.Green, theme.ValueArea.Blue, Clamp01(ValueAreaOpacity / 100f)));
            unclassifiedBrush = new DxSolidColorBrush(RenderTarget, new DxColor(theme.Neutral.Red, theme.Neutral.Green, theme.Neutral.Blue, 0.45f));

            int levels = ClampInt(HeatmapLevels, 8, MaxHeatmapLevels);
            float minAlpha = Clamp01(HeatmapMinOpacity / 100f);
            float maxAlpha = Clamp01(HeatmapMaxOpacity / 100f);
            if (maxAlpha <= minAlpha) maxAlpha = minAlpha + 0.05f;
            for (int i = 0; i < MaxHeatmapLevels; i++)
            {
                float t = levels <= 1 ? 1f : (float)Math.Min(i, levels - 1) / (levels - 1);
                float alpha = minAlpha + (maxAlpha - minAlpha) * t;
                bidHeatBrushes[i] = new DxSolidColorBrush(RenderTarget, new DxColor(theme.Bid.Red, theme.Bid.Green, theme.Bid.Blue, alpha));
                askHeatBrushes[i] = new DxSolidColorBrush(RenderTarget, new DxColor(theme.Ask.Red, theme.Ask.Green, theme.Ask.Blue, alpha));

                float coreAlpha = Clamp01(alpha * (InternalHeatmapCoreOpacity / 100f));
                internalNeutralHeatBrushes[i] = new DxSolidColorBrush(RenderTarget, new DxColor(theme.Neutral.Red, theme.Neutral.Green, theme.Neutral.Blue, coreAlpha));
                internalBullHeatBrushes[i] = new DxSolidColorBrush(RenderTarget, new DxColor(theme.Ask.Red, theme.Ask.Green, theme.Ask.Blue, coreAlpha));
                internalBearHeatBrushes[i] = new DxSolidColorBrush(RenderTarget, new DxColor(theme.Bid.Red, theme.Bid.Green, theme.Bid.Blue, coreAlpha));
            }
            internalPocCoreBrush = new DxSolidColorBrush(RenderTarget, new DxColor(theme.Poc.Red, theme.Poc.Green, theme.Poc.Blue, Clamp01(InternalHeatmapCoreOpacity / 100f)));
            persistentCoreBrush = new DxSolidColorBrush(RenderTarget, new DxColor(theme.Gold.Red, theme.Gold.Green, theme.Gold.Blue, Clamp01(InternalHeatmapCoreOpacity / 100f)));
            float zoneLineAlpha = Clamp01(StackZoneLineOpacity / 100f);
            buyZoneLineBrush = new DxSolidColorBrush(RenderTarget, new DxColor(theme.Bull.Red, theme.Bull.Green, theme.Bull.Blue, zoneLineAlpha));
            sellZoneLineBrush = new DxSolidColorBrush(RenderTarget, new DxColor(theme.Bear.Red, theme.Bear.Green, theme.Bear.Blue, zoneLineAlpha));

            for (int i = 0; i < MaxZoneAlphaLevels; i++)
            {
                float a = 0.035f + i * 0.025f;
                buyZoneBrushes[i] = new DxSolidColorBrush(RenderTarget, new DxColor(theme.Bull.Red, theme.Bull.Green, theme.Bull.Blue, a));
                sellZoneBrushes[i] = new DxSolidColorBrush(RenderTarget, new DxColor(theme.Bear.Red, theme.Bear.Green, theme.Bear.Blue, a));
            }
        }

        #endregion
        // Legacy DOM Bricks V6 helper methods removed.
#region Render entry

        protected override void OnRender(ChartControl chartControl, ChartScale chartScale)
        {
            base.OnRender(chartControl, chartScale);

            if (RenderTarget == null || ChartBars == null || Bars == null || ChartPanel == null || chartControl == null || chartScale == null)
                return;

            if (ofBars == null)
                ofBars = Bars.BarsType as OrderFlowMinuteBarsTypeV8NoOutput;

            if (ofBars == null)
            {
                DrawWarning("Ez az indikátor csak az OrderFlow Minute PRO V8 BarsType-pal működik. Tick-rule approximation overlay.");
                return;
            }

            ComputeRenderSettings(chartControl, chartScale);
            ComputeLayoutLanes();
            ApplyPresetOverrides();
            EnsureVisibleCaches();

            if (ShowStackZones)
                DrawStackZones(chartControl, chartScale);
            // Legacy DOM draw removed; use DOMBrickStandaloneOrderFlowV1 indicator.

            DrawInternalHeatmapCore(chartControl, chartScale);
            DrawFootprintCells(chartControl, chartScale);
            DrawStackMarkers(chartControl, chartScale);
            DrawReversalMarkers(chartControl, chartScale);

            if (ShowProfile)
                DrawProfile(chartControl, chartScale);

            DrawValueAreaBoundaryLines(chartControl, chartScale);
            DrawPocMigration(chartControl, chartScale);
            DrawDeltaRibbon(chartControl, chartScale);
            DrawImbalanceLadder(chartControl, chartScale);
            DrawMicroLabels(chartControl, chartScale);

            DrawSignalStripes(chartControl, chartScale);
            DrawSignalLane(chartControl, chartScale);
            DrawBarStats(chartControl, chartScale);
            DrawLegend(chartControl, chartScale);

            if (ShowZoomHint && rs.DensityMode == 0)
                DrawCompactHint();
        }

        private void ComputeRenderSettings(ChartControl chartControl, ChartScale chartScale)
        {
            currentTickMultiplier = GetActiveTickMultiplier();
            rs.From = Math.Max(0, ChartBars.FromIndex);
            rs.To = Math.Min(Bars.Count - 1, ChartBars.ToIndex);
            rs.VisibleBars = Math.Max(1, rs.To - rs.From + 1);
            rs.BarWidth = ChartPanel.W / Math.Max(1, rs.VisibleBars);
            rs.CellWidth = Math.Min(Math.Max(3f, rs.BarWidth * 0.45f), 48f);
            rs.CellHeight = Math.Max(7f, Math.Min(16f, FontSize + 2f));
            double p1 = Close.Count > 0 ? Close[0] : 0;
            double displayTickSize = TickSize * Math.Max(1, currentTickMultiplier);
            rs.PixelsPerTick = displayTickSize > 0 ? Math.Abs(chartScale.GetYByValue(p1) - chartScale.GetYByValue(p1 + displayTickSize)) : 0f;
            rs.ProfileWidth = Math.Min(ChartPanel.W * (ProfileMaxWidthPercent / 100f), Math.Max(48f, ChartPanel.W * 0.24f));

            if (TickSize <= 0)
            {
                rs.DensityMode = 0;
                rs.CanDrawFootprint = false;
                rs.CanDrawHeatmap = false;
                rs.CanDrawPoc = false;
                rs.CanDrawImbalance = false;
                rs.CanDrawStack = false;
                rs.CanDrawNumbers = false;
                rs.CanDrawGrid = false;
                rs.CanDrawProfileNumbers = false;
                rs.CanDrawSignals = false;
                rs.CanDrawBarStats = false;
                rs.CanDrawInternalCore = false;
                return;
            }

            if (!AutoDensityMode)
                rs.DensityMode = ForceDensityMode;
            else
            {
                if (rs.BarWidth < 12 || rs.PixelsPerTick < 2.2f) rs.DensityMode = 0;
                else if (rs.BarWidth < 22 || rs.PixelsPerTick < 3.5f) rs.DensityMode = 1;
                else if (rs.BarWidth < 40 || rs.PixelsPerTick < 5.0f) rs.DensityMode = 2;
                else if (rs.BarWidth < HideNumbersBelowBarWidth || rs.PixelsPerTick < MinPixelsPerTickForNumbers) rs.DensityMode = 3;
                else if (rs.BarWidth < 65) rs.DensityMode = 4;
                else rs.DensityMode = 5;
            }

            if (UxPresetMode == 0 || UxPresetMode == 1) // Keep heatmap/internal core visible longer on dense charts.
            {
                if (rs.BarWidth >= 8 && rs.PixelsPerTick >= 1.6f)
                    rs.DensityMode = Math.Max(rs.DensityMode, 1);
                if (rs.BarWidth >= 16 && rs.PixelsPerTick >= 2.4f)
                    rs.DensityMode = Math.Max(rs.DensityMode, 2);
                if (rs.BarWidth >= 24 && rs.PixelsPerTick >= 3.2f)
                    rs.DensityMode = Math.Max(rs.DensityMode, 3);
                if (rs.BarWidth >= HideNumbersBelowBarWidth && rs.PixelsPerTick >= MinPixelsPerTickForNumbers)
                    rs.DensityMode = Math.Max(rs.DensityMode, 4);
            }

            rs.CanDrawFootprint = ShowFootprintVolume && rs.DensityMode >= 1;
            rs.CanDrawHeatmap = rs.DensityMode >= 1;
            rs.CanDrawPoc = ShowFootprintPoc && rs.DensityMode >= 2;
            rs.CanDrawImbalance = rs.DensityMode >= 3;
            rs.CanDrawStack = ShowStacks && rs.DensityMode >= 4;
            rs.CanDrawNumbers = ShowFootprintNumbers && rs.DensityMode >= 4 && rs.BarWidth >= HideNumbersBelowBarWidth && rs.PixelsPerTick >= MinPixelsPerTickForNumbers;
            rs.CanDrawGrid = ShowFootprintGrid && rs.DensityMode >= 5 && rs.BarWidth >= HideGridBelowBarWidth;
            rs.CanDrawProfileNumbers = ShowProfileNumbers && rs.BarWidth >= HideProfileNumbersBelowBarWidth;
            rs.CanDrawSignals = rs.DensityMode >= 1;
            rs.CanDrawBarStats = rs.DensityMode >= 2;
            rs.CanDrawInternalCore = ShowInternalHeatmapCore && InternalHeatmapCoreMode > 0 && rs.DensityMode >= 1 && rs.BarWidth >= 6 && rs.PixelsPerTick >= 1.4f;
        }

        private void ApplyPresetOverrides()
        {
            bool enoughNumberSpace = rs.BarWidth >= HideNumbersBelowBarWidth && rs.PixelsPerTick >= MinPixelsPerTickForNumbers;

            // Only two visual presets remain: 0 Black/Dark background, 1 White/Light background.
            // The order-flow logic is identical; the preset only controls visual density hierarchy.
            rs.CanDrawGrid = ShowFootprintGrid && rs.DensityMode >= 5 && rs.BarWidth >= HideGridBelowBarWidth;
            rs.CanDrawInternalCore = ShowInternalHeatmapCore && InternalHeatmapCoreMode > 0 && rs.DensityMode >= 1 && rs.BarWidth >= 6 && rs.PixelsPerTick >= 1.2f;
            rs.CanDrawImbalance = rs.DensityMode >= 2;
            rs.CanDrawStack = ShowStacks && rs.DensityMode >= 2;
            rs.CanDrawNumbers = ShowFootprintNumbers && rs.DensityMode >= 4 && enoughNumberSpace;
            rs.CanDrawProfileNumbers = ShowProfileNumbers && rs.BarWidth >= HideProfileNumbersBelowBarWidth;
            rs.CanDrawSignals = rs.DensityMode >= 1;
            rs.CanDrawBarStats = rs.DensityMode >= 4 && rs.BarWidth >= 42;
            rs.CanDrawGrid = false;

            // Stack zone horizontal lines are intentionally not density-gated.
            // DrawStackZones() is controlled by ShowStackZones and persistent-zone settings only.
        }

        private void EnsureVisibleCaches()
        {
            int dataCount = ofBars != null && ofBars.FlowDataByBar != null ? ofBars.FlowDataByBar.Count : 0;
            for (int i = rs.From; i <= rs.To; i++)
                GetCachedMetrics(i);

            if (ShowProfile)
                RebuildProfileIfNeeded(dataCount);

            if (ShowStackZones)
                RebuildZonesIfNeeded(dataCount);
        }

        #endregion

        #region Metrics / profile cache

        private FlowMetrics GetCachedMetrics(int barIndex)
        {
            if (ofBars == null || Bars == null || barIndex < 0 || barIndex >= Bars.Count)
                return null;

            OrderFlowMinuteProOrderFlowDataV8NoOutput flow;
            if (!ofBars.FlowDataByBar.TryGetValue(barIndex, out flow) || flow == null)
                return null;

            FlowMetrics m;
            if (CacheBarMetrics && cache.Metrics.TryGetValue(barIndex, out m) && IsMetricsCacheValid(barIndex, m, flow))
                return m;

            m = BuildMetrics(barIndex);
            if (CacheBarMetrics && m != null)
                cache.Metrics[barIndex] = m;
            return m;
        }

        private bool IsMetricsCacheValid(int barIndex, FlowMetrics m, OrderFlowMinuteProOrderFlowDataV8NoOutput flow)
        {
            if (m == null || !m.Valid || flow == null || flow.Footprint == null)
                return false;
            if (barIndex >= Bars.Count - 2)
                return false;
            if (m.FootprintLevelCount != flow.Footprint.Count)
                return false;
            if (m.SourceTotalVolume != GetDisplayTotalVolume(flow))
                return false;
            if (m.SourceBuyVolume != flow.BuyVolume || m.SourceSellVolume != flow.SellVolume || m.SourceUnclassifiedVolume != flow.UnclassifiedVolume)
                return false;
            if (m.SourceTradeCount != flow.TradeCount)
                return false;
            if (m.SourceMaxNodeVolume != flow.MaxNodeVolume)
                return false;
            if (Math.Abs(m.SourcePocPrice - flow.PocPrice) > TickSize * 0.5)
                return false;
            return true;
        }

        private void FillMetricFingerprint(FlowMetrics m, OrderFlowMinuteProOrderFlowDataV8NoOutput flow)
        {
            if (m == null || flow == null)
                return;
            m.FootprintLevelCount = flow.Footprint != null ? flow.Footprint.Count : 0;
            m.SourceTotalVolume = GetDisplayTotalVolume(flow);
            m.SourceBuyVolume = flow.BuyVolume;
            m.SourceSellVolume = flow.SellVolume;
            m.SourceUnclassifiedVolume = flow.UnclassifiedVolume;
            m.SourceMaxNodeVolume = flow.MaxNodeVolume;
            m.SourcePocPrice = flow.PocPrice;
            m.SourceTradeCount = flow.TradeCount;
        }

        private FlowMetrics BuildMetrics(int barIndex)
        {
            FlowMetrics m = new FlowMetrics { BarIndex = barIndex, Valid = false };
            if (ofBars == null || barIndex < 0 || barIndex >= Bars.Count)
                return m;

            OrderFlowMinuteProOrderFlowDataV8NoOutput flow;
            if (!ofBars.FlowDataByBar.TryGetValue(barIndex, out flow) || flow == null || flow.Footprint == null || flow.Footprint.Count == 0)
                return m;

            Dictionary<double, OrderFlowMinuteProPriceLevelDataV8NoOutput> groupedFootprint = BuildGroupedFootprint(flow);
            if (groupedFootprint == null || groupedFootprint.Count == 0)
                return m;

            m.ClassifiedVolume = GetClassifiedVolume(flow);
            m.UnclassifiedVolume = flow.UnclassifiedVolume;
            m.TotalVolume = GetDisplayTotalVolume(flow);
            m.Delta = flow.Delta;
            m.DeltaPercent = GetDeltaPercent(flow);
            m.MinPrice = double.MaxValue;
            m.MaxPrice = double.MinValue;
            m.MaxNodeVolume = 0;
            m.PocVolume = 0;
            m.PocPrice = 0;

            double groupedTickSize = GetDisplayTickSize();

            foreach (KeyValuePair<double, OrderFlowMinuteProPriceLevelDataV8NoOutput> kv in groupedFootprint)
            {
                double p = kv.Key;
                OrderFlowMinuteProPriceLevelDataV8NoOutput level = kv.Value;
                if (level == null)
                    continue;

                long bid = level.SellVolume;
                long ask = level.BuyVolume;
                long total = bid + ask + (ShowUnclassifiedVolume ? level.UnclassifiedVolume : 0);
                if (total <= 0)
                    continue;

                if (p < m.MinPrice) m.MinPrice = p;
                if (p > m.MaxPrice) m.MaxPrice = p;
                if (total > m.MaxNodeVolume)
                    m.MaxNodeVolume = total;
                if (total > m.PocVolume)
                {
                    m.PocVolume = total;
                    m.PocPrice = p;
                }

                long diagonalBidBelow = GetBidVolumeFromGrouped(groupedFootprint, p - groupedTickSize);
                long diagonalAskAbove = GetAskVolumeFromGrouped(groupedFootprint, p + groupedTickSize);
                if (IsAskImbalanceDiagonal(ask, diagonalBidBelow)) m.AskImbalanceCount++;
                if (IsBidImbalanceDiagonal(bid, diagonalAskAbove)) m.BidImbalanceCount++;
                m.LevelCount++;
            }

            if (m.LevelCount == 0 || m.MinPrice == double.MaxValue)
                return m;

            CountStacks(groupedFootprint, m);
            if (signals != null)
            {
                m.Reversal = signals.DetectReversalCluster(barIndex, flow, m);
                m.PrimarySignal = signals.DetectPrimarySignal(barIndex, flow, m);
            }
            else
            {
                m.Reversal = new ReversalScore();
                m.PrimarySignal = new BarSignal();
            }

            m.Valid = true;
            FillMetricFingerprint(m, flow);
            return m;
        }

        private void CountStacks(Dictionary<double, OrderFlowMinuteProPriceLevelDataV8NoOutput> groupedFootprint, FlowMetrics m)
        {
            if (groupedFootprint == null || m == null || !m.Valid && m.LevelCount == 0)
                return;
            int askRun = 0;
            int bidRun = 0;
            double groupedTickSize = GetDisplayTickSize();
            double p = m.MinPrice;
            int guard = 0;
            while (p <= m.MaxPrice + groupedTickSize * 0.25 && guard < 5000)
            {
                OrderFlowMinuteProPriceLevelDataV8NoOutput level;
                double price = GetGroupedPrice(p, currentTickMultiplier);
                if (groupedFootprint.TryGetValue(price, out level) && level != null)
                {
                    long bid = level.SellVolume;
                    long ask = level.BuyVolume;
                    long total = bid + ask + (ShowUnclassifiedVolume ? level.UnclassifiedVolume : 0);
                    if (total >= StackMinVolume)
                    {
                        long diagonalBidBelow = GetBidVolumeFromGrouped(groupedFootprint, price - groupedTickSize);
                        long diagonalAskAbove = GetAskVolumeFromGrouped(groupedFootprint, price + groupedTickSize);
                        askRun = IsAskImbalanceDiagonal(ask, diagonalBidBelow) ? askRun + 1 : 0;
                        bidRun = IsBidImbalanceDiagonal(bid, diagonalAskAbove) ? bidRun + 1 : 0;
                        if (askRun == StackMinCount) m.AskStackCount++;
                        if (bidRun == StackMinCount) m.BidStackCount++;
                    }
                    else
                    {
                        askRun = 0;
                        bidRun = 0;
                    }
                }
                else
                {
                    askRun = 0;
                    bidRun = 0;
                }
                p += groupedTickSize;
                guard++;
            }
        }

        private void RebuildProfileIfNeeded(int dataCount)
        {
            if (CacheProfile && cache.Profile.Valid && cache.Profile.From == rs.From && cache.Profile.To == rs.To && cache.Profile.DataCount == dataCount && cache.Profile.ProfileMode == ProfileMode && cache.Profile.LookbackBars == ProfileLookbackBars)
                return;

            cache.Profile.Valid = false;
            cache.Profile.Prices.Clear();
            cache.Profile.Volumes.Clear();
            cache.Profile.ValueArea.Clear();
            cache.Profile.HVN.Clear();
            cache.Profile.LVN.Clear();
            cache.Profile.From = rs.From;
            cache.Profile.To = rs.To;
            cache.Profile.DataCount = dataCount;
            cache.Profile.ProfileMode = ProfileMode;
            cache.Profile.LookbackBars = ProfileLookbackBars;

            Dictionary<double, long> dict = new Dictionary<double, long>();
            int from = rs.From;
            int to = rs.To;
            if (ProfileMode == 2)
                from = Math.Max(0, to - ProfileLookbackBars + 1);
            else if (ProfileMode == 1)
                from = Math.Max(0, to - Math.Max(ProfileLookbackBars, rs.VisibleBars) + 1); // session approximation without session iterator dependency

            for (int i = from; i <= to; i++)
            {
                OrderFlowMinuteProOrderFlowDataV8NoOutput flow;
                if (!ofBars.FlowDataByBar.TryGetValue(i, out flow) || flow == null || flow.Footprint == null)
                    continue;
                foreach (KeyValuePair<double, OrderFlowMinuteProPriceLevelDataV8NoOutput> kv in flow.Footprint)
                {
                    if (kv.Value == null)
                        continue;
                    long total = kv.Value.BuyVolume + kv.Value.SellVolume + (ShowUnclassifiedVolume ? kv.Value.UnclassifiedVolume : 0);
                    if (total <= 0)
                        continue;
                    long old;
                    if (dict.TryGetValue(kv.Key, out old)) dict[kv.Key] = old + total;
                    else dict[kv.Key] = total;
                }
            }

            if (dict.Count == 0)
                return;

            double minP = double.MaxValue;
            double maxP = double.MinValue;
            foreach (double p in dict.Keys)
            {
                if (p < minP) minP = p;
                if (p > maxP) maxP = p;
            }

            long maxVol = 0;
            double poc = minP;
            long pocVol = 0;
            int guard = 0;
            for (double p = minP; p <= maxP + TickSize * 0.25 && guard < 10000; p += TickSize, guard++)
            {
                double rp = RoundToTick(p);
                long v;
                if (!dict.TryGetValue(rp, out v))
                    v = 0;
                cache.Profile.Prices.Add(rp);
                cache.Profile.Volumes.Add(v);
                if (v > maxVol) maxVol = v;
                if (v > pocVol)
                {
                    pocVol = v;
                    poc = rp;
                }
            }

            cache.Profile.MaxVolume = maxVol;
            cache.Profile.PocPrice = poc;
            cache.Profile.PocVolume = pocVol;
            CalculateValueAreaPocExpansion(cache.Profile);
            CalculateValueAreaBounds(cache.Profile);
            CalculateHvnLvn(cache.Profile);
            cache.Profile.Valid = true;
        }

        private void CalculateValueAreaPocExpansion(ProfileCache p)
        {
            if (p == null || p.Prices.Count == 0)
                return;

            long total = 0;
            for (int i = 0; i < p.Volumes.Count; i++) total += p.Volumes[i];
            long target = (long)(total * (ValueAreaPercent / 100.0));
            int pocIndex = 0;
            for (int i = 0; i < p.Prices.Count; i++)
            {
                if (Math.Abs(p.Prices[i] - p.PocPrice) < TickSize * 0.5)
                {
                    pocIndex = i;
                    break;
                }
            }

            int low = pocIndex;
            int high = pocIndex;
            long acc = p.Volumes[pocIndex];
            p.ValueArea.Add(p.Prices[pocIndex]);

            while (acc < target && (low > 0 || high < p.Prices.Count - 1))
            {
                long below = low > 0 ? p.Volumes[low - 1] : -1;
                long above = high < p.Prices.Count - 1 ? p.Volumes[high + 1] : -1;
                if (above >= below)
                {
                    high++;
                    acc += p.Volumes[high];
                    p.ValueArea.Add(p.Prices[high]);
                }
                else
                {
                    low--;
                    acc += p.Volumes[low];
                    p.ValueArea.Add(p.Prices[low]);
                }
            }
        }


        private void CalculateValueAreaBounds(ProfileCache p)
        {
            if (p == null || p.ValueArea == null || p.ValueArea.Count == 0)
                return;
            double lo = double.MaxValue;
            double hi = double.MinValue;
            foreach (double price in p.ValueArea)
            {
                if (price < lo) lo = price;
                if (price > hi) hi = price;
            }
            p.ValueAreaLow = lo == double.MaxValue ? 0 : lo;
            p.ValueAreaHigh = hi == double.MinValue ? 0 : hi;
        }

        private void CalculateHvnLvn(ProfileCache p)
        {
            if (p == null || p.Prices.Count < 3)
                return;
            int span = Math.Max(1, HvnLvnSensitivity);
            for (int i = span; i < p.Prices.Count - span; i++)
            {
                long v = p.Volumes[i];
                if (v <= 0)
                    continue;
                bool hvn = true;
                bool lvn = true;
                for (int j = i - span; j <= i + span; j++)
                {
                    if (j == i) continue;
                    if (p.Volumes[j] >= v) hvn = false;
                    if (p.Volumes[j] <= v && p.Volumes[j] > 0) lvn = false;
                }
                if (hvn) p.HVN.Add(p.Prices[i]);
                if (lvn) p.LVN.Add(p.Prices[i]);
            }
        }

        #endregion

        #region Renderers

        private void DrawInternalHeatmapCore(ChartControl chartControl, ChartScale chartScale)
        {
            if (!rs.CanDrawInternalCore || !ShowInternalHeatmapCore || InternalHeatmapCoreMode <= 0)
                return;
            if (ofBars == null || ofBars.FlowDataByBar == null || TickSize <= 0)
                return;

            long visibleMax = GetVisibleMaxNodeVolume();
            double noiseThreshold = InternalHeatNoiseThresholdPercent / 100.0;

            for (int i = rs.From; i <= rs.To; i++)
            {
                FlowMetrics m = GetCachedMetrics(i);
                if (m == null || !m.Valid)
                    continue;

                OrderFlowMinuteProOrderFlowDataV8NoOutput flow;
                if (!ofBars.FlowDataByBar.TryGetValue(i, out flow) || flow == null || flow.Footprint == null)
                    continue;

                float x = chartControl.GetXByBarIndex(ChartBars, i);
                float coreW = Math.Min(InternalHeatmapCoreMaxWidth, rs.BarWidth * (InternalHeatmapCoreWidthPercent / 100f));
                if (coreW < 2f)
                    continue;

                float cellH = Math.Max(2f, Math.Min(rs.CellHeight, rs.PixelsPerTick * 0.85f));
                long scaleMax = GetHeatmapScaleMax(m, visibleMax);
                int guard = 0;
                for (double p = m.MaxPrice; p >= m.MinPrice - TickSize * 0.25 && guard < 5000; p -= TickSize, guard++)
                {
                    double price = RoundToTick(p);
                    OrderFlowMinuteProPriceLevelDataV8NoOutput level;
                    if (!flow.Footprint.TryGetValue(price, out level) || level == null)
                        continue;

                    long total = GetPriceLevelTotal(level);
                    if (total <= 0)
                        continue;

                    double score = CalculateInternalHeatScore(i, price, level, flow, m, scaleMax);
                    if (HideInternalHeatmapNoise && score < noiseThreshold)
                        continue;

                    float y = chartScale.GetYByValue(price);
                    if (y < ChartPanel.Y - 20 || y > ChartPanel.Y + ChartPanel.H + 20)
                        continue;

                    DxBrush brush = GetInternalCoreBrush(level, m, price, score);
                    if (brush == null)
                        continue;

                    float w = Math.Max(1f, coreW * Clamp01((float)score));
                    DxRect rect = new DxRect(x - w * 0.5f, y - cellH * 0.5f, w, cellH);
                    RenderTarget.FillRectangle(rect, brush);

                    if (Math.Abs(price - m.PocPrice) < TickSize * 0.5 && internalPocCoreBrush != null && rs.DensityMode >= 2)
                        RenderTarget.DrawLine(new Vector2(x - coreW * 0.55f, y), new Vector2(x + coreW * 0.55f, y), internalPocCoreBrush, UxPresetMode == 1 ? 1.25f : 1.0f);
                }
            }
        }

        private double CalculateInternalHeatScore(int barIndex, double price, OrderFlowMinuteProPriceLevelDataV8NoOutput level, OrderFlowMinuteProOrderFlowDataV8NoOutput flow, FlowMetrics m, long scaleMax)
        {
            if (level == null || m == null || scaleMax <= 0)
                return 0;

            long total = GetPriceLevelTotal(level);
            if (total <= 0)
                return 0;

            double raw = total / (double)Math.Max(1, scaleMax);
            double gamma = Math.Max(0.50, Math.Min(2.50, HeatmapGammaX100 / 100.0));
            double volumeScore = Math.Pow(Math.Max(0.0, Math.Min(1.0, raw)), gamma);

            bool isPoc = Math.Abs(price - m.PocPrice) < TickSize * 0.5;
            bool isHvn = m.MaxNodeVolume > 0 && total >= m.MaxNodeVolume * (InternalHeatmapHvnPercent / 100.0);
            bool askImb = IsAskImbalance(level.SellVolume, level.BuyVolume);
            bool bidImb = IsBidImbalance(level.SellVolume, level.BuyVolume);
            bool persistent = IsPersistentNode(barIndex, price);

            if (InternalHeatmapCoreMode == 1)
                return Clamp01((float)volumeScore);

            if (InternalHeatmapCoreMode == 2)
                return Clamp01((float)volumeScore);

            if (InternalHeatmapCoreMode == 3)
            {
                if (!isPoc && !isHvn)
                    return 0;
                return Clamp01((float)(volumeScore + (isPoc ? 0.28 : 0.12)));
            }

            if (InternalHeatmapCoreMode == 4)
            {
                if (!persistent)
                    return 0;
                return Clamp01((float)(volumeScore + 0.18));
            }

            double score = volumeScore;
            if (isPoc) score += 0.20;
            if (isHvn) score += 0.12;
            if (askImb || bidImb) score += 0.10;
            if (persistent) score += 0.18;
            if (m.AskStackCount > 0 || m.BidStackCount > 0) score += 0.06;
            return Clamp01((float)score);
        }

        private bool IsPersistentNode(int barIndex, double price)
        {
            if (PersistentNodeLookbackBars <= 0 || TickSize <= 0 || ofBars == null || ofBars.FlowDataByBar == null)
                return false;

            int hits = 0;
            int minHits = Math.Max(1, PersistentNodeMinHits);
            int lookback = Math.Min(PersistentNodeLookbackBars, barIndex);
            int toleranceTicks = Math.Max(0, PersistentNodeMergeTicks);

            for (int i = 1; i <= lookback; i++)
            {
                int prevBar = barIndex - i;
                FlowMetrics pm = GetCachedMetrics(prevBar);
                if (pm == null || !pm.Valid || pm.MaxNodeVolume <= 0)
                    continue;

                OrderFlowMinuteProOrderFlowDataV8NoOutput prevFlow;
                if (!ofBars.FlowDataByBar.TryGetValue(prevBar, out prevFlow) || prevFlow == null || prevFlow.Footprint == null)
                    continue;

                bool matchedThisBar = false;
                for (int t = -toleranceTicks; t <= toleranceTicks; t++)
                {
                    double testPrice = RoundToTick(price + t * TickSize);
                    OrderFlowMinuteProPriceLevelDataV8NoOutput level;
                    if (prevFlow.Footprint.TryGetValue(testPrice, out level) && level != null)
                    {
                        long total = GetPriceLevelTotal(level);
                        if (total >= pm.MaxNodeVolume * (InternalHeatmapHvnPercent / 100.0))
                        {
                            matchedThisBar = true;
                            break;
                        }
                    }
                }

                if (matchedThisBar)
                {
                    hits++;
                    if (hits >= minHits)
                        return true;
                }
            }
            return false;
        }

        private DxBrush GetInternalCoreBrush(OrderFlowMinuteProPriceLevelDataV8NoOutput level, FlowMetrics m, double price, double score)
        {
            int idx = ClampInt((int)Math.Round(Clamp01((float)score) * (ClampInt(HeatmapLevels, 8, MaxHeatmapLevels) - 1)), 0, ClampInt(HeatmapLevels, 8, MaxHeatmapLevels) - 1);
            bool isPoc = m != null && Math.Abs(price - m.PocPrice) < TickSize * 0.5;
            bool persistent = m != null && IsPersistentNode(m.BarIndex, price);

            if (InternalHeatmapCoreMode == 3 && isPoc && internalPocCoreBrush != null)
                return internalPocCoreBrush;
            if (InternalHeatmapCoreMode == 4 && persistent && persistentCoreBrush != null)
                return persistentCoreBrush;
            if (InternalHeatmapCoreMode == 5 && isPoc && persistent && persistentCoreBrush != null)
                return persistentCoreBrush;
            if (InternalHeatmapCoreMode == 5 && isPoc && internalPocCoreBrush != null)
                return internalPocCoreBrush;

            if (InternalHeatmapCoreMode == 2 || InternalHeatmapCoreMode == 5)
            {
                if (IsAskImbalance(level.SellVolume, level.BuyVolume) || level.BuyVolume > level.SellVolume)
                    return internalBullHeatBrushes[idx];
                if (IsBidImbalance(level.SellVolume, level.BuyVolume) || level.SellVolume > level.BuyVolume)
                    return internalBearHeatBrushes[idx];
            }

            return internalNeutralHeatBrushes[idx];
        }

        private long GetPriceLevelTotal(OrderFlowMinuteProPriceLevelDataV8NoOutput level)
        {
            if (level == null)
                return 0;
            return level.BuyVolume + level.SellVolume + (ShowUnclassifiedVolume ? level.UnclassifiedVolume : 0);
        }

        private void DrawFootprintCells(ChartControl chartControl, ChartScale chartScale)
        {
            if (!rs.CanDrawFootprint)
                return;

            long visibleMax = GetVisibleMaxNodeVolume();
            double groupedTickSize = GetDisplayTickSize();
            for (int i = rs.From; i <= rs.To; i++)
            {
                FlowMetrics m = GetCachedMetrics(i);
                if (m == null || !m.Valid)
                    continue;
                OrderFlowMinuteProOrderFlowDataV8NoOutput flow;
                if (!ofBars.FlowDataByBar.TryGetValue(i, out flow) || flow == null || flow.Footprint == null)
                    continue;

                Dictionary<double, OrderFlowMinuteProPriceLevelDataV8NoOutput> groupedFootprint = BuildGroupedFootprint(flow);
                if (groupedFootprint == null || groupedFootprint.Count == 0)
                    continue;

                float x = chartControl.GetXByBarIndex(ChartBars, i);
                long scaleMax = GetHeatmapScaleMax(m, visibleMax);
                int guard = 0;
                for (double p = m.MaxPrice; p >= m.MinPrice - groupedTickSize * 0.25 && guard < 5000; p -= groupedTickSize, guard++)
                {
                    double price = GetGroupedPrice(p, currentTickMultiplier);
                    OrderFlowMinuteProPriceLevelDataV8NoOutput level;
                    if (!groupedFootprint.TryGetValue(price, out level) || level == null)
                        continue;

                    long bid = level.SellVolume;
                    long ask = level.BuyVolume;
                    long nodeTotal = bid + ask + (ShowUnclassifiedVolume ? level.UnclassifiedVolume : 0);
                    if (nodeTotal <= 0)
                        continue;

                    float y = chartScale.GetYByValue(price);
                    if (y < ChartPanel.Y - 20 || y > ChartPanel.Y + ChartPanel.H + 20)
                        continue;

                    float cellHeight = Math.Max(rs.CellHeight, Math.Min(32f, Math.Abs(chartScale.GetYByValue(price) - chartScale.GetYByValue(price + groupedTickSize))));
                    DxRect bidRect = new DxRect(x - rs.CellWidth, y - cellHeight * 0.5f, rs.CellWidth - 1f, cellHeight);
                    DxRect askRect = new DxRect(x + 1f, y - cellHeight * 0.5f, rs.CellWidth - 1f, cellHeight);

                    if (CellStyleMode == 3)
                    {
                        float bidW = rs.CellWidth * GetIntensity(bid, scaleMax);
                        float askW = rs.CellWidth * GetIntensity(ask, scaleMax);
                        if (bid > 0) bidW = Math.Max(1f, bidW);
                        if (ask > 0) askW = Math.Max(1f, askW);
                        FillCell(new DxRect(x - bidW, bidRect.Top, bidW, bidRect.Height), bidHeatBrushes[GetHeatIndex(bid, scaleMax)]);
                        FillCell(new DxRect(x + 1f, askRect.Top, askW, askRect.Height), askHeatBrushes[GetHeatIndex(ask, scaleMax)]);
                    }
                    else
                    {
                        FillCell(bidRect, bidHeatBrushes[GetHeatIndex(bid, scaleMax)]);
                        FillCell(askRect, askHeatBrushes[GetHeatIndex(ask, scaleMax)]);
                    }

                    if (ShowImbalanceMarkers && rs.CanDrawImbalance)
                    {
                        long diagonalBidBelow = GetBidVolumeFromGrouped(groupedFootprint, price - groupedTickSize);
                        long diagonalAskAbove = GetAskVolumeFromGrouped(groupedFootprint, price + groupedTickSize);
                        if (IsBidImbalanceDiagonal(bid, diagonalAskAbove)) DrawImbalanceMarker(bidRect, false);
                        if (IsAskImbalanceDiagonal(ask, diagonalBidBelow)) DrawImbalanceMarker(askRect, true);
                    }

                    if (rs.CanDrawGrid)
                    {
                        RenderTarget.DrawRectangle(bidRect, gridBrush, 0.35f);
                        RenderTarget.DrawRectangle(askRect, gridBrush, 0.35f);
                    }

                    if (rs.CanDrawNumbers)
                    {
                        if (bid > 0) DrawText(FormatVol(bid), bidRect, fontTiny, textBrush, TextAlignment.Center);
                        if (ask > 0) DrawText(FormatVol(ask), askRect, fontTiny, textBrush, TextAlignment.Center);
                    }

                    if (ShowUnclassifiedNodeMarker && level.UnclassifiedVolume > 0)
                        DrawUnclassifiedNodeMarker(x, y, level.UnclassifiedVolume);

                    if (rs.CanDrawPoc && Math.Abs(price - m.PocPrice) < groupedTickSize * 0.5)
                        DrawPoc(chartControl, chartScale, x, y, rs.CellWidth);
                }
            }
        }

        private void FillCell(DxRect rect, DxBrush brush)
        {
            if (brush == null || rect.Width <= 0 || rect.Height <= 0)
                return;
            if (EnableRoundedCells || CellStyleMode == 1 || CellStyleMode == 2)
            {
                float r = CellStyleMode == 2 ? rect.Height * 0.5f : CellCornerRadius;
                RenderTarget.FillRoundedRectangle(new DxRoundedRect { Rect = rect, RadiusX = r, RadiusY = r }, brush);
            }
            else
                RenderTarget.FillRectangle(rect, brush);
        }

        private void DrawPoc(ChartControl chartControl, ChartScale chartScale, float x, float y, float cellW)
        {
            if (UxPresetMode == 1)
            {
                float w = Math.Max(10f, Math.Min(cellW * 1.9f, 44f));
                RenderTarget.DrawLine(new Vector2(x - w * 0.5f, y), new Vector2(x + w * 0.5f, y), pocBrush, 1.4f);
                if (rs.DensityMode >= 4)
                    RenderTarget.FillEllipse(new Ellipse(new Vector2(x, y), PocMarkerSize, PocMarkerSize), pocBrush);
                return;
            }

            float w2 = Math.Max(8f, Math.Min(cellW * 1.7f, 42f));
            RenderTarget.DrawLine(new Vector2(x - w2 * 0.5f, y), new Vector2(x + w2 * 0.5f, y), pocBrush, Math.Max(1.2f, PocMarkerSize * 0.55f));
            if (rs.DensityMode >= 4)
                RenderTarget.FillEllipse(new Ellipse(new Vector2(x, y), PocMarkerSize, PocMarkerSize), pocBrush);
        }

        private void DrawImbalanceMarker(DxRect r, bool isAsk)
        {
            DxBrush b = isAsk ? askStrongBrush : bidStrongBrush;
            int style = ImbalanceMarkerStyle == 1 ? 2 : ImbalanceMarkerStyle;
            if (style == 0)
                RenderTarget.DrawRectangle(r, b, 1.05f);
            else if (style == 1)
            {
                // Vertical side rails next to bars are intentionally disabled.
                // Fallback to a small corner dot if this legacy style is selected.
                float x = isAsk ? r.Right - 3f : r.Left + 3f;
                RenderTarget.FillEllipse(new Ellipse(new Vector2(x, r.Top + 3f), 2.0f, 2.0f), b);
            }
            else if (style == 2)
            {
                float x = isAsk ? r.Right - 3f : r.Left + 3f;
                RenderTarget.FillEllipse(new Ellipse(new Vector2(x, r.Top + 3f), 2.0f, 2.0f), b);
            }
            else
            {
                float mid = (r.Top + r.Bottom) * 0.5f;
                if (isAsk)
                {
                    RenderTarget.DrawLine(new Vector2(r.Right - 6f, mid - 4f), new Vector2(r.Right - 2f, mid), b, 1.4f);
                    RenderTarget.DrawLine(new Vector2(r.Right - 6f, mid + 4f), new Vector2(r.Right - 2f, mid), b, 1.4f);
                }
                else
                {
                    RenderTarget.DrawLine(new Vector2(r.Left + 6f, mid - 4f), new Vector2(r.Left + 2f, mid), b, 1.4f);
                    RenderTarget.DrawLine(new Vector2(r.Left + 6f, mid + 4f), new Vector2(r.Left + 2f, mid), b, 1.4f);
                }
            }
        }

        private void DrawStackMarkers(ChartControl chartControl, ChartScale chartScale)
        {
            if (!rs.CanDrawStack)
                return;
            for (int i = rs.From; i <= rs.To; i++)
            {
                FlowMetrics m = GetCachedMetrics(i);
                if (m == null || !m.Valid)
                    continue;
                OrderFlowMinuteProOrderFlowDataV8NoOutput flow;
                if (!ofBars.FlowDataByBar.TryGetValue(i, out flow) || flow == null || flow.Footprint == null)
                    continue;
                float x = chartControl.GetXByBarIndex(ChartBars, i);
                int askRun = 0;
                int bidRun = 0;
                int guard = 0;
                for (double p = m.MinPrice; p <= m.MaxPrice + TickSize * 0.25 && guard < 5000; p += TickSize, guard++)
                {
                    double price = RoundToTick(p);
                    OrderFlowMinuteProPriceLevelDataV8NoOutput level;
                    if (!flow.Footprint.TryGetValue(price, out level) || level == null)
                    {
                        askRun = 0; bidRun = 0;
                        continue;
                    }
                    long bid = level.SellVolume;
                    long ask = level.BuyVolume;
                    long total = bid + ask;
                    if (total < StackMinVolume)
                    {
                        askRun = 0; bidRun = 0;
                        continue;
                    }
                    askRun = IsAskImbalance(bid, ask) ? askRun + 1 : 0;
                    bidRun = IsBidImbalance(bid, ask) ? bidRun + 1 : 0;
                    if (askRun >= StackMinCount || bidRun >= StackMinCount)
                    {
                        float y = chartScale.GetYByValue(price);
                        RenderTarget.FillEllipse(new Ellipse(new Vector2(x, y), 3.0f, 3.0f), askRun >= StackMinCount ? askStrongBrush : bidStrongBrush);
                    }
                }
            }
        }

        private void DrawReversalMarkers(ChartControl chartControl, ChartScale chartScale)
        {
            if (!ShowReversalClusters || !rs.CanDrawSignals || !ShowPriceLevelSignals)
                return;
            for (int i = rs.From; i <= rs.To; i++)
            {
                FlowMetrics m = GetCachedMetrics(i);
                if (m == null || !m.Valid || m.Reversal == null || !m.Reversal.IsValid)
                    continue;
                if (!ShowWeakReversals && m.Reversal.Score < MinReversalScore)
                    continue;
                DrawReversalSignal(chartControl, chartScale, i, m.Reversal);
            }
        }

        private void DrawReversalSignal(ChartControl chartControl, ChartScale chartScale, int barIndex, ReversalScore signal)
        {
            float x = chartControl.GetXByBarIndex(ChartBars, barIndex);
            float y = chartScale.GetYByValue(signal.Price);
            float halfW = Math.Max(7f, Math.Min(rs.CellWidth + SignalMarkerSize, rs.BarWidth * 0.56f));
            DxBrush main = signal.IsBullish ? bullReversalBrush : bearReversalBrush;
            bool strong = signal.Score >= StrongReversalThreshold;
            bool institutional = signal.Score >= InstitutionalReversalThreshold;

            if (EnableSoftGlow && institutional)
                RenderTarget.DrawLine(new Vector2(x - halfW, y), new Vector2(x + halfW, y), reversalGlowBrush, 8.0f);

            float stroke = institutional ? 3.4f : strong ? 2.5f : 1.4f;
            RenderTarget.DrawLine(new Vector2(x - halfW, y), new Vector2(x + halfW, y), main, stroke);

            if ((ReversalMarkerStyle == 1 || ReversalMarkerStyle == 2) && strong && rs.BarWidth >= 15)
            {
                float h = SignalMarkerSize + 3f;
                if (signal.IsBullish)
                {
                    RenderTarget.DrawLine(new Vector2(x - h, y + h), new Vector2(x, y + 1f), main, 1.8f);
                    RenderTarget.DrawLine(new Vector2(x, y + 1f), new Vector2(x + h, y + h), main, 1.8f);
                }
                else
                {
                    RenderTarget.DrawLine(new Vector2(x - h, y - h), new Vector2(x, y - 1f), main, 1.8f);
                    RenderTarget.DrawLine(new Vector2(x, y - 1f), new Vector2(x + h, y - h), main, 1.8f);
                }
            }

            if (institutional)
                RenderTarget.FillEllipse(new Ellipse(new Vector2(x, y), 3.2f, 3.2f), goldBrush);

            if (DebugMode && rs.BarWidth >= 42)
                DrawText(signal.Score.ToString(), new DxRect(x - 14f, y - 18f, 28f, 14f), fontTiny, goldBrush, TextAlignment.Center);
        }

        private void DrawProfile(ChartControl chartControl, ChartScale chartScale)
        {
            ProfileCache p = cache.Profile;
            if (p == null || !p.Valid || p.Prices.Count == 0 || p.MaxVolume <= 0)
                return;

            float panelW = Math.Max(44f, rs.ProfileWidth);
            float left;
            float right;
            if (ProfileSide == 1)
            {
                left = ChartPanel.X + 6f;
                right = left + panelW;
            }
            else if (ProfileSide == 2)
            {
                right = ChartPanel.X + ChartPanel.W - panelW - 24f;
                left = right - panelW;
            }
            else
            {
                right = ChartPanel.X + ChartPanel.W - 6f;
                left = right - panelW;
            }

            if (ShowProfileBackground)
                RenderTarget.FillRoundedRectangle(new DxRoundedRect { Rect = new DxRect(left - 3f, ChartPanel.Y + 8f, panelW + 6f, ChartPanel.H - 16f), RadiusX = 8f, RadiusY = 8f }, profileBgBrush);

            for (int i = 0; i < p.Prices.Count; i++)
            {
                long vol = p.Volumes[i];
                if (vol <= 0)
                    continue;
                double price = p.Prices[i];
                float y = chartScale.GetYByValue(price);
                if (y < ChartPanel.Y - 8 || y > ChartPanel.Y + ChartPanel.H + 8)
                    continue;
                float w = (float)(vol / (double)p.MaxVolume * panelW);
                DxRect r = ProfileSide == 1 ? new DxRect(left, y - 3.5f, w, 7f) : new DxRect(right - w, y - 3.5f, w, 7f);

                if (ShowValueArea && p.ValueArea.Contains(price))
                    RenderTarget.FillRectangle(new DxRect(left, y - 3.5f, panelW, 7f), profileValueAreaBrush);

                RenderTarget.FillRectangle(r, profileVolumeBrush);

                if (ShowHVN && p.HVN.Contains(price))
                    RenderTarget.DrawLine(new Vector2(r.Left, y), new Vector2(r.Right, y), hvnBrush, 1.2f);
                if (ShowLVN && p.LVN.Contains(price))
                    RenderTarget.DrawLine(new Vector2(left, y), new Vector2(right, y), lvnBrush, 0.8f);

                if (ShowProfilePoc && Math.Abs(price - p.PocPrice) < TickSize * 0.5)
                    RenderTarget.DrawLine(new Vector2(left, y), new Vector2(right, y), pocBrush, 1.4f);

                if (rs.CanDrawProfileNumbers && w > 42f)
                    DrawText(FormatVol(vol), r, fontTiny, textBrush, TextAlignment.Center);
            }
        }


        private void DrawValueAreaBoundaryLines(ChartControl chartControl, ChartScale chartScale)
        {
            if (!ShowProfile || !ShowValueAreaBoundaryLines || cache.Profile == null || !cache.Profile.Valid || cache.Profile.ValueArea.Count == 0)
                return;
            if (cache.Profile.ValueAreaHigh <= 0 || cache.Profile.ValueAreaLow <= 0)
                return;

            float x1 = ChartPanel.X + 6f;
            float x2 = ChartPanel.X + ChartPanel.W - 6f;
            float vahY = chartScale.GetYByValue(cache.Profile.ValueAreaHigh);
            float valY = chartScale.GetYByValue(cache.Profile.ValueAreaLow);
            RenderTarget.DrawLine(new Vector2(x1, vahY), new Vector2(x2, vahY), valueAreaBrush, 0.75f);
            RenderTarget.DrawLine(new Vector2(x1, valY), new Vector2(x2, valY), valueAreaBrush, 0.75f);
            if (rs.BarWidth >= 45 && rs.PixelsPerTick >= 5)
            {
                DrawText("VAH", new DxRect(x2 - 42f, vahY - 8f, 38f, 14f), fontTiny, mutedTextBrush, TextAlignment.Trailing);
                DrawText("VAL", new DxRect(x2 - 42f, valY - 8f, 38f, 14f), fontTiny, mutedTextBrush, TextAlignment.Trailing);
            }
        }

        private void DrawDeltaRibbon(ChartControl chartControl, ChartScale chartScale)
        {
            if (!ShowDeltaRibbon || !rs.CanDrawSignals)
                return;
            float y = rs.DeltaRibbonY;
            float h = 3f;
            for (int i = rs.From; i <= rs.To; i++)
            {
                FlowMetrics m = GetCachedMetrics(i);
                if (m == null || !m.Valid)
                    continue;
                float x = chartControl.GetXByBarIndex(ChartBars, i);
                float w = Math.Max(2f, Math.Min(rs.BarWidth * 0.65f, 10f));
                float intensity = UxPresetMode == 1 ? Clamp01((float)(Math.Abs(m.DeltaPercent) / 45.0)) : Clamp01((float)(Math.Abs(m.DeltaPercent) / 100.0));
                DxBrush b = m.Delta >= 0 ? bullBrush : bearBrush;
                RenderTarget.FillRectangle(new DxRect(x - w * 0.5f, y - h * intensity, w, Math.Max(1f, h * intensity)), b);
            }
        }

        private void DrawPocMigration(ChartControl chartControl, ChartScale chartScale)
        {
            if (!ShowPocMigration || rs.DensityMode < 2)
                return;
            FlowMetrics prev = null;
            for (int i = rs.From; i <= rs.To; i++)
            {
                FlowMetrics m = GetCachedMetrics(i);
                if (m == null || !m.Valid || m.PocPrice <= 0)
                    continue;
                float x = chartControl.GetXByBarIndex(ChartBars, i);
                float y = chartScale.GetYByValue(m.PocPrice);
                RenderTarget.FillEllipse(new Ellipse(new Vector2(x, y), 1.8f, 1.8f), pocBrush);
                if (prev != null && prev.Valid && prev.PocPrice > 0 && Math.Abs(prev.PocPrice - m.PocPrice) >= TickSize * 0.5)
                {
                    float px = chartControl.GetXByBarIndex(ChartBars, prev.BarIndex);
                    float py = chartScale.GetYByValue(prev.PocPrice);
                    RenderTarget.DrawLine(new Vector2(px, py), new Vector2(x, y), pocBrush, UxPresetMode == 1 ? 0.65f : 0.75f);
                }
                prev = m;
            }
        }

        private void DrawImbalanceLadder(ChartControl chartControl, ChartScale chartScale)
        {
            if (!ShowImbalanceLadder || !rs.CanDrawImbalance || (UxPresetMode == 1 && rs.DensityMode < 2))
                return;
            for (int i = rs.From; i <= rs.To; i++)
            {
                FlowMetrics m = GetCachedMetrics(i);
                if (m == null || !m.Valid)
                    continue;
                OrderFlowMinuteProOrderFlowDataV8NoOutput flow;
                if (!ofBars.FlowDataByBar.TryGetValue(i, out flow) || flow == null || flow.Footprint == null)
                    continue;
                float x = chartControl.GetXByBarIndex(ChartBars, i);
                DrawOneLadder(flow, m, x + rs.CellWidth + 3f, true, chartScale);
                DrawOneLadder(flow, m, x - rs.CellWidth - 3f, false, chartScale);
            }
        }

        private void DrawOneLadder(OrderFlowMinuteProOrderFlowDataV8NoOutput flow, FlowMetrics m, float x, bool askSide, ChartScale chartScale)
        {
            int run = 0;
            float firstY = 0;
            float lastY = 0;
            float stroke = UxPresetMode == 1 ? 1.15f : 1.4f;
            int guard = 0;
            for (double p = m.MinPrice; p <= m.MaxPrice + TickSize * 0.25 && guard < 5000; p += TickSize, guard++)
            {
                double price = RoundToTick(p);
                OrderFlowMinuteProPriceLevelDataV8NoOutput level;
                bool imb = false;
                if (flow.Footprint.TryGetValue(price, out level) && level != null)
                    imb = askSide ? IsAskImbalance(level.SellVolume, level.BuyVolume) : IsBidImbalance(level.SellVolume, level.BuyVolume);
                if (imb)
                {
                    float y = chartScale.GetYByValue(price);
                    if (run == 0) firstY = y;
                    lastY = y;
                    run++;
                }
                else
                {
                    if (run >= StackMinCount)
                        RenderTarget.DrawLine(new Vector2(x, firstY), new Vector2(x, lastY), askSide ? askStrongBrush : bidStrongBrush, stroke);
                    run = 0;
                }
            }
            if (run >= StackMinCount)
                RenderTarget.DrawLine(new Vector2(x, firstY), new Vector2(x, lastY), askSide ? askStrongBrush : bidStrongBrush, stroke);
        }

        private void DrawMicroLabels(ChartControl chartControl, ChartScale chartScale)
        {
            if (!ShowMicroLabels || rs.BarWidth < 58 || rs.PixelsPerTick < MinPixelsPerTickForNumbers)
                return;
            for (int i = rs.From; i <= rs.To; i++)
            {
                FlowMetrics m = GetCachedMetrics(i);
                if (m == null || !m.Valid)
                    continue;
                string label = "";
                if (m.Reversal != null && m.Reversal.IsValid)
                    label = m.Reversal.Score.ToString(CultureInfo.InvariantCulture);
                else if (Math.Abs(m.DeltaPercent) >= 30)
                    label = m.DeltaPercent.ToString("0", CultureInfo.InvariantCulture) + "%";
                if (string.IsNullOrEmpty(label))
                    continue;
                float x = chartControl.GetXByBarIndex(ChartBars, i);
                float y = chartScale.GetYByValue(m.PocPrice);
                DrawText(label, new DxRect(x - 15f, y - 22f, 30f, 14f), fontTiny, mutedTextBrush, TextAlignment.Center);
            }
        }

        private void DrawSignalStripes(ChartControl chartControl, ChartScale chartScale)
        {
            if (!ShowSignalStripes || !rs.CanDrawSignals)
                return;
            for (int i = rs.From; i <= rs.To; i++)
            {
                FlowMetrics m = GetCachedMetrics(i);
                if (m == null || !m.Valid || m.PrimarySignal == null || !m.PrimarySignal.HasSignal)
                    continue;
                DxBrush b = GetSignalBrush(m.PrimarySignal);
                float x = chartControl.GetXByBarIndex(ChartBars, i);
                float w = m.PrimarySignal.Type == 7 ? 3f : 2f;
                RenderTarget.FillRectangle(new DxRect(x - w * 0.5f, ChartPanel.Y, w, ChartPanel.H), b);
            }
        }

        private void DrawSignalLane(ChartControl chartControl, ChartScale chartScale)
        {
            if (!ShowSignalLane || !rs.CanDrawSignals)
                return;
            float y = rs.SignalLaneY;
            for (int i = rs.From; i <= rs.To; i++)
            {
                FlowMetrics m = GetCachedMetrics(i);
                if (m == null || !m.Valid || m.PrimarySignal == null || !m.PrimarySignal.HasSignal)
                    continue;
                float x = chartControl.GetXByBarIndex(ChartBars, i);
                DxBrush b = GetSignalBrush(m.PrimarySignal);
                float h = m.PrimarySignal.Type == 7 ? 7f : 4f;
                RenderTarget.FillRectangle(new DxRect(x - 2f, y - h, 4f, h), b);
            }
        }

        private void DrawBarStats(ChartControl chartControl, ChartScale chartScale)
        {
            if (!rs.CanDrawBarStats)
                return;
            bool compact = rs.BarWidth < 32;
            for (int i = rs.From; i <= rs.To; i++)
            {
                FlowMetrics m = GetCachedMetrics(i);
                if (m == null || !m.Valid)
                    continue;
                float x = chartControl.GetXByBarIndex(ChartBars, i);
                float y = compact ? rs.CompactStatsY : rs.FullStatsY;
                string text = "";
                if (compact)
                {
                    if (ShowSignal && m.PrimarySignal != null && m.PrimarySignal.HasSignal)
                        text = m.PrimarySignal.ShortLabel;
                    else if (ShowDeltaPercent)
                        text = m.DeltaPercent.ToString("0") + "%";
                }
                else
                {
                    if (ShowVolumeStats) text += "V " + FormatVol(m.TotalVolume) + "\n";
                    if (ShowUnclassifiedInStats && m.UnclassifiedVolume > 0) text += "U " + FormatVol(m.UnclassifiedVolume) + "\n";
                    if (ShowDeltaStats) text += "Δ " + m.Delta.ToString("N0") + "\n";
                    if (ShowDeltaPercent) text += m.DeltaPercent.ToString("0") + "%";
                    if (ShowSignal && m.PrimarySignal != null && m.PrimarySignal.HasSignal) text += "\n" + m.PrimarySignal.ShortLabel;
                }
                DrawText(text, compact ? new DxRect(x - 24f, y, 48f, 30f) : new DxRect(x - 32f, y, 64f, 60f), compact ? fontTiny : fontSmall, m.Delta >= 0 ? bullBrush : bearBrush, TextAlignment.Center);
            }
        }

        private void DrawStackZones(ChartControl chartControl, ChartScale chartScale)
        {
            List<StackZone> zones = KeepStackZonesPersistent ? cache.VisibleZones : cache.Zones;
            if (zones == null || zones.Count == 0 || ChartPanel == null || chartScale == null || RenderTarget == null || Bars == null || ChartBars == null)
                return;

            int drawn = 0;
            float visibleLeft = ChartPanel.X;
            float visibleRight = ChartPanel.X + ChartPanel.W;

            for (int i = 0; i < zones.Count && drawn < MaxVisibleStackZones; i++)
            {
                StackZone z = zones[i];
                if (z == null || z.IsManuallyExpired)
                    continue;
                if (InvalidateZonesOnCloseThrough && z.Invalidated)
                    continue;

                int startBar = ClampInt(z.CreatedBar >= 0 ? z.CreatedBar : z.StartBar, 0, Bars.Count - 1);
                int endBar = GetStackZoneRenderEndBar(z);

                float rawX1 = chartControl.GetXByBarIndex(ChartBars, startBar);
                float rawX2 = chartControl.GetXByBarIndex(ChartBars, endBar);
                if (rawX2 < rawX1)
                {
                    float tmp = rawX1;
                    rawX1 = rawX2;
                    rawX2 = tmp;
                }

                if (rawX2 < visibleLeft || rawX1 > visibleRight)
                    continue;

                float x1 = Math.Max(rawX1, visibleLeft);
                float x2 = Math.Min(rawX2, visibleRight);
                if (x2 - x1 < 2f)
                    continue;

                float yTop = chartScale.GetYByValue(z.ToPrice);
                float yBottom = chartScale.GetYByValue(z.FromPrice);
                float top = Math.Min(yTop, yBottom);
                float height = Math.Max(3f, Math.Abs(yBottom - yTop));
                float yMid = chartScale.GetYByValue(GetZoneMidPrice(z));

                if (top > ChartPanel.Y + ChartPanel.H + 10 || top + height < ChartPanel.Y - 10)
                    continue;

                int age = Math.Max(0, rs.To - z.CreatedBar);
                int alphaIndex = 7;
                if (EnableZoneDecay)
                    alphaIndex = ClampInt(9 - (int)(age / Math.Max(1.0, ZoneDecayBars / 8.0)), 1, 9);
                DxBrush fill = z.IsBuy ? buyZoneBrushes[alphaIndex] : sellZoneBrushes[alphaIndex];
                DxBrush line = z.IsBuy ? buyZoneLineBrush : sellZoneLineBrush;

                RenderTarget.FillRectangle(new DxRect(x1, top, x2 - x1, height), fill);

                if (ShowStackZoneCenterLine && line != null)
                    RenderTarget.DrawLine(new Vector2(x1, yMid), new Vector2(x2, yMid), line, Math.Max(1f, StackZoneLineWidth));

                if (ShowStackZoneReactionMarker && z.HasReaction)
                    DrawStackZoneReactionMarker(chartControl, chartScale, z, visibleLeft, visibleRight);

                drawn++;
            }
        }

        private void DrawLegend(ChartControl chartControl, ChartScale chartScale)
        {
            if (!ShowLegend)
                return;
            if (AutoHideLegendOnSmallChart && (ChartPanel.W < 520 || ChartPanel.H < 240))
                return;

            string heatmapBadge = "Hybrid Heatmap + Internal Core";
            string line1 = "[OrderFlow V5] [" + GetPresetName() + "] [" + GetThemeName() + "] [Density: " + GetDensityName(rs.DensityMode) + "] [" + heatmapBadge + "]";
            string line2 = ShowExtendedLegend ? "Visible " + rs.VisibleBars + " | Heatmap " + HeatmapLevels + "L γ" + (HeatmapGammaX100 / 100.0).ToString("0.00", CultureInfo.InvariantCulture) + " | " + (HeatmapScaleMode == 3 ? "Hybrid scale" : "Scale " + HeatmapScaleMode.ToString(CultureInfo.InvariantCulture)) + " | Core M" + InternalHeatmapCoreMode.ToString(CultureInfo.InvariantCulture) + " | tick-rule approximation" : "";
            float desiredW = ShowExtendedLegend ? 660f : 440f;
            float w = Math.Min(desiredW, Math.Max(240f, ChartPanel.W - 24f));
            float h = ShowExtendedLegend ? 46f : 26f;
            float x = ChartPanel.X + 12f;
            float y = ChartPanel.Y + 12f;
            if (LegendPosition == 1) x = ChartPanel.X + ChartPanel.W - w - 12f;
            if (LegendPosition == 2) y = ChartPanel.Y + ChartPanel.H - h - 16f;
            if (LegendPosition == 3) { x = ChartPanel.X + ChartPanel.W - w - 12f; y = ChartPanel.Y + ChartPanel.H - h - 16f; }

            DxRect r = new DxRect(x, y, w, h);
            RenderTarget.FillRoundedRectangle(new DxRoundedRect { Rect = r, RadiusX = 9, RadiusY = 9 }, panelBrush);
            RenderTarget.DrawRoundedRectangle(new DxRoundedRect { Rect = r, RadiusX = 9, RadiusY = 9 }, panelBorderBrush, 1f);
            DrawText(line1 + (ShowExtendedLegend ? "\n" + line2 : ""), new DxRect(r.Left + 10f, r.Top + 3f, r.Width - 20f, r.Height - 6f), fontTiny, mutedTextBrush, TextAlignment.Leading);
        }

        private void DrawCompactHint()
        {
            string text = "Footprint rejtve: túl sűrű chart / kevés pixel per tick. Density: " + GetDensityName(rs.DensityMode) + " | BarWidth " + rs.BarWidth.ToString("0.0") + " | px/tick " + rs.PixelsPerTick.ToString("0.0");
            DxRect r = new DxRect(ChartPanel.X + 12f, ChartPanel.Y + ChartPanel.H - 34f, Math.Min(760f, ChartPanel.W - 24f), 24f);
            RenderTarget.FillRoundedRectangle(new DxRoundedRect { Rect = r, RadiusX = 8, RadiusY = 8 }, panelBrush);
            DrawText(text, new DxRect(r.Left + 8f, r.Top, r.Width - 16f, r.Height), fontTiny, warningBrush, TextAlignment.Leading);
        }

        private void DrawWarning(string message)
        {
            DxRect r = new DxRect(ChartPanel.X + 20f, ChartPanel.Y + 20f, Math.Min(720f, ChartPanel.W - 40f), 46f);
            RenderTarget.FillRoundedRectangle(new DxRoundedRect { Rect = r, RadiusX = 10, RadiusY = 10 }, panelBrush);
            RenderTarget.DrawRoundedRectangle(new DxRoundedRect { Rect = r, RadiusX = 10, RadiusY = 10 }, panelBorderBrush, 1f);
            DrawText(message, r, fontNormal, warningBrush, TextAlignment.Center);
        }

        #endregion

        #region Zones

        private void RebuildZonesIfNeeded(int dataCount)
        {
            if (!ShowStackZones)
            {
                if (cache.VisibleZones != null) cache.VisibleZones.Clear();
                return;
            }

            if (KeepStackZonesPersistent)
                UpdatePersistentStackZones(dataCount);
            else
                RebuildZones();
        }

        private void UpdatePersistentStackZones(int dataCount)
        {
            if (!ShowStackZones || ofBars == null || Bars == null || ofBars.FlowDataByBar == null)
                return;

            int end = Math.Min(Bars.Count - 1, rs.To);
            if (end < 0)
                return;

            int start = Math.Max(0, cache.LastProcessedZoneBar + 1);
            if (cache.LastProcessedZoneBar < 0 || cache.AllZones.Count == 0 || start > end)
                start = Math.Max(0, end - StackZoneLookbackBars + 1);

            for (int i = start; i <= end; i++)
            {
                FlowMetrics m = GetCachedMetrics(i);
                if (m == null || !m.Valid)
                    continue;
                OrderFlowMinuteProOrderFlowDataV8NoOutput flow;
                if (!ofBars.FlowDataByBar.TryGetValue(i, out flow) || flow == null || flow.Footprint == null)
                    continue;

                DetectZonesForBar(i, flow, m, true);
                DetectZonesForBar(i, flow, m, false);
            }

            cache.LastProcessedZoneBar = Math.Max(cache.LastProcessedZoneBar, end);
            UpdatePersistentZoneStates();
            TrimPersistentZones();
            BuildVisibleZonesForRender();
            cache.LastZonesDataCount = dataCount;
        }

        private void RebuildZones()
        {
            cache.Zones.Clear();
            if (!ShowStackZones || ofBars == null)
                return;

            int from = Math.Max(0, rs.To - StackZoneLookbackBars + 1);
            for (int i = from; i <= rs.To; i++)
            {
                FlowMetrics m = GetCachedMetrics(i);
                if (m == null || !m.Valid)
                    continue;
                OrderFlowMinuteProOrderFlowDataV8NoOutput flow;
                if (!ofBars.FlowDataByBar.TryGetValue(i, out flow) || flow == null || flow.Footprint == null)
                    continue;
                DetectZonesForBar(i, flow, m, true);
                DetectZonesForBar(i, flow, m, false);
            }

            if (MergeNearbyZones)
                MergeZones(cache.Zones);
            for (int i = 0; i < cache.Zones.Count; i++)
                UpdateZoneState(cache.Zones[i]);
            cache.Zones.Sort(delegate(StackZone a, StackZone b) { return b.Strength.CompareTo(a.Strength); });
            if (cache.Zones.Count > MaxVisibleStackZones * 3)
                cache.Zones.RemoveRange(MaxVisibleStackZones * 3, cache.Zones.Count - MaxVisibleStackZones * 3);
        }

        private void DetectZonesForBar(int barIndex, OrderFlowMinuteProOrderFlowDataV8NoOutput flow, FlowMetrics m, bool askStack)
        {
            int run = 0;
            double start = 0;
            double last = 0;
            long vol = 0;
            double ratioSum = 0;
            int guard = 0;
            for (double p = m.MinPrice; p <= m.MaxPrice + TickSize * 0.25 && guard < 5000; p += TickSize, guard++)
            {
                double price = RoundToTick(p);
                OrderFlowMinuteProPriceLevelDataV8NoOutput level;
                bool imb = false;
                double ratio = 0;
                long total = 0;
                if (flow.Footprint.TryGetValue(price, out level) && level != null)
                {
                    long bid = level.SellVolume;
                    long ask = level.BuyVolume;
                    total = bid + ask + (ShowUnclassifiedVolume ? level.UnclassifiedVolume : 0);
                    if (total >= StackMinVolume)
                    {
                        imb = askStack ? IsAskImbalance(bid, ask) : IsBidImbalance(bid, ask);
                        ratio = askStack ? SafeRatio(ask, bid) : SafeRatio(bid, ask);
                    }
                }

                if (imb)
                {
                    if (run == 0) { start = price; vol = 0; ratioSum = 0; }
                    run++;
                    last = price;
                    vol += total;
                    ratioSum += ratio;
                }
                else
                {
                    if (run >= StackMinCount)
                        AddZone(start, last, askStack, barIndex, run, vol, ratioSum / Math.Max(1, run));
                    run = 0; vol = 0; ratioSum = 0;
                }
            }
            if (run >= StackMinCount)
                AddZone(start, last, askStack, barIndex, run, vol, ratioSum / Math.Max(1, run));
        }

        private void AddZone(double start, double end, bool isBuy, int barIndex, int count, long vol, double ratio)
        {
            double from = Math.Min(start, end);
            double to = Math.Max(start, end);
            if (Math.Abs(to - from) < TickSize)
                to = from + TickSize;

            int recency = Math.Max(1, StackZoneLookbackBars - Math.Max(0, rs.To - barIndex));
            int strength = count * 100 + (int)Math.Min(5000, vol / 10) + (int)Math.Min(500, ratio * 20);
            if (ZoneStrengthMode == 2)
                strength += recency * 5;
            if (strength < MinZoneStrength)
                return;

            StackZone candidate = new StackZone
            {
                Id = cache.NextZoneId++,
                FromPrice = from,
                ToPrice = to,
                IsBuy = isBuy,
                StartBar = barIndex,
                EndBar = Math.Min(Bars.Count - 1, barIndex + StackZoneProjectionBars),
                CreatedBar = barIndex,
                LastSeenBar = barIndex,
                TouchCount = 0,
                ReactionBar = -1,
                ReactionPrice = 0,
                HasReaction = false,
                ReactionConfirmed = false,
                ReactionType = 0,
                FirstTouchBar = -1,
                LastTouchBar = -1,
                IsPersistent = KeepStackZonesPersistent,
                Volume = vol,
                StackCount = count,
                AvgRatio = ratio,
                Strength = strength
            };

            if (KeepStackZonesPersistent)
                AddOrMergePersistentZone(candidate);
            else
                cache.Zones.Add(candidate);
        }

        private void AddOrMergePersistentZone(StackZone candidate)
        {
            if (candidate == null)
                return;

            double tolerance = ZoneMergeTicks * TickSize;
            for (int i = 0; i < cache.AllZones.Count; i++)
            {
                StackZone existing = cache.AllZones[i];
                if (existing == null || existing.IsManuallyExpired || existing.IsBuy != candidate.IsBuy)
                    continue;

                bool overlap = !(candidate.FromPrice > existing.ToPrice + tolerance || candidate.ToPrice < existing.FromPrice - tolerance);
                if (!overlap)
                    continue;

                existing.FromPrice = Math.Min(existing.FromPrice, candidate.FromPrice);
                existing.ToPrice = Math.Max(existing.ToPrice, candidate.ToPrice);
                existing.EndBar = Math.Max(existing.EndBar, candidate.EndBar);
                existing.LastSeenBar = Math.Max(existing.LastSeenBar, candidate.StartBar);
                existing.Volume += candidate.Volume;
                existing.StackCount += candidate.StackCount;
                existing.Strength = Math.Max(existing.Strength, candidate.Strength) + Math.Min(250, candidate.Strength / 10);
                existing.AvgRatio = (existing.AvgRatio + candidate.AvgRatio) * 0.5;
                existing.IsPersistent = true;
                return;
            }

            candidate.IsPersistent = true;
            cache.AllZones.Add(candidate);
        }

        private void UpdatePersistentZoneStates()
        {
            if (cache.AllZones == null || cache.AllZones.Count == 0 || Bars == null)
                return;
            for (int i = 0; i < cache.AllZones.Count; i++)
                UpdateZoneState(cache.AllZones[i]);
        }

        private void TrimPersistentZones()
        {
            if (cache.AllZones == null)
                return;

            int minBar = Math.Max(0, rs.To - PersistentZoneMaxBars);
            for (int i = cache.AllZones.Count - 1; i >= 0; i--)
            {
                StackZone z = cache.AllZones[i];
                if (z == null || z.IsManuallyExpired || z.LastSeenBar < minBar)
                    cache.AllZones.RemoveAt(i);
            }

            cache.AllZones.Sort(delegate(StackZone a, StackZone b)
            {
                int s = b.Strength.CompareTo(a.Strength);
                if (s != 0) return s;
                return b.LastSeenBar.CompareTo(a.LastSeenBar);
            });

            if (cache.AllZones.Count > MaxStoredStackZones)
                cache.AllZones.RemoveRange(MaxStoredStackZones, cache.AllZones.Count - MaxStoredStackZones);
        }

        private void BuildVisibleZonesForRender()
        {
            cache.VisibleZones.Clear();
            if (cache.AllZones == null || cache.AllZones.Count == 0)
                return;

            for (int i = 0; i < cache.AllZones.Count; i++)
            {
                StackZone z = cache.AllZones[i];
                if (z == null || z.IsManuallyExpired)
                    continue;
                if (InvalidateZonesOnCloseThrough && z.Invalidated)
                    continue;
                z.IsVisible = true;
                cache.VisibleZones.Add(z);
            }

            cache.VisibleZones.Sort(delegate(StackZone a, StackZone b)
            {
                int s = b.Strength.CompareTo(a.Strength);
                if (s != 0) return s;
                return b.LastSeenBar.CompareTo(a.LastSeenBar);
            });

            if (cache.VisibleZones.Count > MaxVisibleStackZones)
                cache.VisibleZones.RemoveRange(MaxVisibleStackZones, cache.VisibleZones.Count - MaxVisibleStackZones);

            cache.Zones.Clear();
            cache.Zones.AddRange(cache.VisibleZones);
        }

        private void MergeZones(List<StackZone> zones)
        {
            if (zones == null)
                return;
            double tolerance = ZoneMergeTicks * TickSize;
            for (int i = 0; i < zones.Count; i++)
            {
                StackZone a = zones[i];
                if (a == null) continue;
                for (int j = zones.Count - 1; j > i; j--)
                {
                    StackZone b = zones[j];
                    if (b == null || a.IsBuy != b.IsBuy) continue;
                    bool overlap = !(b.FromPrice > a.ToPrice + tolerance || b.ToPrice < a.FromPrice - tolerance);
                    if (!overlap) continue;
                    a.FromPrice = Math.Min(a.FromPrice, b.FromPrice);
                    a.ToPrice = Math.Max(a.ToPrice, b.ToPrice);
                    a.StartBar = Math.Min(a.StartBar, b.StartBar);
                    a.CreatedBar = Math.Min(a.CreatedBar, b.CreatedBar);
                    a.LastSeenBar = Math.Max(a.LastSeenBar, b.LastSeenBar);
                    a.EndBar = Math.Max(a.EndBar, b.EndBar);
                    a.Volume += b.Volume;
                    a.StackCount += b.StackCount;
                    a.Strength += b.Strength;
                    zones.RemoveAt(j);
                }
            }
        }

        private void UpdateZoneState(StackZone z)
        {
            if (z == null || Bars == null)
                return;

            // Reaction only determines the visual end of the line. It does not invalidate/delete the zone.
            DetectFirstZoneReaction(z);

            if (!InvalidateZonesOnCloseThrough)
                return;

            int start = Math.Max(z.CreatedBar + 1, 0);
            int end = Math.Min(rs.To, Bars.Count - 1);
            double tol = ZoneInvalidationTicks * TickSize;
            for (int i = start; i <= end; i++)
            {
                double c = Bars.GetClose(i);
                if (z.IsBuy && c < z.FromPrice - tol) { z.Invalidated = true; return; }
                if (!z.IsBuy && c > z.ToPrice + tol) { z.Invalidated = true; return; }
            }
        }

        private void DetectFirstZoneReaction(StackZone z)
        {
            if (z == null || z.HasReaction || Bars == null || TickSize <= 0)
                return;

            double tol = StackZoneReactionToleranceTicks * TickSize;
            int start = Math.Max(z.CreatedBar + 1, z.StartBar + 1);
            int end = Math.Min(Bars.Count - 1, rs.To);
            if (start > end)
                return;

            for (int i = start; i <= end; i++)
            {
                double h = Bars.GetHigh(i);
                double l = Bars.GetLow(i);
                double c = Bars.GetClose(i);
                double mid = GetZoneMidPrice(z);

                bool touch = h >= z.FromPrice - tol && l <= z.ToPrice + tol;
                bool closeInto = c >= z.FromPrice - tol && c <= z.ToPrice + tol;
                bool wickReject = z.IsBuy
                    ? (l <= z.ToPrice + tol && c >= mid)
                    : (h >= z.FromPrice - tol && c <= mid);

                bool reaction = false;
                int reactionType = 0;

                if (StackZoneReactionDetectionMode == 0 && touch)
                {
                    reaction = true;
                    reactionType = 1;
                }
                else if (StackZoneReactionDetectionMode == 1 && closeInto)
                {
                    reaction = true;
                    reactionType = 2;
                }
                else if (StackZoneReactionDetectionMode == 2 && wickReject)
                {
                    reaction = true;
                    reactionType = 3;
                }
                else if (StackZoneReactionDetectionMode == 3 && (touch || wickReject))
                {
                    reaction = true;
                    reactionType = wickReject ? 3 : 1;
                }

                if (reaction)
                {
                    z.HasReaction = true;
                    z.ReactionConfirmed = true;
                    z.ReactionBar = i;
                    z.ReactionPrice = mid;
                    z.ReactionType = reactionType;
                    z.Retested = true;
                    z.FirstTouchBar = i;
                    z.LastTouchBar = i;
                    z.TouchCount = Math.Max(1, z.TouchCount + 1);
                    z.LastSeenBar = Math.Max(z.LastSeenBar, i);
                    return;
                }
            }
        }

        private int GetStackZoneRenderEndBar(StackZone z)
        {
            if (z == null || Bars == null || Bars.Count <= 0)
                return 0;

            if (StackZoneLineSpanMode == 1 && StopStackZoneAtFirstReaction && z.HasReaction && z.ReactionBar >= 0)
                return ClampInt(z.ReactionBar, 0, Bars.Count - 1);

            if (StackZoneLineSpanMode == 0)
                return ClampInt(z.EndBar, 0, Bars.Count - 1);

            if (StackZoneLineSpanMode == 2)
                return ClampInt(rs.To, 0, Bars.Count - 1);

            int projected = ClampInt(z.EndBar, 0, Bars.Count - 1);
            int visibleRight = ClampInt(rs.To, 0, Bars.Count - 1);
            return Math.Max(projected, visibleRight);
        }

        private void DrawStackZoneReactionMarker(ChartControl chartControl, ChartScale chartScale, StackZone z, float visibleLeft, float visibleRight)
        {
            if (z == null || !z.HasReaction || z.ReactionBar < 0 || chartControl == null || chartScale == null || RenderTarget == null)
                return;
            int rb = ClampInt(z.ReactionBar, 0, Bars.Count - 1);
            float rx = chartControl.GetXByBarIndex(ChartBars, rb);
            if (rx < visibleLeft || rx > visibleRight)
                return;
            float ry = chartScale.GetYByValue(GetZoneMidPrice(z));
            DxBrush b = z.IsBuy ? buyZoneLineBrush : sellZoneLineBrush;
            float r = Math.Max(1f, StackZoneReactionMarkerSize);
            if (b != null)
                RenderTarget.FillEllipse(new Ellipse(new Vector2(rx, ry), r, r), b);
            if (goldBrush != null)
                RenderTarget.DrawEllipse(new Ellipse(new Vector2(rx, ry), r + 1f, r + 1f), goldBrush, 0.9f);
        }

        private double GetZoneMidPrice(StackZone z)
        {
            if (z == null)
                return 0;
            return (z.FromPrice + z.ToPrice) * 0.5;
        }
        #endregion

        #region Helpers / signal math

        private long GetClassifiedVolume(OrderFlowMinuteProOrderFlowDataV8NoOutput flow)
        {
            if (flow == null)
                return 0;
            return flow.BuyVolume + flow.SellVolume;
        }

        private long GetDisplayTotalVolume(OrderFlowMinuteProOrderFlowDataV8NoOutput flow)
        {
            if (flow == null)
                return 0;
            return flow.BuyVolume + flow.SellVolume + (ShowUnclassifiedVolume ? flow.UnclassifiedVolume : 0);
        }

        private double GetDeltaPercent(OrderFlowMinuteProOrderFlowDataV8NoOutput flow)
        {
            if (flow == null)
                return 0;
            long denominator = DeltaPercentMode == 0 ? GetClassifiedVolume(flow) : GetDisplayTotalVolume(flow);
            return denominator > 0 ? flow.Delta / (double)denominator * 100.0 : 0.0;
        }

        private long GetSessionApproxMaxNodeVolume()
        {
            long max = 1;
            int from = Math.Max(0, rs.To - Math.Max(ProfileLookbackBars, rs.VisibleBars * 2));
            int to = rs.To;
            for (int i = from; i <= to; i++)
            {
                FlowMetrics m = GetCachedMetrics(i);
                if (m != null && m.Valid && m.MaxNodeVolume > max)
                    max = m.MaxNodeVolume;
            }
            return max;
        }

        private void ComputeLayoutLanes()
        {
            rs.DeltaRibbonY = ChartPanel.Y + ChartPanel.H - 4f;
            rs.SignalLaneY = ChartPanel.Y + ChartPanel.H - 12f;
            rs.CompactStatsY = ChartPanel.Y + ChartPanel.H - 36f;
            rs.FullStatsY = ChartPanel.Y + ChartPanel.H - 62f;
        }

        private void DrawUnclassifiedNodeMarker(float x, float y, long unclassifiedVolume)
        {
            if (unclassifiedVolume <= 0 || unclassifiedBrush == null || rs.DensityMode < 3)
                return;
            RenderTarget.FillEllipse(new Ellipse(new Vector2(x, y), 1.6f, 1.6f), unclassifiedBrush);
        }

        private long GetVisibleMaxNodeVolume()
        {
            long max = 1;
            for (int i = rs.From; i <= rs.To; i++)
            {
                FlowMetrics m = GetCachedMetrics(i);
                if (m != null && m.Valid && m.MaxNodeVolume > max)
                    max = m.MaxNodeVolume;
            }
            return max;
        }

        private long GetHeatmapScaleMax(FlowMetrics m, long visibleMax)
        {
            if (m == null)
                return Math.Max(1, visibleMax);

            long localMax = Math.Max(1, m.MaxNodeVolume);
            long globalMax = Math.Max(1, visibleMax);

            if (HeatmapScaleMode == 1)
                return globalMax;

            if (HeatmapScaleMode == 2)
                return Math.Max(1, GetSessionApproxMaxNodeVolume());

            if (HeatmapScaleMode == 3)
            {
                // Hybrid+: combines local bar structure and visible context.
                // Heatmap Max intentionally reveals both micro-structure and relative importance.
                double localWeight = UxPresetMode == 1 ? 0.55 : 0.50;
                double globalWeight = 1.0 - localWeight;
                return Math.Max(1, (long)(localMax * localWeight + globalMax * globalWeight));
            }

            return localMax;
        }

        private int GetHeatIndex(long volume, long max)
        {
            int levels = ClampInt(HeatmapLevels, 8, MaxHeatmapLevels);
            if (volume <= 0 || max <= 0)
                return 0;
            double raw = volume / (double)max;
            double gamma = Math.Max(0.50, Math.Min(2.50, HeatmapGammaX100 / 100.0));
            double intensity = Math.Pow(Math.Max(0.0, Math.Min(1.0, raw)), gamma);
            int idx = (int)Math.Round(intensity * (levels - 1));
            return ClampInt(idx, 0, levels - 1);
        }

        private float GetIntensity(long volume, long max)
        {
            if (volume <= 0 || max <= 0)
                return 0f;
            // Heatmap Max intentionally uses gamma below 1.0 to reveal smaller liquidity participation, not only dominant nodes.
            double gamma = Math.Max(0.50, Math.Min(2.50, HeatmapGammaX100 / 100.0));
            return (float)Math.Pow(Math.Max(0.0, Math.Min(1.0, volume / (double)max)), gamma);
        }

        private bool HasAskStackAwayFromLow(OrderFlowMinuteProOrderFlowDataV8NoOutput flow, double lowPrice)
        {
            int count = 0;
            int maxTicks = Math.Max(1, ReversalExtremeTicks + StackMinCount + 1);
            for (int i = 0; i <= maxTicks; i++)
            {
                double p = RoundToTick(lowPrice + i * TickSize);
                OrderFlowMinuteProPriceLevelDataV8NoOutput level;
                if (!flow.Footprint.TryGetValue(p, out level) || level == null)
                {
                    count = 0;
                    continue;
                }
                long bid = level.SellVolume;
                long ask = level.BuyVolume;
                if (bid + ask < StackMinVolume) { count = 0; continue; }
                count = IsAskImbalance(bid, ask) ? count + 1 : 0;
                if (count >= StackMinCount) return true;
            }
            return false;
        }

        private bool HasBidStackAwayFromHigh(OrderFlowMinuteProOrderFlowDataV8NoOutput flow, double highPrice)
        {
            int count = 0;
            int maxTicks = Math.Max(1, ReversalExtremeTicks + StackMinCount + 1);
            for (int i = 0; i <= maxTicks; i++)
            {
                double p = RoundToTick(highPrice - i * TickSize);
                OrderFlowMinuteProPriceLevelDataV8NoOutput level;
                if (!flow.Footprint.TryGetValue(p, out level) || level == null)
                {
                    count = 0;
                    continue;
                }
                long bid = level.SellVolume;
                long ask = level.BuyVolume;
                if (bid + ask < StackMinVolume) { count = 0; continue; }
                count = IsBidImbalance(bid, ask) ? count + 1 : 0;
                if (count >= StackMinCount) return true;
            }
            return false;
        }

        private int GetActiveTickMultiplier()
        {
            if (AssetProfile == InstrumentProfile.NQ_HighVolatility)
                return 4;
            if (AssetProfile == InstrumentProfile.Custom)
                return ClampInt(CustomPriceGroupTicks, 1, 16);
            return 1;
        }

        private double GetDisplayTickSize()
        {
            return Math.Max(TickSize, TickSize * Math.Max(1, currentTickMultiplier));
        }

        private double GetGroupedPrice(double price, int multiplier)
        {
            if (TickSize <= 0 || multiplier <= 1)
                return RoundToTick(price);
            double groupedTickSize = TickSize * multiplier;
            return Math.Floor((price / groupedTickSize) + 1e-10) * groupedTickSize;
        }

        private Dictionary<double, OrderFlowMinuteProPriceLevelDataV8NoOutput> BuildGroupedFootprint(OrderFlowMinuteProOrderFlowDataV8NoOutput flow)
        {
            Dictionary<double, OrderFlowMinuteProPriceLevelDataV8NoOutput> grouped = new Dictionary<double, OrderFlowMinuteProPriceLevelDataV8NoOutput>();
            if (flow == null || flow.Footprint == null)
                return grouped;

            int multiplier = Math.Max(1, currentTickMultiplier);
            foreach (KeyValuePair<double, OrderFlowMinuteProPriceLevelDataV8NoOutput> kv in flow.Footprint)
            {
                OrderFlowMinuteProPriceLevelDataV8NoOutput src = kv.Value;
                if (src == null)
                    continue;
                double groupedPrice = GetGroupedPrice(kv.Key, multiplier);
                OrderFlowMinuteProPriceLevelDataV8NoOutput dst;
                if (!grouped.TryGetValue(groupedPrice, out dst) || dst == null)
                {
                    dst = new OrderFlowMinuteProPriceLevelDataV8NoOutput();
                    grouped[groupedPrice] = dst;
                }
                dst.BuyVolume += src.BuyVolume;
                dst.SellVolume += src.SellVolume;
                dst.UnclassifiedVolume += src.UnclassifiedVolume;
                dst.TradeCount += src.TradeCount;
                if (dst.FirstSeenTime == DateTime.MinValue || (src.FirstSeenTime != DateTime.MinValue && src.FirstSeenTime < dst.FirstSeenTime))
                    dst.FirstSeenTime = src.FirstSeenTime;
                if (src.LastSeenTime > dst.LastSeenTime)
                    dst.LastSeenTime = src.LastSeenTime;
            }
            return grouped;
        }

        private long GetBidVolumeFromGrouped(Dictionary<double, OrderFlowMinuteProPriceLevelDataV8NoOutput> dict, double price)
        {
            if (dict == null)
                return 0;
            OrderFlowMinuteProPriceLevelDataV8NoOutput level;
            return dict.TryGetValue(GetGroupedPrice(price, currentTickMultiplier), out level) && level != null ? level.SellVolume : 0;
        }

        private long GetAskVolumeFromGrouped(Dictionary<double, OrderFlowMinuteProPriceLevelDataV8NoOutput> dict, double price)
        {
            if (dict == null)
                return 0;
            OrderFlowMinuteProPriceLevelDataV8NoOutput level;
            return dict.TryGetValue(GetGroupedPrice(price, currentTickMultiplier), out level) && level != null ? level.BuyVolume : 0;
        }

        /// <summary>Diagonal ask imbalance: current grouped ask/buy volume vs grouped bid/sell volume one display step below.</summary>
        private bool IsAskImbalanceDiagonal(long askVolume, long diagonalBidBelow)
        {
            if (askVolume < MinImbalanceVolume)
                return false;
            if (diagonalBidBelow == 0)
                return ShowZeroCompareImbalance && askVolume >= ZeroCompareMinVolume;
            return askVolume > 0 && askVolume >= diagonalBidBelow * (ImbalanceRatioPercent / 100.0);
        }

        /// <summary>Diagonal bid imbalance: current grouped bid/sell volume vs grouped ask/buy volume one display step above.</summary>
        private bool IsBidImbalanceDiagonal(long bidVolume, long diagonalAskAbove)
        {
            if (bidVolume < MinImbalanceVolume)
                return false;
            if (diagonalAskAbove == 0)
                return ShowZeroCompareImbalance && bidVolume >= ZeroCompareMinVolume;
            return bidVolume > 0 && bidVolume >= diagonalAskAbove * (ImbalanceRatioPercent / 100.0);
        }

        private bool IsAskImbalance(long bid, long ask)
        {
            if (ask < MinImbalanceVolume)
                return false;
            if (bid == 0)
                return ShowZeroCompareImbalance && ask >= ZeroCompareMinVolume;
            return ask > 0 && ask >= bid * (ImbalanceRatioPercent / 100.0);
        }

        private bool IsBidImbalance(long bid, long ask)
        {
            if (bid < MinImbalanceVolume)
                return false;
            if (ask == 0)
                return ShowZeroCompareImbalance && bid >= ZeroCompareMinVolume;
            return bid > 0 && bid >= ask * (ImbalanceRatioPercent / 100.0);
        }

        private double GetNearestPriceFast(OrderFlowMinuteProOrderFlowDataV8NoOutput flow, double price, double minP, double maxP)
        {
            double p = RoundToTick(price);
            if (flow != null && flow.Footprint != null && flow.Footprint.ContainsKey(p))
                return p;
            double up = p;
            double down = p;
            for (int i = 1; i <= 8; i++)
            {
                up = RoundToTick(p + i * TickSize);
                down = RoundToTick(p - i * TickSize);
                if (flow != null && flow.Footprint != null && up <= maxP && flow.Footprint.ContainsKey(up)) return up;
                if (flow != null && flow.Footprint != null && down >= minP && flow.Footprint.ContainsKey(down)) return down;
            }
            return p;
        }

        private long GetVolumeAtPrice(OrderFlowMinuteProOrderFlowDataV8NoOutput flow, double price)
        {
            if (flow == null || flow.Footprint == null)
                return 0;
            OrderFlowMinuteProPriceLevelDataV8NoOutput level;
            if (!flow.Footprint.TryGetValue(RoundToTick(price), out level) || level == null)
                return 0;
            return level.BuyVolume + level.SellVolume + (ShowUnclassifiedVolume ? level.UnclassifiedVolume : 0);
        }

        private DxBrush GetSignalBrush(BarSignal s)
        {
            if (s == null)
                return neutralBrush;
            if (s.Type == 7) return s.Direction >= 0 ? bullReversalBrush : bearReversalBrush;
            if (s.Type == 2) return absorptionBrush;
            if (s.Type == 3) return trapBrush;
            if (s.Type == 1) return divergenceBrush;
            if (s.Type == 4) return pivotBrush;
            return neutralBrush;
        }

        private string GetPresetName()
        {
            return UxPresetMode == 1 ? "White Background" : "Black Background";
        }

        private string GetThemeName()
        {
            return (ThemeMode == 1 || UxPresetMode == 1) ? "White / Light" : "Black / Dark";
        }

        private string GetDensityName(int d)
        {
            if (d == 0) return "Hidden";
            if (d == 1) return "Heatmap";
            if (d == 2) return "Heat+POC";
            if (d == 3) return "Imbalance";
            if (d == 4) return "Numbers";
            return "Full Detail";
        }

        private string GetProfileModeName()
        {
            if (ProfileMode == 1) return "Session Approx Profile";
            if (ProfileMode == 2) return "Lookback Profile";
            if (ProfileMode == 3) return "Anchored Profile";
            return "Visible Profile";
        }

        private double RoundToTick(double price)
        {
            if (TickSize <= 0)
                return price;
            return Math.Round(price / TickSize, 0, MidpointRounding.AwayFromZero) * TickSize;
        }

        private double SafeRatio(long a, long b)
        {
            if (b == 0)
                return a > 0 ? 999.0 : 0.0;
            return a / (double)b;
        }

        private int ClampInt(int v, int min, int max)
        {
            if (v < min) return min;
            if (v > max) return max;
            return v;
        }

        private float Clamp01(float v)
        {
            if (v < 0f) return 0f;
            if (v > 1f) return 1f;
            return v;
        }

        private string FormatVol(long v)
        {
            if (Math.Abs(v) >= 1000000)
                return (v / 1000000.0).ToString("0.0", CultureInfo.InvariantCulture) + "M";
            if (Math.Abs(v) >= 1000)
                return (v / 1000.0).ToString("0.0", CultureInfo.InvariantCulture) + "K";
            return v.ToString(CultureInfo.InvariantCulture);
        }

        private void DrawText(string text, DxRect rect, TextFormat format, DxBrush brush, TextAlignment align)
        {
            if (string.IsNullOrEmpty(text) || format == null || brush == null || dwFactory == null || RenderTarget == null)
                return;
            if (rect.Width <= 1 || rect.Height <= 1)
                return;
            format.TextAlignment = align;
            format.ParagraphAlignment = ParagraphAlignment.Center;
            using (TextLayout layout = new TextLayout(dwFactory, text, format, Math.Max(1f, rect.Width), Math.Max(1f, rect.Height)))
                RenderTarget.DrawTextLayout(new Vector2(rect.Left, rect.Top), layout, brush);
        }

        private void DebugPrint(string msg)
        {
            if (DebugMode)
                Print((CurrentBar >= 0 ? Time[0].ToString("yyyy-MM-dd HH:mm:ss.fff") : DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss.fff")) + " | " + Name + " | " + msg);
        }

        #endregion

        #region Dispose

        private void DisposeTextFormats()
        {
            if (fontTiny != null) fontTiny.Dispose();
            if (fontSmall != null) fontSmall.Dispose();
            if (fontNormal != null) fontNormal.Dispose();
            if (fontBold != null) fontBold.Dispose();
            fontTiny = null;
            fontSmall = null;
            fontNormal = null;
            fontBold = null;
        }

        private void DisposeBrushArray(DxSolidColorBrush[] arr)
        {
            if (arr == null)
                return;
            for (int i = 0; i < arr.Length; i++)
            {
                if (arr[i] != null)
                    arr[i].Dispose();
                arr[i] = null;
            }
        }

        private void DisposeDx()
        {
            DisposeBrushArray(bidHeatBrushes);
            DisposeBrushArray(askHeatBrushes);
            DisposeBrushArray(buyZoneBrushes);
            DisposeBrushArray(sellZoneBrushes);
            DisposeBrushArray(internalNeutralHeatBrushes);
            DisposeBrushArray(internalBullHeatBrushes);
            DisposeBrushArray(internalBearHeatBrushes);

            DisposeBrush(ref bidBrush);
            DisposeBrush(ref askBrush);
            DisposeBrush(ref bidStrongBrush);
            DisposeBrush(ref askStrongBrush);
            DisposeBrush(ref textBrush);
            DisposeBrush(ref mutedTextBrush);
            DisposeBrush(ref gridBrush);
            DisposeBrush(ref panelBrush);
            DisposeBrush(ref panelBorderBrush);
            DisposeBrush(ref pocBrush);
            DisposeBrush(ref valueAreaBrush);
            DisposeBrush(ref bullBrush);
            DisposeBrush(ref bearBrush);
            DisposeBrush(ref goldBrush);
            DisposeBrush(ref neutralBrush);
            DisposeBrush(ref profileBgBrush);
            DisposeBrush(ref hvnBrush);
            DisposeBrush(ref lvnBrush);
            DisposeBrush(ref bullReversalBrush);
            DisposeBrush(ref bearReversalBrush);
            DisposeBrush(ref reversalGlowBrush);
            DisposeBrush(ref absorptionBrush);
            DisposeBrush(ref trapBrush);
            DisposeBrush(ref divergenceBrush);
            DisposeBrush(ref pivotBrush);
            DisposeBrush(ref warningBrush);
            DisposeBrush(ref profileVolumeBrush);
            DisposeBrush(ref profileValueAreaBrush);
            DisposeBrush(ref unclassifiedBrush);
            DisposeBrush(ref internalPocCoreBrush);
            DisposeBrush(ref persistentCoreBrush);
            DisposeBrush(ref buyZoneLineBrush);
            DisposeBrush(ref sellZoneLineBrush);
        }

        private void DisposeBrush(ref DxSolidColorBrush b)
        {
            if (b != null)
                b.Dispose();
            b = null;
        }

        #endregion
    }
}

