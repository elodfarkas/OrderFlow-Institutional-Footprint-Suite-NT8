#region Using declarations
using System;
using System.Collections.Generic;
using NinjaTrader.NinjaScript.AddOns.OrderFlowPro;
#endregion

namespace NinjaTrader.NinjaScript.AddOns.OrderFlowPro
{
    /// <summary>Pure calculation engine: footprint POC, delta, diagonal imbalance and stacked imbalance. No rendering.</summary>
    public sealed class OrderFlowMetricsEngine
    {
        private readonly MetricsSettings settings;
        private readonly double tickSize;

        public OrderFlowMetricsEngine(MetricsSettings settings, double tickSize)
        {
            this.settings = settings ?? new MetricsSettings();
            this.tickSize = tickSize > 0 ? tickSize : 0.25;
        }

        public FlowMetrics BuildMetrics(FootprintBarData bar)
        {
            FlowMetrics m = new FlowMetrics();
            if (bar == null || bar.Levels == null || bar.Levels.Count == 0) return m;
            m.BarIndex = bar.BarIndex;
            m.Valid = true;
            m.TotalVolume = settings.IncludeUnclassifiedInTotal ? bar.TotalVolume : bar.ClassifiedVolume;
            m.ClassifiedVolume = bar.ClassifiedVolume;
            m.UnclassifiedVolume = bar.UnclassifiedVolume;
            m.Delta = bar.Delta;
            long denominator = settings.DeltaPercentMode == 0 ? Math.Max(1, bar.ClassifiedVolume) : Math.Max(1, m.TotalVolume);
            m.DeltaPercent = (double)m.Delta / denominator * 100.0;
            bool first = true;
            foreach (KeyValuePair<double, PriceLevelData> kv in bar.Levels)
            {
                PriceLevelData level = kv.Value;
                if (level == null) continue;
                long nodeVolume = settings.IncludeUnclassifiedInTotal ? level.TotalVolume : level.ClassifiedVolume;
                if (first) { m.MinPrice = kv.Key; m.MaxPrice = kv.Key; first = false; }
                else { if (kv.Key < m.MinPrice) m.MinPrice = kv.Key; if (kv.Key > m.MaxPrice) m.MaxPrice = kv.Key; }
                if (nodeVolume >= m.MaxNodeVolume) { m.MaxNodeVolume = nodeVolume; m.PocVolume = nodeVolume; m.PocPrice = kv.Key; }
                m.LevelCount++;
            }
            DetectDiagonalImbalances(bar, m);
            DetectStacks(m);
            return m;
        }

        private void DetectDiagonalImbalances(FootprintBarData bar, FlowMetrics m)
        {
            foreach (KeyValuePair<double, PriceLevelData> kv in bar.Levels)
            {
                double price = kv.Key;
                PriceLevelData current = kv.Value;
                if (current == null) continue;
                PriceLevelData below; PriceLevelData above;
                bar.Levels.TryGetValue(RoundToTick(price - tickSize), out below);
                bar.Levels.TryGetValue(RoundToTick(price + tickSize), out above);
                long diagonalBidBelow = below != null ? below.BidVolume : 0;
                long diagonalAskAbove = above != null ? above.AskVolume : 0;
                bool askImb = IsImbalance(current.AskVolume, diagonalBidBelow, settings.MinImbalanceVolume);
                bool bidImb = IsImbalance(current.BidVolume, diagonalAskAbove, settings.MinImbalanceVolume);
                if (!askImb && !bidImb) continue;
                ImbalanceLevel imb = new ImbalanceLevel();
                imb.Price = price; imb.AskImbalance = askImb; imb.BidImbalance = bidImb;
                imb.AskVolume = current.AskVolume; imb.BidVolume = current.BidVolume;
                imb.AskRatio = SafeRatio(current.AskVolume, diagonalBidBelow);
                imb.BidRatio = SafeRatio(current.BidVolume, diagonalAskAbove);
                m.Imbalances.Add(imb);
                if (askImb) m.AskImbalanceCount++;
                if (bidImb) m.BidImbalanceCount++;
            }
        }

        private void DetectStacks(FlowMetrics m)
        {
            if (m.Imbalances.Count == 0) return;
            List<ImbalanceLevel> ordered = new List<ImbalanceLevel>(m.Imbalances);
            ordered.Sort(delegate(ImbalanceLevel a, ImbalanceLevel b) { return a.Price.CompareTo(b.Price); });
            DetectStackSide(m, ordered, true);
            DetectStackSide(m, ordered, false);
        }

        private void DetectStackSide(FlowMetrics m, List<ImbalanceLevel> ordered, bool askSide)
        {
            int runCount = 0; double runFrom = 0; double runTo = 0; long runVolume = 0; double ratioSum = 0; double previousPrice = double.NaN;
            for (int i = 0; i < ordered.Count; i++)
            {
                ImbalanceLevel level = ordered[i];
                bool active = askSide ? level.AskImbalance : level.BidImbalance;
                long sideVolume = askSide ? level.AskVolume : level.BidVolume;
                double ratio = askSide ? level.AskRatio : level.BidRatio;
                bool volumeOk = sideVolume >= settings.StackMinVolume;
                bool consecutive = double.IsNaN(previousPrice) || Math.Abs(level.Price - previousPrice - tickSize) < tickSize * 0.1;
                if (active && volumeOk && (runCount == 0 || consecutive))
                {
                    if (runCount == 0) runFrom = level.Price;
                    runTo = level.Price; runCount++; runVolume += sideVolume; ratioSum += ratio; previousPrice = level.Price;
                }
                else
                {
                    FlushStackIfValid(m, askSide, runCount, runFrom, runTo, runVolume, ratioSum);
                    runCount = 0; runVolume = 0; ratioSum = 0; previousPrice = double.NaN;
                    if (active && volumeOk) { runFrom = level.Price; runTo = level.Price; runCount = 1; runVolume = sideVolume; ratioSum = ratio; previousPrice = level.Price; }
                }
            }
            FlushStackIfValid(m, askSide, runCount, runFrom, runTo, runVolume, ratioSum);
        }

        private void FlushStackIfValid(FlowMetrics m, bool askSide, int count, double from, double to, long volume, double ratioSum)
        {
            if (count < settings.StackMinCount) return;
            ImbalanceStack stack = new ImbalanceStack();
            stack.BarIndex = m.BarIndex; stack.IsAskStack = askSide; stack.IsBidStack = !askSide;
            stack.FromPrice = Math.Min(from, to); stack.ToPrice = Math.Max(from, to);
            stack.Count = count; stack.TotalVolume = volume; stack.AverageRatio = count > 0 ? ratioSum / count : 0;
            m.Stacks.Add(stack);
            if (askSide) m.AskStackCount++; else m.BidStackCount++;
        }

        private bool IsImbalance(long aggressiveVolume, long passiveDiagonalVolume, long minVolume)
        {
            if (aggressiveVolume < minVolume) return false;
            if (passiveDiagonalVolume <= 0) return settings.AllowZeroCompareImbalance && aggressiveVolume >= settings.ZeroCompareMinVolume;
            return aggressiveVolume / (double)passiveDiagonalVolume >= settings.ImbalanceRatioPercent / 100.0;
        }
        private double SafeRatio(long numerator, long denominator) { if (denominator <= 0) return numerator > 0 ? double.PositiveInfinity : 0; return numerator / (double)denominator; }
        private double RoundToTick(double price) { if (tickSize <= 0) return price; return Math.Round(price / tickSize, 0, MidpointRounding.AwayFromZero) * tickSize; }
    }
}
