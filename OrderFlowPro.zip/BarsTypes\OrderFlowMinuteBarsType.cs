#region Using declarations
using System;
using System.Collections.Generic;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
#endregion

namespace NinjaTrader.NinjaScript.BarsTypes
{
    // Compatibility data model for older visualizers/adapters that still reference OrderFlowMinute...V8 names.
    // Uses a unique BarsPeriodType ID so it does not conflict with the previous 8260 / 8261 tests.
    public class OrderFlowMinuteProPriceLevelDataV8NoOutput
    {
        public long BuyVolume;
        public long SellVolume;
        public long UnclassifiedVolume;
        public int TradeCount;
        public DateTime FirstSeenTime;
        public DateTime LastSeenTime;

        public long Delta { get { return BuyVolume - SellVolume; } }
        public long TotalVolume { get { return BuyVolume + SellVolume + UnclassifiedVolume; } }

        public double BuySellRatio
        {
            get
            {
                if (SellVolume == 0)
                    return BuyVolume > 0 ? double.PositiveInfinity : 0;
                return (double)BuyVolume / SellVolume;
            }
        }

        public double SellBuyRatio
        {
            get
            {
                if (BuyVolume == 0)
                    return SellVolume > 0 ? double.PositiveInfinity : 0;
                return (double)SellVolume / BuyVolume;
            }
        }
    }

    public class OrderFlowMinuteProOrderFlowDataV8NoOutput
    {
        public long BuyVolume;
        public long SellVolume;
        public long UnclassifiedVolume;
        public int TradeCount;

        public long MaxNodeVolume;
        public double PocPrice;
        public int HighVolumeNodeCount;
        public DateTime FirstSeenTime;
        public DateTime LastSeenTime;

        public long Delta { get { return BuyVolume - SellVolume; } }
        public long TotalVolume { get { return BuyVolume + SellVolume + UnclassifiedVolume; } }

        public double BuySellRatio
        {
            get
            {
                if (SellVolume == 0)
                    return BuyVolume > 0 ? double.PositiveInfinity : 0;
                return (double)BuyVolume / SellVolume;
            }
        }

        public double SellBuyRatio
        {
            get
            {
                if (BuyVolume == 0)
                    return SellVolume > 0 ? double.PositiveInfinity : 0;
                return (double)SellVolume / BuyVolume;
            }
        }

        public bool BuyImbalance { get { return BuyVolume > 0 && BuyVolume >= SellVolume * 3; } }
        public bool SellImbalance { get { return SellVolume > 0 && SellVolume >= BuyVolume * 3; } }

        public Dictionary<double, OrderFlowMinuteProPriceLevelDataV8NoOutput> Footprint = new Dictionary<double, OrderFlowMinuteProPriceLevelDataV8NoOutput>();
    }

    public class OrderFlowMinuteBarsTypeV8NoOutput : BarsType
    {
        public Dictionary<int, OrderFlowMinuteProOrderFlowDataV8NoOutput> FlowDataByBar = new Dictionary<int, OrderFlowMinuteProOrderFlowDataV8NoOutput>();

        public int FlatTickMode { get; set; }
        public int HvnMetricRecalcInterval { get; set; }

        private double lastPrice;
        private int lastDirection;
        private SessionIterator sessionIterator;
        private DateTime lastInputTime;
        private int lastBarsCountSeen;

        protected override void OnStateChange()
        {
            if (State == State.SetDefaults)
            {
                Description = "OrderFlow Minute PRO V8 compatibility bars. Unique ID 9272; keeps legacy visualizers/adapters compiling while avoiding the old 8260/8261 conflict.";
                Name = "OrderFlow Minute PRO V8 Compat";

                BarsPeriod = new BarsPeriod
                {
                    BarsPeriodType = (BarsPeriodType)9272,
                    BarsPeriodTypeName = "OrderFlow Minute PRO V8 Compat",
                    Value = 1
                };

                FlatTickMode = 1;
                HvnMetricRecalcInterval = 8;
                BuiltFrom = BarsPeriodType.Tick;
                DaysToLoad = 1;
                IsIntraday = true;
                IsTimeBased = true;
            }
            else if (State == State.Configure)
            {
                if (BarsPeriod == null)
                    BarsPeriod = new BarsPeriod { BarsPeriodType = (BarsPeriodType)9272, BarsPeriodTypeName = "OrderFlow Minute PRO V8 Compat", Value = 1 };
                if (BarsPeriod.Value <= 0)
                    BarsPeriod.Value = 1;
                if (FlatTickMode < 0 || FlatTickMode > 2)
                    FlatTickMode = 1;
                if (HvnMetricRecalcInterval <= 0)
                    HvnMetricRecalcInterval = 8;
            }
            else if (State == State.DataLoaded)
            {
                ResetAllLocalState(true);
            }
            else if (State == State.Terminated)
            {
                ResetAllLocalState(true);
            }
        }

        protected override void OnDataPoint(Bars bars, double open, double high, double low, double close, DateTime time, long volume, bool isBar, double bid, double ask)
        {
            if (bars == null)
                return;

            if (lastInputTime != DateTime.MinValue && time < lastInputTime)
                ResetPerInputStreamState();

            if (lastBarsCountSeen > 0 && bars.Count < lastBarsCountSeen)
            {
                FlowDataByBar.Clear();
                ResetPerInputStreamState();
            }

            if (sessionIterator == null)
                sessionIterator = new SessionIterator(bars);

            bool isNewSession = sessionIterator.IsNewSession(time, isBar);
            if (isNewSession)
            {
                sessionIterator.GetNextSession(time, isBar);
                lastPrice = close;
                lastDirection = 0;
            }

            DateTime barTime = GetBarTime(time, bars.BarsPeriod.Value);
            long safeVolume = volume > 0 ? volume : 0;

            if (bars.Count == 0)
                AddBar(bars, open, high, low, close, barTime, safeVolume);
            else if (barTime > bars.LastBarTime)
                AddBar(bars, open, high, low, close, barTime, safeVolume);
            else
                UpdateBar(bars, high, low, close, bars.LastBarTime, safeVolume);

            int currentBarIndex = bars.Count - 1;
            if (currentBarIndex >= 0)
                UpdateOrderFlowData(bars, currentBarIndex, close, safeVolume, time);

            if (close > 0)
                lastPrice = close;

            lastInputTime = time;
            lastBarsCountSeen = bars.Count;
        }

        private void UpdateOrderFlowData(Bars bars, int currentBarIndex, double close, long volume, DateTime time)
        {
            OrderFlowMinuteProOrderFlowDataV8NoOutput flow;
            if (!FlowDataByBar.TryGetValue(currentBarIndex, out flow))
            {
                flow = new OrderFlowMinuteProOrderFlowDataV8NoOutput();
                flow.FirstSeenTime = time;
                FlowDataByBar[currentBarIndex] = flow;
            }

            long buyVolume = 0;
            long sellVolume = 0;
            long unclassifiedVolume = 0;
            ClassifyVolumeTickRuleOnly(close, volume, ref buyVolume, ref sellVolume, ref unclassifiedVolume);

            flow.BuyVolume += buyVolume;
            flow.SellVolume += sellVolume;
            flow.UnclassifiedVolume += unclassifiedVolume;
            if (volume > 0)
                flow.TradeCount++;
            if (flow.FirstSeenTime == DateTime.MinValue)
                flow.FirstSeenTime = time;
            flow.LastSeenTime = time;

            double priceLevel = NormalizePrice(bars, close);
            OrderFlowMinuteProPriceLevelDataV8NoOutput priceData;
            if (!flow.Footprint.TryGetValue(priceLevel, out priceData))
            {
                priceData = new OrderFlowMinuteProPriceLevelDataV8NoOutput();
                priceData.FirstSeenTime = time;
                flow.Footprint[priceLevel] = priceData;
            }

            priceData.BuyVolume += buyVolume;
            priceData.SellVolume += sellVolume;
            priceData.UnclassifiedVolume += unclassifiedVolume;
            if (volume > 0)
                priceData.TradeCount++;
            if (priceData.FirstSeenTime == DateTime.MinValue)
                priceData.FirstSeenTime = time;
            priceData.LastSeenTime = time;

            UpdateCachedBarMetrics(flow, priceLevel, priceData);
        }

        private void ClassifyVolumeTickRuleOnly(double close, long volume, ref long buyVolume, ref long sellVolume, ref long unclassifiedVolume)
        {
            if (volume <= 0)
                return;

            if (lastPrice > 0)
            {
                if (close > lastPrice)
                {
                    buyVolume = volume;
                    lastDirection = 1;
                }
                else if (close < lastPrice)
                {
                    sellVolume = volume;
                    lastDirection = -1;
                }
                else
                {
                    if (FlatTickMode == 1)
                    {
                        if (lastDirection > 0)
                            buyVolume = volume;
                        else if (lastDirection < 0)
                            sellVolume = volume;
                        else
                            unclassifiedVolume = volume;
                    }
                    else if (FlatTickMode == 2)
                    {
                        buyVolume = volume / 2;
                        sellVolume = volume - buyVolume;
                    }
                    else
                    {
                        unclassifiedVolume = volume;
                    }
                }
            }
            else
            {
                unclassifiedVolume = volume;
            }
        }

        private void UpdateCachedBarMetrics(OrderFlowMinuteProOrderFlowDataV8NoOutput flow, double priceLevel, OrderFlowMinuteProPriceLevelDataV8NoOutput priceData)
        {
            if (flow == null || priceData == null)
                return;

            long total = priceData.TotalVolume;
            bool newPoc = false;
            if (total >= flow.MaxNodeVolume)
            {
                flow.MaxNodeVolume = total;
                flow.PocPrice = priceLevel;
                newPoc = true;
            }

            if (!newPoc && HvnMetricRecalcInterval > 1 && flow.TradeCount % HvnMetricRecalcInterval != 0)
                return;

            long hvnThreshold = flow.MaxNodeVolume > 0 ? (long)(flow.MaxNodeVolume * 0.70) : 0;
            int hvnCount = 0;
            foreach (KeyValuePair<double, OrderFlowMinuteProPriceLevelDataV8NoOutput> kv in flow.Footprint)
            {
                if (kv.Value != null && kv.Value.TotalVolume >= hvnThreshold && hvnThreshold > 0)
                    hvnCount++;
            }
            flow.HighVolumeNodeCount = hvnCount;
        }

        private void ResetAllLocalState(bool clearFlowData)
        {
            if (clearFlowData)
                FlowDataByBar.Clear();
            sessionIterator = null;
            lastPrice = 0;
            lastDirection = 0;
            lastInputTime = DateTime.MinValue;
            lastBarsCountSeen = 0;
        }

        private void ResetPerInputStreamState()
        {
            sessionIterator = null;
            lastPrice = 0;
            lastDirection = 0;
            lastInputTime = DateTime.MinValue;
        }

        private DateTime GetBarTime(DateTime time, int minutes)
        {
            if (minutes <= 0)
                minutes = 1;
            DateTime date = time.Date;
            int totalMinutes = (int)time.TimeOfDay.TotalMinutes;
            int roundedMinutes = ((totalMinutes / minutes) + 1) * minutes;
            return date.AddMinutes(roundedMinutes);
        }

        private double NormalizePrice(Bars bars, double price)
        {
            if (bars == null || bars.Instrument == null || bars.Instrument.MasterInstrument == null)
                return price;
            double tickSize = bars.Instrument.MasterInstrument.TickSize;
            if (tickSize <= 0)
                return price;
            return Math.Round(price / tickSize, 0, MidpointRounding.AwayFromZero) * tickSize;
        }

        public override void ApplyDefaultValue(BarsPeriod period)
        {
            if (period == null)
                return;
            period.Value = 1;
        }

        public override void ApplyDefaultBasePeriodValue(BarsPeriod period)
        {
        }

        public override int GetInitialLookBackDays(BarsPeriod barsPeriod, TradingHours tradingHours, int barsBack)
        {
            return 1;
        }

        public override double GetPercentComplete(Bars bars, DateTime now)
        {
            if (bars == null || bars.Count == 0 || bars.BarsPeriod == null || bars.BarsPeriod.Value <= 0)
                return 0;
            DateTime lastBarTime = bars.LastBarTime;
            DateTime previousBarTime = lastBarTime.AddMinutes(-bars.BarsPeriod.Value);
            double elapsed = (now - previousBarTime).TotalSeconds;
            double total = bars.BarsPeriod.Value * 60.0;
            if (total <= 0)
                return 0;
            return Math.Max(0, Math.Min(1, elapsed / total));
        }

        public override string ChartLabel(DateTime dateTime)
        {
            return dateTime.ToString("HH:mm");
        }

        public override string ToString()
        {
            return "OrderFlow Minute PRO V8 Compat";
        }
    }
}
