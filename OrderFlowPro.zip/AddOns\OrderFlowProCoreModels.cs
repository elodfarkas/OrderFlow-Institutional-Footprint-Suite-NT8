#region Using declarations
using System;
using System.Collections.Generic;
#endregion

namespace NinjaTrader.NinjaScript.AddOns.OrderFlowPro
{
    /// <summary>One normalized footprint price level. Current source data is tick-rule classified.</summary>
    public sealed class PriceLevelData
    {
        public double Price;
        public long BidVolume;
        public long AskVolume;
        public long UnclassifiedVolume;
        public int TradeCount;
        public long Delta { get { return AskVolume - BidVolume; } }
        public long ClassifiedVolume { get { return AskVolume + BidVolume; } }
        public long TotalVolume { get { return AskVolume + BidVolume + UnclassifiedVolume; } }
        public bool HasVolume { get { return TotalVolume > 0; } }
        public void Add(long askVolume, long bidVolume, long unclassifiedVolume)
        {
            AskVolume += askVolume;
            BidVolume += bidVolume;
            UnclassifiedVolume += unclassifiedVolume;
            if (askVolume > 0 || bidVolume > 0 || unclassifiedVolume > 0)
                TradeCount++;
        }
    }

    /// <summary>Full footprint ladder for one bar.</summary>
    public sealed class FootprintBarData
    {
        public int BarIndex;
        public DateTime FirstSeenTime;
        public DateTime LastSeenTime;
        public long AskVolume;
        public long BidVolume;
        public long UnclassifiedVolume;
        public int TradeCount;
        public readonly Dictionary<double, PriceLevelData> Levels = new Dictionary<double, PriceLevelData>();
        public long Delta { get { return AskVolume - BidVolume; } }
        public long ClassifiedVolume { get { return AskVolume + BidVolume; } }
        public long TotalVolume { get { return AskVolume + BidVolume + UnclassifiedVolume; } }
        public void AddLevelVolume(double price, long askVolume, long bidVolume, long unclassifiedVolume, DateTime time)
        {
            AskVolume += askVolume;
            BidVolume += bidVolume;
            UnclassifiedVolume += unclassifiedVolume;
            if (askVolume > 0 || bidVolume > 0 || unclassifiedVolume > 0) TradeCount++;
            if (FirstSeenTime == DateTime.MinValue) FirstSeenTime = time;
            LastSeenTime = time;
            PriceLevelData level;
            if (!Levels.TryGetValue(price, out level)) { level = new PriceLevelData { Price = price }; Levels[price] = level; }
            level.Add(askVolume, bidVolume, unclassifiedVolume);
        }
    }

    public sealed class ImbalanceLevel
    {
        public double Price;
        public bool AskImbalance;
        public bool BidImbalance;
        public double AskRatio;
        public double BidRatio;
        public long AskVolume;
        public long BidVolume;
    }

    public sealed class ImbalanceStack
    {
        public int BarIndex;
        public bool IsAskStack;
        public bool IsBidStack;
        public double FromPrice;
        public double ToPrice;
        public int Count;
        public long TotalVolume;
        public double AverageRatio;
        public double MidPrice { get { return (FromPrice + ToPrice) * 0.5; } }
    }

    public sealed class FlowMetrics
    {
        public int BarIndex;
        public bool Valid;
        public long TotalVolume;
        public long ClassifiedVolume;
        public long UnclassifiedVolume;
        public long Delta;
        public double DeltaPercent;
        public double MinPrice;
        public double MaxPrice;
        public double PocPrice;
        public long PocVolume;
        public long MaxNodeVolume;
        public int LevelCount;
        public int AskImbalanceCount;
        public int BidImbalanceCount;
        public int AskStackCount;
        public int BidStackCount;
        public readonly List<ImbalanceLevel> Imbalances = new List<ImbalanceLevel>();
        public readonly List<ImbalanceStack> Stacks = new List<ImbalanceStack>();
    }

    public sealed class MetricsSettings
    {
        public int ImbalanceRatioPercent = 300;
        public long MinImbalanceVolume = 0;
        public bool AllowZeroCompareImbalance = true;
        public long ZeroCompareMinVolume = 1;
        public int StackMinCount = 3;
        public long StackMinVolume = 0;
        public bool IncludeUnclassifiedInTotal = true;
        public int DeltaPercentMode = 1;
    }
}
