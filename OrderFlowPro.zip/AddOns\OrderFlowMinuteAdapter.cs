#region Using declarations
using System.Collections.Generic;
using NinjaTrader.NinjaScript.BarsTypes;
#endregion

namespace NinjaTrader.NinjaScript.AddOns.OrderFlowPro
{
    /// <summary>Adapter from OrderFlow Minute PRO V8 BarsType data to the clean OrderFlowPro calculation model.</summary>
    public static class OrderFlowMinuteAdapter
    {
        public static FootprintBarData FromOrderFlowMinute(int barIndex, OrderFlowMinuteProOrderFlowDataV8NoOutput source)
        {
            if (source == null) return null;
            FootprintBarData target = new FootprintBarData();
            target.BarIndex = barIndex;
            target.FirstSeenTime = source.FirstSeenTime;
            target.LastSeenTime = source.LastSeenTime;
            target.AskVolume = source.BuyVolume;
            target.BidVolume = source.SellVolume;
            target.UnclassifiedVolume = source.UnclassifiedVolume;
            target.TradeCount = source.TradeCount;
            if (source.Footprint == null) return target;
            foreach (KeyValuePair<double, OrderFlowMinuteProPriceLevelDataV8NoOutput> kv in source.Footprint)
            {
                OrderFlowMinuteProPriceLevelDataV8NoOutput srcLevel = kv.Value;
                if (srcLevel == null) continue;
                PriceLevelData dstLevel = new PriceLevelData();
                dstLevel.Price = kv.Key;
                dstLevel.AskVolume = srcLevel.BuyVolume;
                dstLevel.BidVolume = srcLevel.SellVolume;
                dstLevel.UnclassifiedVolume = srcLevel.UnclassifiedVolume;
                dstLevel.TradeCount = srcLevel.TradeCount;
                target.Levels[kv.Key] = dstLevel;
            }
            return target;
        }
    }
}
