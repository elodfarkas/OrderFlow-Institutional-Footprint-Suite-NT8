
#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Globalization;
using NinjaTrader.Data;
using NinjaTrader.Gui.Chart;
using NinjaTrader.NinjaScript;
using SharpDX;
using SharpDX.DirectWrite;
using DxBrush = SharpDX.Direct2D1.Brush;
using DxColor = SharpDX.Color4;
using DxRect = SharpDX.RectangleF;
using DxSolidColorBrush = SharpDX.Direct2D1.SolidColorBrush;
#endregion

public enum DOMBrickInstrumentPresetOrderFlowV1
{
    ES,
    NQ,
    Custom
}

namespace NinjaTrader.NinjaScript.Indicators
{
    public class DOMBrickStandaloneOrderFlowV1 : Indicator
    {
        public override string DisplayName { get { return string.Empty; } }

        private readonly object sync = new object();
        private Dictionary<string, DomLevel> bidBook;
        private Dictionary<string, DomLevel> askBook;
        private Dictionary<string, BrickCandidate> candidates;
        private Dictionary<string, DomBrick> active;
        private List<DomBrick> confirmed;
        private Dictionary<string, LiquidityZone> longZones;
        private Dictionary<string, HMHeatmapCell> hmActiveCells;
        private List<HMHeatmapCell> hmAllCells;

        private SharpDX.DirectWrite.Factory dwFactory;
        private TextFormat fontTiny;
        private DxSolidColorBrush bidLineBrush;
        private DxSolidColorBrush askLineBrush;
        private DxSolidColorBrush magnetBrush;
        private DxSolidColorBrush textBrush;
        private DxSolidColorBrush mutedBrush;
        private DxSolidColorBrush panelBrush;
        private DxSolidColorBrush borderBrush;
        private DxSolidColorBrush spoofBrush;

        private class DomLevel
        {
            public double Price;
            public long Volume;
            public int Position;
            public bool IsBid;
        }

        private class BrickCandidate
        {
            public double Price;
            public bool IsBid;
            public long Volume;
            public long PeakVolume;
            public int Position;
            public int StartBar;
            public int LastSeenBar;
            public int FlickerCount;
            public int SampleCount;
            public DateTime FirstSeenUtc;
            public DateTime LastSeenUtc;
            public double CurrentDepthImbalance;
            public double AdjustedDepthImbalance;
            public double CredibilityScore;
            public double SpoofSuspicionScore;
            public double LiquidityQualityScore;
        }

        private class DomBrick
        {
            public double Price;
            public bool IsBid;
            public long Volume;
            public long PeakVolume;
            public int Position;
            public int StartBar;
            public int LastSeenBar;
            public int FlickerCount;
            public int SampleCount;
            public DateTime FirstSeenUtc;
            public DateTime LastSeenUtc;
            public bool Active;
            public bool IsMagnet;
            public bool IsSpoofing;
            public double CurrentDepthImbalance;
            public double AdjustedDepthImbalance;
            public double CredibilityScore;
            public double SpoofSuspicionScore;
            public double LiquidityQualityScore;
            public double LastDistanceTicks;
            public double VolatilityRegime;
        }

        private class LiquidityZone
        {
            public double CenterPrice;
            public double ZoneLow;
            public double ZoneHigh;
            public bool IsBid;
            public long LastVolume;
            public long PeakVolume;
            public double AverageVolume;
            public int AppearanceCount;
            public int CancellationCount;
            public int PullBeforeTouchCount;
            public int TouchCount;
            public int ReactionCount;
            public int BreakthroughCount;
            public int LastSeenBar;
            public DateTime FirstSeenUtc;
            public DateTime LastSeenUtc;
            public DateTime LastTouchUtc;
            public double MemoryScore;
            public double SpoofRisk;
            public double ExecutionConfirmation;
            public double HighProbabilityScore;
            public double LastDistanceTicks;
            public bool CurrentlyVisible;
        }

        
        private class HMHeatmapCell
        {
            public double Price;
            public double ZoneCenter;
            public bool IsBid;
            public long Volume;
            public long PeakVolume;
            public int StartBar;
            public int EndBar;
            public int UpdateCount;
            public DateTime FirstSeenUtc;
            public DateTime LastSeenUtc;
            public DateTime ClosedUtc;
            public double Intensity;
            public double SpoofRisk;
            public double MemoryScore;
            public double HighProbabilityScore;
            public bool Active;
            public bool PriceTouched;
            public bool InferredFilled;
            public bool ExplicitlyRemoved;
        }
        private enum HMLiquidityTier
        {
            None,
            HighProbability,
            Critical
        }
#region Properties
        [NinjaScriptProperty]
        [Display(Name = "Instrument preset", GroupName = "00. Preset", Order = 0)]
        public DOMBrickInstrumentPresetOrderFlowV1 InstrumentPreset { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Enable short-term DOM bricks", GroupName = "01. Short-Term Bricks", Order = 0)]
        public bool EnableDomBricks { get; set; }

        [NinjaScriptProperty]
        [Range(1, 10000)]
        [Display(Name = "Short-term trigger size", GroupName = "01. Short-Term Bricks", Order = 1)]
        public int TriggerSize { get; set; }

        [NinjaScriptProperty]
        [Range(10, 100)]
        [Display(Name = "Short-term remove hysteresis percent", GroupName = "01. Short-Term Bricks", Order = 2)]
        public int RemoveHysteresisPercent { get; set; }

        [NinjaScriptProperty]
        [Range(1, 120)]
        [Display(Name = "Short-term min duration seconds", GroupName = "01. Short-Term Bricks", Order = 3)]
        public int MinDurationSeconds { get; set; }

        [NinjaScriptProperty]
        [Range(250, 30000)]
        [Display(Name = "Institutional persistence ms", GroupName = "01. Short-Term Bricks", Order = 4)]
        public int InstitutionalPersistenceMs { get; set; }

        [NinjaScriptProperty]
        [Range(0, 50)]
        [Display(Name = "DOM max position", GroupName = "02. DOM Depth", Order = 0)]
        public int DomMaxPosition { get; set; }

        [NinjaScriptProperty]
        [Range(1, 10)]
        [Display(Name = "Depth imbalance levels", GroupName = "02. DOM Depth", Order = 1)]
        public int DepthImbalanceLevels { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Enable long-range liquidity map", GroupName = "03. Long-Range Liquidity", Order = 0)]
        public bool EnableLongRangeLiquidity { get; set; }

        [NinjaScriptProperty]
        [Range(1, 10000)]
        [Display(Name = "Long-range trigger size", GroupName = "03. Long-Range Liquidity", Order = 1)]
        public int LongRangeTriggerSize { get; set; }

        [NinjaScriptProperty]
        [Range(1, 500)]
        [Display(Name = "Long-range min distance ticks", GroupName = "03. Long-Range Liquidity", Order = 2)]
        public int LongRangeMinDistanceTicks { get; set; }

        [NinjaScriptProperty]
        [Range(2, 1000)]
        [Display(Name = "Long-range max distance ticks", GroupName = "03. Long-Range Liquidity", Order = 3)]
        public int LongRangeMaxDistanceTicks { get; set; }

        [NinjaScriptProperty]
        [Range(1, 50)]
        [Display(Name = "Zone merge ticks", GroupName = "03. Long-Range Liquidity", Order = 4)]
        public int ZoneMergeTicks { get; set; }

        [NinjaScriptProperty]
        [Range(5, 480)]
        [Display(Name = "Memory window minutes", GroupName = "03. Long-Range Liquidity", Order = 5)]
        public int MemoryWindowMinutes { get; set; }

        [NinjaScriptProperty]
        [Range(1, 20)]
        [Display(Name = "Min appearances to draw", GroupName = "03. Long-Range Liquidity", Order = 6)]
        public int MinAppearancesToDraw { get; set; }

        [NinjaScriptProperty]
        [Range(1, 99)]
        [Display(Name = "Min memory score percent", GroupName = "03. Long-Range Liquidity", Order = 7)]
        public int MinMemoryScorePercent { get; set; }

        [NinjaScriptProperty]
        [Range(10, 1000)]
        [Display(Name = "Max long-range zones", GroupName = "03. Long-Range Liquidity", Order = 8)]
        public int MaxLongRangeZones { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Draw candidate walls", GroupName = "04. Visual", Order = 0)]
        public bool DrawCandidateWalls { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Draw confirmed walls", GroupName = "04. Visual", Order = 1)]
        public bool DrawConfirmedWalls { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Draw long-range zones", GroupName = "04. Visual", Order = 2)]
        public bool DrawLongRangeZones { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Project magnets to margin", GroupName = "04. Visual", Order = 3)]
        public bool ProjectMagnetsToMargin { get; set; }

        [NinjaScriptProperty]
        [Range(5, 100)]
        [Display(Name = "Candidate opacity", GroupName = "04. Visual", Order = 4)]
        public int CandidateOpacity { get; set; }

        [NinjaScriptProperty]
        [Range(10, 100)]
        [Display(Name = "Confirmed opacity", GroupName = "04. Visual", Order = 5)]
        public int ConfirmedOpacity { get; set; }

        [NinjaScriptProperty]
        [Range(5, 100)]
        [Display(Name = "Long-range opacity", GroupName = "04. Visual", Order = 6)]
        public int LongRangeOpacity { get; set; }

        [NinjaScriptProperty]
        [Range(1, 12)]
        [Display(Name = "Zone height ticks", GroupName = "04. Visual", Order = 7)]
        public int ZoneHeightTicks { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Show labels", GroupName = "04. Visual", Order = 8)]
        public bool ShowLabels { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Show info panel", GroupName = "04. Visual", Order = 9)]
        public bool ShowInfoPanel { get; set; }

        
        
        [NinjaScriptProperty]
        [Display(Name = "Enable integrated heatmap", GroupName = "04B. Integrated Heatmap", Order = 0)]
        public bool EnableHeatmap { get; set; }
        [NinjaScriptProperty]
        [Range(1, 10000)]
        [Display(Name = "Heatmap trigger size", GroupName = "04B. Integrated Heatmap", Order = 1)]
        public int HeatmapTriggerSize { get; set; }
        [NinjaScriptProperty]
        [Range(1000, 20000)]
        [Display(Name = "Heatmap max cells", GroupName = "04B. Integrated Heatmap", Order = 2)]
        public int HeatmapMaxCells { get; set; }
        [NinjaScriptProperty]
        [Range(20, 3000)]
        [Display(Name = "Heatmap lookback bars", GroupName = "04B. Integrated Heatmap", Order = 3)]
        public int HeatmapLookbackBars { get; set; }
        [NinjaScriptProperty]
        [Range(1, 50)]
        [Display(Name = "Heatmap compression ticks", GroupName = "04B. Integrated Heatmap", Order = 4)]
        public int HeatmapCompressionTicks { get; set; }
        [NinjaScriptProperty]
        [Range(1, 12)]
        [Display(Name = "Heatmap cell height ticks", GroupName = "04B. Integrated Heatmap", Order = 5)]
        public int HeatmapCellHeightTicks { get; set; }
        [NinjaScriptProperty]
        [Range(5, 100)]
        [Display(Name = "Heatmap opacity", GroupName = "04B. Integrated Heatmap", Order = 6)]
        public int HeatmapOpacity { get; set; }
        [NinjaScriptProperty]
        [Display(Name = "Fade completed heatmap walls", GroupName = "04B. Integrated Heatmap", Order = 7)]
        public bool HeatmapFadeOldCells { get; set; }
        [NinjaScriptProperty]
        [Range(0, 100)]
        [Display(Name = "Completed heatmap min opacity percent", GroupName = "04B. Integrated Heatmap", Order = 8)]
        public int CompletedMinOpacityPercent { get; set; }
        [NinjaScriptProperty]
        [Range(1, 99)]
        [Display(Name = "Heatmap high probability threshold percent", GroupName = "04B. Integrated Heatmap", Order = 9)]
        public int HighProbabilityThresholdPercent { get; set; }
        [NinjaScriptProperty]
        [Range(1, 99)]
        [Display(Name = "Heatmap critical threshold percent", GroupName = "04B. Integrated Heatmap", Order = 10)]
        public int CriticalThresholdPercent { get; set; }
        [NinjaScriptProperty]
        [Range(1, 10)]
        [Display(Name = "Heatmap peak volume multiplier", GroupName = "04B. Integrated Heatmap", Order = 11)]
        public int PeakVolumeMultiplier { get; set; }
        [NinjaScriptProperty]
        [Range(1, 99)]
        [Display(Name = "Heatmap spoof fade threshold percent", GroupName = "04B. Integrated Heatmap", Order = 12)]
        public int SpoofRiskFadeThresholdPercent { get; set; }
[NinjaScriptProperty]
        [Display(Name = "Use trend adjustment", GroupName = "04. Visual", Order = 10)]
        public bool UseTrendAdjustment { get; set; }

        [NinjaScriptProperty]
        [Range(1, 20)]
        [Display(Name = "Trend lookback bars", GroupName = "04. Visual", Order = 11)]
        public int TrendLookbackBars { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Filter spoofing", GroupName = "05. Quality", Order = 0)]
        public bool FilterSpoofing { get; set; }

        [NinjaScriptProperty]
        [Range(1, 30)]
        [Display(Name = "Max flicker count", GroupName = "05. Quality", Order = 1)]
        public int MaxFlickerCount { get; set; }

        [NinjaScriptProperty]
        [Range(1, 99)]
        [Display(Name = "Min credibility percent", GroupName = "05. Quality", Order = 2)]
        public int MinCredibilityPercent { get; set; }

        [NinjaScriptProperty]
        [Range(1, 99)]
        [Display(Name = "Max spoof suspicion percent", GroupName = "05. Quality", Order = 3)]
        public int MaxSpoofSuspicionPercent { get; set; }

        [NinjaScriptProperty]
        [Range(1, 50)]
        [Display(Name = "Magnet distance ticks", GroupName = "06. Magnet", Order = 0)]
        public int MagnetDistanceTicks { get; set; }

        [NinjaScriptProperty]
        [Range(1, 99)]
        [Display(Name = "Magnet credibility percent", GroupName = "06. Magnet", Order = 1)]
        public int MagnetCredibilityPercent { get; set; }

        [NinjaScriptProperty]
        [Range(1, 99)]
        [Display(Name = "Volume retention percent", GroupName = "06. Magnet", Order = 2)]
        public int VolumeRetentionPercent { get; set; }

        [NinjaScriptProperty]
        [Range(100, 20000)]
        [Display(Name = "Max stored walls", GroupName = "07. Storage", Order = 0)]
        public int MaxStoredWalls { get; set; }

        [NinjaScriptProperty]
        [Display(Name = "Debug output", GroupName = "99. Debug", Order = 0)]
        public bool DebugOutput { get; set; }
        #endregion

        protected override void OnStateChange()
        {
            if (State == State.SetDefaults)
            {
                Name = "DOM Brick Standalone OrderFlow V1";
                Description = "Short-term DOM brick wall detector plus long-range resting liquidity memory map with spoof-risk, reappearance and touch/reaction tracking.";
                Calculate = Calculate.OnEachTick;
                IsOverlay = true;
                DrawOnPricePanel = true;
                DisplayInDataBox = false;
                PaintPriceMarkers = false;
                IsSuspendedWhileInactive = true;

                InstrumentPreset = DOMBrickInstrumentPresetOrderFlowV1.ES;
                EnableDomBricks = true;
                TriggerSize = 90;
                RemoveHysteresisPercent = 65;
                MinDurationSeconds = 3;
                InstitutionalPersistenceMs = 2500;
                DomMaxPosition = 7;
                DepthImbalanceLevels = 5;

                EnableLongRangeLiquidity = true;
                LongRangeTriggerSize = 120;
                LongRangeMinDistanceTicks = 20;
                LongRangeMaxDistanceTicks = 120;
                ZoneMergeTicks = 4;
                MemoryWindowMinutes = 90;
                MinAppearancesToDraw = 2;
                MinMemoryScorePercent = 22;
                MaxLongRangeZones = 240;

                DrawCandidateWalls = true;
                DrawConfirmedWalls = true;
                DrawLongRangeZones = true;
                ProjectMagnetsToMargin = true;
                CandidateOpacity = 24;
                ConfirmedOpacity = 78;
                LongRangeOpacity = 34;
                ZoneHeightTicks = 3;
                ShowLabels = true;
                ShowInfoPanel = true;

                
                UseTrendAdjustment = true;
                TrendLookbackBars = 3;
                FilterSpoofing = true;
                MaxFlickerCount = 6;
                MinCredibilityPercent = 28;
                MaxSpoofSuspicionPercent = 74;
                MagnetDistanceTicks = 8;
                MagnetCredibilityPercent = 55;
                VolumeRetentionPercent = 70;
                MaxStoredWalls = 2500;
                DebugOutput = false;
                EnableHeatmap = true;
                HeatmapTriggerSize = 42;
                HeatmapMaxCells = 10000;
                HeatmapLookbackBars = 520;
                HeatmapCompressionTicks = 1;
                HeatmapCellHeightTicks = 1;
                HeatmapOpacity = 76;
                HeatmapFadeOldCells = true;
                CompletedMinOpacityPercent = 24;
                HighProbabilityThresholdPercent = 70;
                CriticalThresholdPercent = 85;
                PeakVolumeMultiplier = 3;
                SpoofRiskFadeThresholdPercent = 55;
            }
            else if (State == State.DataLoaded)
            {
                bidBook = new Dictionary<string, DomLevel>();
                askBook = new Dictionary<string, DomLevel>();
                candidates = new Dictionary<string, BrickCandidate>();
                active = new Dictionary<string, DomBrick>();
                confirmed = new List<DomBrick>();
                longZones = new Dictionary<string, LiquidityZone>();
                hmActiveCells = new Dictionary<string, HMHeatmapCell>();
                hmAllCells = new List<HMHeatmapCell>();
                ApplyPreset();
                CreateTextFormats();
            }
            else if (State == State.Terminated)
            {
                DisposeDx();
                DisposeTextFormats();
                if (dwFactory != null) dwFactory.Dispose();
                dwFactory = null;
            }
        }

        private void ApplyPreset()
        {
            if (InstrumentPreset == DOMBrickInstrumentPresetOrderFlowV1.Custom) return;

            if (InstrumentPreset == DOMBrickInstrumentPresetOrderFlowV1.ES)
            {
                TriggerSize = 90;
                RemoveHysteresisPercent = 65;
                MinDurationSeconds = 3;
                InstitutionalPersistenceMs = 2500;
                DomMaxPosition = 7;
                MaxFlickerCount = 6;
                MinCredibilityPercent = 28;
                MaxSpoofSuspicionPercent = 74;
                MagnetDistanceTicks = 8;
                MagnetCredibilityPercent = 55;
                VolumeRetentionPercent = 70;
                CandidateOpacity = 24;
                ConfirmedOpacity = 78;
                LongRangeTriggerSize = 120;
                LongRangeMinDistanceTicks = 20;
                LongRangeMaxDistanceTicks = 120;
                ZoneMergeTicks = 4;
                LongRangeOpacity = 34;
                MaxLongRangeZones = 240;
                MaxStoredWalls = 2500;
                HeatmapTriggerSize = 42;
                HeatmapCompressionTicks = 1;
                HeatmapCellHeightTicks = 1;
                HeatmapLookbackBars = 520;
                HighProbabilityThresholdPercent = 70;
                CriticalThresholdPercent = 85;
                SpoofRiskFadeThresholdPercent = 55;
            }
            else if (InstrumentPreset == DOMBrickInstrumentPresetOrderFlowV1.NQ)
            {
                TriggerSize = 28;
                RemoveHysteresisPercent = 60;
                MinDurationSeconds = 2;
                InstitutionalPersistenceMs = 1800;
                DomMaxPosition = 11;
                MaxFlickerCount = 8;
                MinCredibilityPercent = 36;
                MaxSpoofSuspicionPercent = 66;
                MagnetDistanceTicks = 16;
                MagnetCredibilityPercent = 62;
                VolumeRetentionPercent = 63;
                CandidateOpacity = 28;
                ConfirmedOpacity = 82;
                LongRangeTriggerSize = 45;
                LongRangeMinDistanceTicks = 40;
                LongRangeMaxDistanceTicks = 220;
                ZoneMergeTicks = 8;
                LongRangeOpacity = 38;
                MaxLongRangeZones = 340;
                MaxStoredWalls = 3500;
                HeatmapTriggerSize = 16;
                HeatmapCompressionTicks = 3;
                HeatmapCellHeightTicks = 2;
                HeatmapLookbackBars = 650;
                HighProbabilityThresholdPercent = 68;
                CriticalThresholdPercent = 74;
                SpoofRiskFadeThresholdPercent = 50;
            }
        }

        public override void OnRenderTargetChanged()
        {
            DisposeDx();
            if (RenderTarget == null) return;
            bidLineBrush = new DxSolidColorBrush(RenderTarget, new DxColor(0.00f, 0.95f, 0.32f, 0.95f));
            askLineBrush = new DxSolidColorBrush(RenderTarget, new DxColor(1.00f, 0.10f, 0.16f, 0.95f));
            magnetBrush = new DxSolidColorBrush(RenderTarget, new DxColor(1.00f, 0.75f, 0.12f, 0.98f));
            textBrush = new DxSolidColorBrush(RenderTarget, new DxColor(0.96f, 0.96f, 0.92f, 0.96f));
            mutedBrush = new DxSolidColorBrush(RenderTarget, new DxColor(0.78f, 0.82f, 0.88f, 0.94f));
            panelBrush = new DxSolidColorBrush(RenderTarget, new DxColor(0.02f, 0.025f, 0.035f, 0.72f));
            borderBrush = new DxSolidColorBrush(RenderTarget, new DxColor(1.00f, 1.00f, 1.00f, 0.12f));
            spoofBrush = new DxSolidColorBrush(RenderTarget, new DxColor(1.00f, 0.55f, 0.05f, 0.90f));
        }

        protected override void OnMarketDepth(MarketDepthEventArgs e)
        {
            if (e == null || Bars == null || CurrentBar < 0 || TickSize <= 0) return;
            if (e.MarketDataType != MarketDataType.Bid && e.MarketDataType != MarketDataType.Ask) return;

            bool isBid = e.MarketDataType == MarketDataType.Bid;
            double price = RoundToTick(e.Price);
            long volume = Math.Max(0, (long)e.Volume);
            int position = Math.Max(0, e.Position);
            DateTime nowUtc = DateTime.UtcNow;
            bool remove = IsRemoveOperation(e.Operation.ToString());
            string key = GetKey(price, isBid);

            lock (sync)
            {
                UpdateBookUnsafe(price, volume, position, isBid, remove);
                if (EnableLongRangeLiquidity) UpdateLongRangeLiquidityUnsafe(price, volume, position, isBid, remove, nowUtc);
                if (EnableDomBricks) UpdateShortTermBrickUnsafe(key, price, volume, position, isBid, remove, nowUtc);
                if (EnableHeatmap) UpdateHMHeatmapUnsafe(price, volume, position, isBid, remove, nowUtc);
                if (EnableHeatmap) TrimHMHeatmapUnsafe();
                if (EnableLongRangeLiquidity) UpdateZoneTouchAndReactionsUnsafe(nowUtc);
            }
        }

        private void UpdateShortTermBrickUnsafe(string key, double price, long volume, int position, bool isBid, bool remove, DateTime nowUtc)
        {
            int removeSize = Math.Max(1, (int)Math.Round(TriggerSize * (RemoveHysteresisPercent / 100.0)));
            if (remove || volume < removeSize || position > DomMaxPosition)
            {
                PenalizeCandidateUnsafe(key, volume, nowUtc, remove || volume <= 0);
                DeactivateBrickUnsafe(key, volume, nowUtc, remove || volume <= 0);
                return;
            }

            DomBrick brick;
            if (active.TryGetValue(key, out brick) && brick != null)
            {
                UpdateBrickUnsafe(brick, volume, position, nowUtc);
                return;
            }

            BrickCandidate candidate;
            if (!candidates.TryGetValue(key, out candidate) || candidate == null)
            {
                if (volume < TriggerSize) return;
                candidate = CreateCandidate(price, volume, position, isBid, nowUtc);
                candidates[key] = candidate;
                DebugPrint("CANDIDATE " + FormatState(candidate.Price, candidate.IsBid, candidate.Volume, candidate.Position, candidate.CredibilityScore, candidate.SpoofSuspicionScore, candidate.AdjustedDepthImbalance));
                return;
            }

            UpdateCandidateUnsafe(candidate, volume, position, nowUtc);
            if (candidate.CredibilityScore >= MinCredibilityPercent / 100.0
                && candidate.SpoofSuspicionScore <= MaxSpoofSuspicionPercent / 100.0
                && (nowUtc - candidate.FirstSeenUtc).TotalSeconds >= Math.Max(1, MinDurationSeconds))
            {
                DomBrick promoted = PromoteCandidateUnsafe(candidate, nowUtc);
                active[key] = promoted;
                candidates.Remove(key);
                TrimWallsUnsafe();
                DebugPrint("PROMOTED " + FormatState(promoted.Price, promoted.IsBid, promoted.Volume, promoted.Position, promoted.CredibilityScore, promoted.SpoofSuspicionScore, promoted.AdjustedDepthImbalance));
            }
        }

        protected override void OnRender(ChartControl chartControl, ChartScale chartScale)
        {
            base.OnRender(chartControl, chartScale);
            if (RenderTarget == null || ChartPanel == null || ChartBars == null || Bars == null || chartControl == null || chartScale == null) return;

            List<DomBrick> wallSnapshot;
            List<BrickCandidate> candidateSnapshot;
            List<LiquidityZone> zoneSnapshot;
            List<HMHeatmapCell> heatmapSnapshot;
            double di;
            lock (sync)
            {
                wallSnapshot = confirmed == null ? new List<DomBrick>() : new List<DomBrick>(confirmed);
                candidateSnapshot = candidates == null ? new List<BrickCandidate>() : new List<BrickCandidate>(candidates.Values);
                zoneSnapshot = longZones == null ? new List<LiquidityZone>() : new List<LiquidityZone>(longZones.Values);
                heatmapSnapshot = hmAllCells == null ? new List<HMHeatmapCell>() : new List<HMHeatmapCell>(hmAllCells);
                di = ComputeDepthImbalanceUnsafe(DepthImbalanceLevels);
            }

            int from = Math.Max(0, ChartBars.FromIndex);
            int to = Math.Min(Bars.Count - 1, ChartBars.ToIndex);
            float left = ChartPanel.X;
            float right = ChartPanel.X + ChartPanel.W;
            int drawnConfirmed = 0;
            int drawnCandidates = 0;
            int drawnLong = 0;
            if (EnableHeatmap)
            {
                int heatFrom = Math.Max(from, CurrentBar - HeatmapLookbackBars);
                for (int pass = 0; pass < 2; pass++)
                {
                    for (int i = 0; i < heatmapSnapshot.Count; i++)
                    {
                        HMHeatmapCell c = heatmapSnapshot[i];
                        if (c == null) continue;
                        if (c.EndBar < heatFrom || c.StartBar > to) continue;
                        HMLiquidityTier tier = GetHMCellTier(c);
                        if (tier == HMLiquidityTier.None) continue;
                        if ((pass == 0 && tier != HMLiquidityTier.HighProbability) || (pass == 1 && tier != HMLiquidityTier.Critical)) continue;
                        DrawHMHeatmapCell(chartControl, chartScale, c, heatFrom, left, right, tier);
                    }
                }
            }

            if (EnableLongRangeLiquidity && DrawLongRangeZones)
            {
                for (int i = 0; i < zoneSnapshot.Count; i++)
                {
                    LiquidityZone z = zoneSnapshot[i];
                    if (z == null) continue;
                    if (z.LastSeenBar < from - 5) continue;
                    if (z.AppearanceCount < MinAppearancesToDraw) continue;
                    if (z.MemoryScore < MinMemoryScorePercent / 100.0) continue;
                    DrawLongRangeZone(chartScale, z, left, right);
                    drawnLong++;
                }
            }

            if (EnableDomBricks && DrawCandidateWalls)
            {
                for (int i = 0; i < candidateSnapshot.Count; i++)
                {
                    BrickCandidate c = candidateSnapshot[i];
                    if (c == null || c.LastSeenBar < from - 2 || c.StartBar > to + 2) continue;
                    DrawCandidateWall(chartControl, chartScale, c, left, right);
                    drawnCandidates++;
                }
            }

            if (EnableDomBricks && DrawConfirmedWalls)
            {
                for (int i = 0; i < wallSnapshot.Count; i++)
                {
                    DomBrick b = wallSnapshot[i];
                    if (b == null || b.LastSeenBar < from - 2 || b.StartBar > to + 2) continue;
                    if (FilterSpoofing && b.SpoofSuspicionScore > MaxSpoofSuspicionPercent / 100.0) continue;
                    if (b.CredibilityScore < MinCredibilityPercent / 100.0) continue;
                    DrawConfirmedWall(chartControl, chartScale, b, left, right);
                    drawnConfirmed++;
                }
            }

            if (ShowInfoPanel) DrawInfoPanel(drawnConfirmed, drawnCandidates, drawnLong, di);
        }

        private void UpdateBookUnsafe(double price, long volume, int position, bool isBid, bool remove)
        {
            Dictionary<string, DomLevel> book = isBid ? bidBook : askBook;
            string key = GetKey(price, isBid);
            if (remove || volume <= 0)
            {
                book.Remove(key);
                return;
            }
            DomLevel level;
            if (!book.TryGetValue(key, out level) || level == null)
            {
                level = new DomLevel { Price = price, IsBid = isBid };
                book[key] = level;
            }
            level.Volume = volume;
            level.Position = position;
        }

        private void UpdateLongRangeLiquidityUnsafe(double price, long volume, int position, bool isBid, bool remove, DateTime nowUtc)
        {
            double distanceTicks = GetDistanceTicks(price);
            if (distanceTicks < LongRangeMinDistanceTicks || distanceTicks > LongRangeMaxDistanceTicks) return;
            if (position > Math.Max(DomMaxPosition, DepthImbalanceLevels + 8)) return;

            int removeSize = Math.Max(1, (int)Math.Round(LongRangeTriggerSize * 0.55));
            string zKey = GetZoneKey(price, isBid);
            LiquidityZone z;
            bool exists = longZones.TryGetValue(zKey, out z) && z != null;

            if (remove || volume < removeSize)
            {
                if (exists)
                {
                    z.CurrentlyVisible = false;
                    z.LastVolume = volume;
                    z.CancellationCount++;
                    if (z.LastDistanceTicks <= LongRangeMinDistanceTicks * 1.35) z.PullBeforeTouchCount++;
                    z.LastSeenUtc = nowUtc;
                    z.LastSeenBar = CurrentBar;
                    RecomputeLongZoneScore(z, nowUtc);
                }
                return;
            }

            if (volume < LongRangeTriggerSize && !exists) return;

            if (!exists)
            {
                double center = GetZoneCenter(price);
                double half = Math.Max(TickSize, ZoneMergeTicks * TickSize * 0.5);
                z = new LiquidityZone();
                z.CenterPrice = center;
                z.ZoneLow = center - half;
                z.ZoneHigh = center + half;
                z.IsBid = isBid;
                z.FirstSeenUtc = nowUtc;
                longZones[zKey] = z;
            }

            z.CurrentlyVisible = true;
            z.LastVolume = volume;
            z.PeakVolume = Math.Max(z.PeakVolume, volume);
            z.AverageVolume = z.AppearanceCount <= 0 ? volume : (z.AverageVolume * z.AppearanceCount + volume) / (z.AppearanceCount + 1.0);
            z.AppearanceCount++;
            z.LastSeenUtc = nowUtc;
            z.LastSeenBar = CurrentBar;
            z.LastDistanceTicks = distanceTicks;
            RecomputeLongZoneScore(z, nowUtc);
            TrimLongZonesUnsafe(nowUtc);
        }

        private void UpdateZoneTouchAndReactionsUnsafe(DateTime nowUtc)
        {
            if (longZones == null || longZones.Count == 0 || Close == null || Close.Count <= 0) return;
            double close = Close[0];
            foreach (KeyValuePair<string, LiquidityZone> kv in longZones)
            {
                LiquidityZone z = kv.Value;
                if (z == null) continue;
                double distanceTicks = Math.Abs(z.CenterPrice - close) / TickSize;
                if (distanceTicks <= Math.Max(1, ZoneMergeTicks))
                {
                    if ((nowUtc - z.LastTouchUtc).TotalSeconds > 15)
                    {
                        z.TouchCount++;
                        z.LastTouchUtc = nowUtc;
                        z.ExecutionConfirmation = Clamp01(z.ExecutionConfirmation + 0.12);
                    }
                }
                if (z.LastTouchUtc != DateTime.MinValue && (nowUtc - z.LastTouchUtc).TotalSeconds <= 90 && CurrentBar >= 2)
                {
                    double moveAwayTicks = z.IsBid ? (Close[0] - z.CenterPrice) / TickSize : (z.CenterPrice - Close[0]) / TickSize;
                    double moveThroughTicks = z.IsBid ? (z.CenterPrice - Close[0]) / TickSize : (Close[0] - z.CenterPrice) / TickSize;
                    if (moveAwayTicks >= Math.Max(4, ZoneMergeTicks) && z.ReactionCount < z.TouchCount) z.ReactionCount++;
                    if (moveThroughTicks >= Math.Max(4, ZoneMergeTicks) && z.BreakthroughCount < z.TouchCount) z.BreakthroughCount++;
                }
                RecomputeLongZoneScore(z, nowUtc);
            }
        }

        private void RecomputeLongZoneScore(LiquidityZone z, DateTime nowUtc)
        {
            if (z == null) return;
            double ageMin = Math.Max(0.01, (nowUtc - z.FirstSeenUtc).TotalMinutes);
            double recentMin = Math.Max(0.01, (nowUtc - z.LastSeenUtc).TotalMinutes);
            double persistence = Clamp01(Math.Log(1.0 + ageMin) / Math.Log(1.0 + Math.Max(5, MemoryWindowMinutes)));
            double recency = Clamp01(1.0 - recentMin / Math.Max(1.0, MemoryWindowMinutes));
            double reappearance = Clamp01(z.AppearanceCount / 10.0);
            double sizeNorm = Clamp01(z.PeakVolume / (double)Math.Max(1, LongRangeTriggerSize * 3));
            double touchQuality = Clamp01((z.TouchCount + z.ReactionCount * 1.5) / 8.0);
            double cancelRate = z.AppearanceCount <= 0 ? 0.0 : Clamp01(z.CancellationCount / (double)Math.Max(1, z.AppearanceCount));
            double pullRate = z.AppearanceCount <= 0 ? 0.0 : Clamp01(z.PullBeforeTouchCount / (double)Math.Max(1, z.AppearanceCount));
            z.SpoofRisk = Clamp01(0.45 * cancelRate + 0.35 * pullRate + 0.20 * (1.0 - recency));
            z.ExecutionConfirmation = Clamp01(0.50 * (z.TouchCount / (double)Math.Max(1, z.AppearanceCount)) + 0.35 * (z.ReactionCount / (double)Math.Max(1, z.TouchCount)) + 0.15 * (1.0 - z.SpoofRisk));
            z.MemoryScore = Clamp01(0.24 * persistence + 0.18 * recency + 0.22 * reappearance + 0.18 * sizeNorm + 0.18 * touchQuality - 0.28 * z.SpoofRisk);
            z.HighProbabilityScore = ComputeHMLongZoneHighProbability(z, nowUtc);
        }

        private BrickCandidate CreateCandidate(double price, long volume, int position, bool isBid, DateTime nowUtc)
        {
            double di = ComputeDepthImbalanceUnsafe(DepthImbalanceLevels);
            BrickCandidate c = new BrickCandidate();
            c.Price = price;
            c.IsBid = isBid;
            c.Volume = volume;
            c.PeakVolume = volume;
            c.Position = position;
            c.StartBar = CurrentBar;
            c.LastSeenBar = CurrentBar;
            c.FirstSeenUtc = nowUtc;
            c.LastSeenUtc = nowUtc;
            c.SampleCount = 1;
            c.CurrentDepthImbalance = di;
            c.AdjustedDepthImbalance = GetAdjustedDi(isBid, di);
            c.CredibilityScore = ComputeCredibility(nowUtc, nowUtc, 0, volume, volume, position, c.AdjustedDepthImbalance, 1.0);
            c.SpoofSuspicionScore = ComputeSpoofSuspicion(nowUtc, nowUtc, 0, volume, volume, c.AdjustedDepthImbalance, false);
            c.LiquidityQualityScore = ComputeLiquidityQuality(c.CredibilityScore, c.SpoofSuspicionScore, c.AdjustedDepthImbalance);
            return c;
        }

        private void UpdateCandidateUnsafe(BrickCandidate c, long volume, int position, DateTime nowUtc)
        {
            bool fast = (nowUtc - c.LastSeenUtc).TotalMilliseconds <= 500.0;
            bool volumeFlicker = c.Volume > 0 && Math.Abs(volume - c.Volume) / (double)Math.Max(1, c.Volume) >= 0.25;
            bool positionFlicker = Math.Abs(position - c.Position) >= 2;
            if (fast && (volumeFlicker || positionFlicker)) c.FlickerCount++;
            c.Volume = volume;
            c.PeakVolume = Math.Max(c.PeakVolume, volume);
            c.Position = position;
            c.LastSeenBar = CurrentBar;
            c.LastSeenUtc = nowUtc;
            c.SampleCount++;
            c.CurrentDepthImbalance = ComputeDepthImbalanceUnsafe(DepthImbalanceLevels);
            c.AdjustedDepthImbalance = GetAdjustedDi(c.IsBid, c.CurrentDepthImbalance);
            double volRegime = GetVolatilityRegime();
            c.CredibilityScore = ComputeCredibility(c.FirstSeenUtc, nowUtc, c.FlickerCount, c.PeakVolume, c.Volume, c.Position, c.AdjustedDepthImbalance, volRegime);
            c.SpoofSuspicionScore = ComputeSpoofSuspicion(c.FirstSeenUtc, nowUtc, c.FlickerCount, c.PeakVolume, c.Volume, c.AdjustedDepthImbalance, false);
            c.LiquidityQualityScore = ComputeLiquidityQuality(c.CredibilityScore, c.SpoofSuspicionScore, c.AdjustedDepthImbalance);
        }

        private DomBrick PromoteCandidateUnsafe(BrickCandidate c, DateTime nowUtc)
        {
            DomBrick b = new DomBrick();
            b.Price = c.Price;
            b.IsBid = c.IsBid;
            b.Volume = c.Volume;
            b.PeakVolume = c.PeakVolume;
            b.Position = c.Position;
            b.StartBar = c.StartBar;
            b.LastSeenBar = CurrentBar;
            b.FirstSeenUtc = c.FirstSeenUtc;
            b.LastSeenUtc = nowUtc;
            b.Active = true;
            b.SampleCount = Math.Max(1, c.SampleCount);
            b.FlickerCount = c.FlickerCount;
            b.CurrentDepthImbalance = c.CurrentDepthImbalance;
            b.AdjustedDepthImbalance = c.AdjustedDepthImbalance;
            b.CredibilityScore = c.CredibilityScore;
            b.SpoofSuspicionScore = c.SpoofSuspicionScore;
            b.LiquidityQualityScore = c.LiquidityQualityScore;
            b.VolatilityRegime = GetVolatilityRegime();
            b.LastDistanceTicks = GetDistanceTicks(c.Price);
            b.IsSpoofing = b.SpoofSuspicionScore > MaxSpoofSuspicionPercent / 100.0;
            UpdateMagnetState(b, c.Volume);
            confirmed.Add(b);
            return b;
        }

        private void UpdateBrickUnsafe(DomBrick b, long volume, int position, DateTime nowUtc)
        {
            bool fast = (nowUtc - b.LastSeenUtc).TotalMilliseconds <= 500.0;
            bool volumeFlicker = b.Volume > 0 && Math.Abs(volume - b.Volume) / (double)Math.Max(1, b.Volume) >= 0.25;
            bool positionFlicker = Math.Abs(position - b.Position) >= 2;
            if (fast && (volumeFlicker || positionFlicker)) b.FlickerCount++;
            b.LastSeenBar = CurrentBar;
            b.LastSeenUtc = nowUtc;
            b.Active = true;
            b.PeakVolume = Math.Max(b.PeakVolume, volume);
            b.SampleCount = Math.Max(1, b.SampleCount + 1);
            b.Volume = (long)Math.Max(1, (b.Volume * (b.SampleCount - 1) + volume) / (double)b.SampleCount);
            b.Position = position;
            b.CurrentDepthImbalance = ComputeDepthImbalanceUnsafe(DepthImbalanceLevels);
            b.AdjustedDepthImbalance = GetAdjustedDi(b.IsBid, b.CurrentDepthImbalance);
            b.VolatilityRegime = GetVolatilityRegime();
            b.CredibilityScore = ComputeCredibility(b.FirstSeenUtc, nowUtc, b.FlickerCount, b.PeakVolume, volume, b.Position, b.AdjustedDepthImbalance, b.VolatilityRegime);
            b.SpoofSuspicionScore = ComputeSpoofSuspicion(b.FirstSeenUtc, nowUtc, b.FlickerCount, b.PeakVolume, volume, b.AdjustedDepthImbalance, false);
            b.LiquidityQualityScore = ComputeLiquidityQuality(b.CredibilityScore, b.SpoofSuspicionScore, b.AdjustedDepthImbalance);
            b.IsSpoofing = b.SpoofSuspicionScore > MaxSpoofSuspicionPercent / 100.0;
            UpdateMagnetState(b, volume);
        }

        private void PenalizeCandidateUnsafe(string key, long volume, DateTime nowUtc, bool removed)
        {
            BrickCandidate c;
            if (!candidates.TryGetValue(key, out c) || c == null) return;
            c.FlickerCount++;
            c.LastSeenUtc = nowUtc;
            c.CurrentDepthImbalance = ComputeDepthImbalanceUnsafe(DepthImbalanceLevels);
            c.AdjustedDepthImbalance = GetAdjustedDi(c.IsBid, c.CurrentDepthImbalance);
            c.SpoofSuspicionScore = ComputeSpoofSuspicion(c.FirstSeenUtc, nowUtc, c.FlickerCount, c.PeakVolume, Math.Max(0, volume), c.AdjustedDepthImbalance, removed);
            c.CredibilityScore *= removed ? 0.35 : 0.70;
            if (removed || c.SpoofSuspicionScore > MaxSpoofSuspicionPercent / 100.0 || c.CredibilityScore < 0.05)
            {
                candidates.Remove(key);
                DebugPrint("REJECT " + FormatState(c.Price, c.IsBid, c.Volume, c.Position, c.CredibilityScore, c.SpoofSuspicionScore, c.AdjustedDepthImbalance));
            }
        }

        private void DeactivateBrickUnsafe(string key, long volume, DateTime nowUtc, bool removed)
        {
            DomBrick b;
            if (!active.TryGetValue(key, out b) || b == null) return;
            b.FlickerCount++;
            b.Active = false;
            b.LastSeenBar = CurrentBar;
            b.LastSeenUtc = nowUtc;
            b.CurrentDepthImbalance = ComputeDepthImbalanceUnsafe(DepthImbalanceLevels);
            b.AdjustedDepthImbalance = GetAdjustedDi(b.IsBid, b.CurrentDepthImbalance);
            b.SpoofSuspicionScore = ComputeSpoofSuspicion(b.FirstSeenUtc, nowUtc, b.FlickerCount, b.PeakVolume, Math.Max(0, volume), b.AdjustedDepthImbalance, removed);
            b.CredibilityScore *= removed ? 0.40 : 0.75;
            b.IsMagnet = false;
            b.IsSpoofing = b.SpoofSuspicionScore > MaxSpoofSuspicionPercent / 100.0;
            if (removed) active.Remove(key);
        }

        private void DrawCandidateWall(ChartControl chartControl, ChartScale chartScale, BrickCandidate c, float visibleLeft, float visibleRight)
        {
            int startBar = ClampInt(c.StartBar, 0, Bars.Count - 1);
            float x1 = Math.Max(chartControl.GetXByBarIndex(ChartBars, startBar), visibleLeft);
            float x2 = Math.Min(visibleRight, chartControl.GetXByBarIndex(ChartBars, Math.Min(Bars.Count - 1, CurrentBar)));
            if (x2 <= x1 + 1f) x2 = Math.Min(visibleRight, x1 + Math.Max(18f, ChartPanel.W * 0.035f));
            DrawWallRect(chartScale, c.Price, x1, x2, c.IsBid, false, c.Volume, c.CredibilityScore, c.AdjustedDepthImbalance, c.LiquidityQualityScore, CandidateOpacity, false, 1);
        }

        private void DrawConfirmedWall(ChartControl chartControl, ChartScale chartScale, DomBrick b, float visibleLeft, float visibleRight)
        {
            int startBar = ClampInt(b.StartBar, 0, Bars.Count - 1);
            int endBar = ClampInt(Math.Max(b.LastSeenBar, b.StartBar), 0, Bars.Count - 1);
            float x1 = Math.Max(chartControl.GetXByBarIndex(ChartBars, startBar), visibleLeft);
            float x2 = (ProjectMagnetsToMargin && b.IsMagnet) ? visibleRight : chartControl.GetXByBarIndex(ChartBars, endBar);
            if (b.Active && !b.IsMagnet) x2 = Math.Max(x2, chartControl.GetXByBarIndex(ChartBars, Math.Min(Bars.Count - 1, CurrentBar)));
            x2 = Math.Min(x2, visibleRight);
            if (x2 <= x1 + 1f) return;
            DrawWallRect(chartScale, b.Price, x1, x2, b.IsBid, b.IsMagnet, b.Volume, b.CredibilityScore, b.AdjustedDepthImbalance, b.LiquidityQualityScore, ConfirmedOpacity, false, 1);
        }

        private void DrawLongRangeZone(ChartScale chartScale, LiquidityZone z, float visibleLeft, float visibleRight)
        {
            float x1 = Math.Max(visibleLeft, visibleRight - Math.Max(180f, ChartPanel.W * 0.38f));
            float x2 = visibleRight;
            int opacity = (int)Math.Round(LongRangeOpacity * (0.35 + 0.65 * z.MemoryScore));
            DrawZoneRect(chartScale, z, x1, x2, opacity);
        }

        private bool TryGetShortTermTrendForRender(out int trendDirection)
        {
            trendDirection = 0;
            if (!UseTrendAdjustment || Bars == null || Close == null || CurrentBar < 1 || Bars.Count <= 1) return false;

            int lastBarIndex = Math.Min(CurrentBar, Bars.Count - 1);
            int lookback = Math.Max(1, Math.Min(20, TrendLookbackBars));
            if (lastBarIndex < lookback) return false;

            int priorBarIndex = lastBarIndex - lookback;
            if (priorBarIndex < 0 || priorBarIndex >= Bars.Count || lastBarIndex >= Bars.Count) return false;

            double currentClose = Close.GetValueAt(lastBarIndex);
            double priorClose = Close.GetValueAt(priorBarIndex);
            if (double.IsNaN(currentClose) || double.IsInfinity(currentClose) || double.IsNaN(priorClose) || double.IsInfinity(priorClose)) return false;

            if (currentClose > priorClose) trendDirection = 1;
            else if (currentClose < priorClose) trendDirection = -1;
            return trendDirection != 0;
        }

        private void DrawWallRect(ChartScale chartScale, double price, float x1, float x2, bool isBid, bool isMagnet, long volume, double score, double adjustedDi, double quality, int opacity, bool spoofRisk, int heightTicks)
        {
            if (chartScale == null || RenderTarget == null || ChartPanel == null || TickSize <= 0) return;

            float y = chartScale.GetYByValue(price);
            if (y < ChartPanel.Y - 40 || y > ChartPanel.Y + ChartPanel.H + 40) return;

            float tickHeight = Math.Abs(chartScale.GetYByValue(price) - chartScale.GetYByValue(price + TickSize));
            float h = Math.Max(2f, Math.Max(heightTicks, 1) * Math.Max(1f, tickHeight));
            float alpha = (float)Clamp01((opacity / 100.0) * (0.35 + 0.65 * quality));

            int trendDirection;
            bool hasTrend = TryGetShortTermTrendForRender(out trendDirection);
            bool absorptionOverride = false;

            double rawDi = isBid ? adjustedDi : -adjustedDi;
            int pressureDirection = rawDi > 0.0 ? 1 : (rawDi < 0.0 ? -1 : 0);

            if (hasTrend && rawDi > 0.0 && trendDirection < 0)
            {
                absorptionOverride = true;
                pressureDirection = -1;
            }
            else if (hasTrend && rawDi < 0.0 && trendDirection > 0)
            {
                absorptionOverride = true;
                pressureDirection = 1;
            }

            bool sideIsAggressive = pressureDirection == 0 || (pressureDirection > 0 && isBid) || (pressureDirection < 0 && !isBid);
            DxColor color;

            if (!sideIsAggressive)
            {
                color = new DxColor(0.42f, 0.45f, 0.48f, alpha * 0.62f);
            }
            else if (absorptionOverride && pressureDirection < 0)
            {
                color = new DxColor(1.00f, 0.25f, 0.00f, alpha);
            }
            else if (absorptionOverride && pressureDirection > 0)
            {
                color = new DxColor(0.00f, 0.75f, 0.75f, alpha);
            }
            else
            {
                color = isBid ? new DxColor(0.00f, 0.78f, 0.22f, alpha) : new DxColor(0.92f, 0.08f, 0.15f, alpha);
            }

            using (DxSolidColorBrush fill = new DxSolidColorBrush(RenderTarget, color))
            {
                DxRect r = new DxRect(x1, y - h * 0.5f, Math.Max(1f, x2 - x1), h);
                RenderTarget.FillRectangle(r, fill);

                DxBrush outline = isMagnet ? magnetBrush : (spoofRisk ? spoofBrush : (sideIsAggressive ? (isBid ? bidLineBrush : askLineBrush) : mutedBrush));
                if (outline != null) RenderTarget.DrawRectangle(r, outline, isMagnet ? 2.4f : 1.0f);

                if (ShowLabels && r.Width >= 48f)
                {
                    string label = absorptionOverride && sideIsAggressive
                        ? Math.Abs(rawDi * 100.0).ToString("0", CultureInfo.InvariantCulture) + "% ABS"
                        : FormatVol(volume);

                    if (!absorptionOverride && sideIsAggressive && r.Width >= 90f)
                        label += " C" + (score * 100.0).ToString("0", CultureInfo.InvariantCulture) + " D" + adjustedDi.ToString("0.00", CultureInfo.InvariantCulture);

                    DrawText(label, new DxRect(r.Left + 2f, r.Top, Math.Min(150f, r.Width - 4f), r.Height), fontTiny, textBrush, TextAlignment.Leading);
                }
            }
        }
        private void DrawZoneRect(ChartScale chartScale, LiquidityZone z, float x1, float x2, int opacity)
        {
            float y1 = chartScale.GetYByValue(z.ZoneHigh);
            float y2 = chartScale.GetYByValue(z.ZoneLow);
            float top = Math.Min(y1, y2);
            float bot = Math.Max(y1, y2);
            float minH = Math.Max(3f, ZoneHeightTicks * Math.Abs(chartScale.GetYByValue(z.CenterPrice) - chartScale.GetYByValue(z.CenterPrice + TickSize)));
            if (bot - top < minH)
            {
                float mid = chartScale.GetYByValue(z.CenterPrice);
                top = mid - minH * 0.5f;
                bot = mid + minH * 0.5f;
            }
            if (bot < ChartPanel.Y - 40 || top > ChartPanel.Y + ChartPanel.H + 40) return;
            float alpha = (float)Clamp01(opacity / 100.0);
            DxColor color = z.IsBid ? new DxColor(0.00f, 0.52f, 0.18f, alpha) : new DxColor(0.72f, 0.03f, 0.10f, alpha);
            using (DxSolidColorBrush fill = new DxSolidColorBrush(RenderTarget, color))
            {
                DxRect r = new DxRect(x1, top, Math.Max(1f, x2 - x1), Math.Max(2f, bot - top));
                RenderTarget.FillRectangle(r, fill);
                DxBrush outline = z.SpoofRisk > 0.62 ? spoofBrush : (z.IsBid ? bidLineBrush : askLineBrush);
                if (outline != null) RenderTarget.DrawRectangle(r, outline, z.SpoofRisk > 0.62 ? 1.8f : 1.0f);
                if (ShowLabels && r.Width >= 90f)
                {
                    string side = z.IsBid ? "LR BID " : "LR ASK ";
                    string label = side + z.CenterPrice.ToString("0.00", CultureInfo.InvariantCulture) + " M" + (z.MemoryScore * 100.0).ToString("0", CultureInfo.InvariantCulture) + " S" + (z.SpoofRisk * 100.0).ToString("0", CultureInfo.InvariantCulture) + " Seen" + z.AppearanceCount.ToString(CultureInfo.InvariantCulture);
                    DrawText(label, new DxRect(r.Left + 4f, r.Top, Math.Min(260f, r.Width - 8f), r.Height), fontTiny, textBrush, TextAlignment.Leading);
                }
            }
        }


        private void UpdateHMHeatmapUnsafe(double price, long volume, int position, bool isBid, bool remove, DateTime nowUtc)
        {
            string key = GetHMHeatmapKey(price, isBid);
            HMHeatmapCell cell = null;
            bool exists = hmActiveCells != null && hmActiveCells.TryGetValue(key, out cell) && cell != null;
            bool priceTouched = HMHasPriceTouchedLevel(price, isBid);
            bool explicitRemove = remove || volume <= 0;
            bool inferredFill = explicitRemove && (exists && cell != null ? cell.PriceTouched || priceTouched : priceTouched);
            if (explicitRemove)
            {
                if (exists)
                {
                    cell.Active = false;
                    cell.EndBar = CurrentBar;
                    cell.LastSeenUtc = nowUtc;
                    cell.ClosedUtc = nowUtc;
                    cell.PriceTouched = cell.PriceTouched || priceTouched;
                    cell.InferredFilled = inferredFill;
                    cell.ExplicitlyRemoved = !inferredFill;
                    cell.HighProbabilityScore = ComputeHMCellHighProbability(cell);
                    hmActiveCells.Remove(key);
                }
                return;
            }
            if (volume < HeatmapTriggerSize && !exists) return;
            double zoneCenter = GetHMHeatmapZoneCenter(price);
            double di = ComputeDepthImbalanceUnsafe(DepthImbalanceLevels);
            double adjustedDi = isBid ? di : -di;
            LiquidityZone zone = GetHMLongZone(zoneCenter, isBid);
            double memory = zone == null ? 0.0 : zone.MemoryScore;
            double spoof = zone == null ? 0.0 : zone.SpoofRisk;
            double zoneHp = zone == null ? 0.0 : zone.HighProbabilityScore;
            double intensity = ComputeHMHeatmapIntensity(volume, adjustedDi, memory, spoof, position, zoneHp);
            if (!exists)
            {
                cell = new HMHeatmapCell();
                cell.Price = price;
                cell.ZoneCenter = zoneCenter;
                cell.IsBid = isBid;
                cell.StartBar = CurrentBar;
                cell.EndBar = CurrentBar;
                cell.FirstSeenUtc = nowUtc;
                cell.PeakVolume = volume;
                cell.Active = true;
                cell.PriceTouched = priceTouched;
                if (hmActiveCells == null) hmActiveCells = new Dictionary<string, HMHeatmapCell>();
                if (hmAllCells == null) hmAllCells = new List<HMHeatmapCell>();
                hmActiveCells[key] = cell;
                hmAllCells.Add(cell);
            }
            cell.Volume = volume;
            cell.PeakVolume = Math.Max(cell.PeakVolume, volume);
            cell.EndBar = CurrentBar;
            cell.LastSeenUtc = nowUtc;
            cell.UpdateCount++;
            cell.PriceTouched = cell.PriceTouched || priceTouched;
            cell.Intensity = Math.Max(cell.Intensity * 0.88, intensity);
            cell.MemoryScore = Math.Max(memory, zoneHp * 0.70);
            cell.SpoofRisk = spoof;
            cell.HighProbabilityScore = ComputeHMCellHighProbability(cell);
        }
        private double ComputeHMHeatmapIntensity(long volume, double adjustedDi, double memory, double spoof, int position, double zoneHp)
        {
            double volumeNorm = Clamp01(volume / (double)Math.Max(1, HeatmapTriggerSize * 5));
            double alignment = Clamp01((adjustedDi + 1.0) * 0.5);
            double queue = Clamp01(1.0 - position / 14.0);
            return Clamp01(0.44 * volumeNorm + 0.14 * alignment + 0.18 * memory + 0.14 * queue + 0.16 * zoneHp - 0.30 * spoof);
        }
        private double ComputeHMCellHighProbability(HMHeatmapCell c)
        {
            if (c == null) return 0.0;
            int lifeBars = Math.Max(0, c.EndBar - c.StartBar);
            double peakScore = Clamp01(c.PeakVolume / (double)Math.Max(1, HeatmapTriggerSize * PeakVolumeMultiplier));
            double persistenceScore = Clamp01(lifeBars / 10.0);
            double updateScore = Clamp01(c.UpdateCount / 10.0);
            double fillScore = c.InferredFilled ? 1.0 : (c.PriceTouched ? 0.45 : 0.0);
            double statePenalty = c.ExplicitlyRemoved && !c.PriceTouched ? 0.18 : 0.0;
            return Clamp01(0.34 * c.Intensity + 0.22 * peakScore + 0.16 * persistenceScore + 0.10 * updateScore + 0.16 * c.MemoryScore + 0.08 * fillScore - 0.30 * c.SpoofRisk - statePenalty);
        }
        private double ComputeHMLongZoneHighProbability(LiquidityZone z, DateTime nowUtc)
        {
            if (z == null) return 0.0;
            double ageMin = Math.Max(0.01, (nowUtc - z.FirstSeenUtc).TotalMinutes);
            double recentMin = Math.Max(0.01, (nowUtc - z.LastSeenUtc).TotalMinutes);
            double peakVolumeScore = Clamp01(z.PeakVolume / (double)Math.Max(1, LongRangeTriggerSize * 4));
            double persistenceScore = Clamp01(Math.Log(1.0 + ageMin) / Math.Log(1.0 + Math.Max(5, MemoryWindowMinutes)));
            double reappearanceScore = Clamp01(z.AppearanceCount / 8.0);
            double executionScore = Clamp01(0.55 * z.ExecutionConfirmation + 0.25 * (z.TouchCount / (double)Math.Max(1, z.AppearanceCount)) + 0.20 * (z.ReactionCount / (double)Math.Max(1, z.TouchCount)));
            double d = GetDistanceTicks(z.CenterPrice);
            double mid = (LongRangeMinDistanceTicks + LongRangeMaxDistanceTicks) * 0.5;
            double distanceScore = Clamp01(1.0 - Math.Abs(d - mid) / Math.Max(1.0, LongRangeMaxDistanceTicks - LongRangeMinDistanceTicks));
            double di = ComputeDepthImbalanceUnsafe(DepthImbalanceLevels);
            double adjustedDi = z.IsBid ? di : -di;
            double bookAlignmentScore = Clamp01((adjustedDi + 1.0) * 0.5);
            double pullPenalty = z.AppearanceCount <= 0 ? 0.0 : Clamp01(z.PullBeforeTouchCount / (double)Math.Max(1, z.AppearanceCount));
            double cancelPenalty = Clamp01(z.CancellationCount / (double)Math.Max(1, z.AppearanceCount));
            double stalePenalty = Clamp01(recentMin / Math.Max(1.0, MemoryWindowMinutes));
            return Clamp01(0.32 * peakVolumeScore + 0.18 * persistenceScore + 0.16 * reappearanceScore + 0.14 * executionScore + 0.10 * distanceScore + 0.10 * bookAlignmentScore - 0.35 * z.SpoofRisk - 0.15 * pullPenalty - 0.10 * cancelPenalty - 0.10 * stalePenalty);
        }
        private HMLiquidityTier GetHMCellTier(HMHeatmapCell c)
        {
            if (c == null) return HMLiquidityTier.None;
            if (c.SpoofRisk > 0.60 && !c.InferredFilled) return HMLiquidityTier.None;
            if (c.PeakVolume < HeatmapTriggerSize * 1.35) return HMLiquidityTier.None;
            if (c.HighProbabilityScore >= CriticalThresholdPercent / 100.0 || c.PeakVolume >= HeatmapTriggerSize * PeakVolumeMultiplier) return HMLiquidityTier.Critical;
            if (c.HighProbabilityScore >= HighProbabilityThresholdPercent / 100.0 || c.Active) return HMLiquidityTier.HighProbability;
            return HMLiquidityTier.None;
        }
        private void DrawHMHeatmapCell(ChartControl chartControl, ChartScale chartScale, HMHeatmapCell c, int heatFrom, float visibleLeft, float visibleRight, HMLiquidityTier tier)
        {
            int startBar = ClampInt(Math.Max(c.StartBar, heatFrom), 0, Bars.Count - 1);
            int endBar = ClampInt(c.Active ? CurrentBar : Math.Max(c.EndBar, c.StartBar), 0, Bars.Count - 1);
            if (endBar < startBar) return;
            float x1 = Math.Max(visibleLeft, chartControl.GetXByBarIndex(ChartBars, startBar));
            float x2 = c.Active ? visibleRight : Math.Min(visibleRight, chartControl.GetXByBarIndex(ChartBars, endBar));
            if (x2 <= x1 + 1f) x2 = Math.Min(visibleRight, x1 + 2f);
            float y = chartScale.GetYByValue(c.ZoneCenter);
            if (y < ChartPanel.Y - 40f || y > ChartPanel.Y + ChartPanel.H + 40f) return;
            float tickHeight = Math.Abs(chartScale.GetYByValue(c.ZoneCenter) - chartScale.GetYByValue(c.ZoneCenter + TickSize));
            float h = Math.Max(2f, Math.Max(1, HeatmapCellHeightTicks) * Math.Max(1f, tickHeight));
            double ageFade = 1.0;
            if (HeatmapFadeOldCells && !c.Active)
            {
                int ageBars = Math.Max(0, CurrentBar - c.EndBar);
                ageFade = Clamp(1.0 - ageBars / (double)Math.Max(1, HeatmapLookbackBars), CompletedMinOpacityPercent / 100.0, 1.0);
            }
            double tierBoost = tier == HMLiquidityTier.Critical ? 1.35 : 1.18;
            double spoofFade = c.SpoofRisk >= SpoofRiskFadeThresholdPercent / 100.0 ? 0.46 : 1.0;
            float alpha = (float)Clamp01((HeatmapOpacity / 100.0) * Math.Max(c.Intensity, 0.10) * ageFade * spoofFade * tierBoost);
            if (alpha <= 0.01f) return;
            DxColor color = GetHMWallSizeColor(c.PeakVolume, HeatmapTriggerSize, alpha, tier);
            using (DxSolidColorBrush fill = new DxSolidColorBrush(RenderTarget, color))
            {
                DxRect r = new DxRect(x1, y - h * 0.5f, Math.Max(1f, x2 - x1), h);
                RenderTarget.FillRectangle(r, fill);
            }
        }
        private DxColor GetHMWallSizeColor(long peakVolume, int triggerSize, float alpha, HMLiquidityTier tier)
        {
            double ratio = peakVolume / (double)Math.Max(1, triggerSize);
            double strength = Clamp01((ratio - 1.0) / 4.0);
            float r = 1.00f;
            float g;
            float b;
            if (strength < 0.50)
            {
                double t = strength / 0.50;
                g = (float)(1.00 - 0.45 * t);
                b = (float)(0.10 - 0.06 * t);
            }
            else
            {
                double t = (strength - 0.50) / 0.50;
                g = (float)(0.55 - 0.50 * t);
                b = (float)(0.04 - 0.02 * t);
            }
            float a = (float)Clamp01(alpha * (0.58 + 0.42 * strength));
            if (tier == HMLiquidityTier.Critical) a = Math.Min(0.98f, a * 1.15f);
            return new DxColor(r, g, b, a);
        }
        private LiquidityZone GetHMLongZone(double zoneCenter, bool isBid)
        {
            LiquidityZone z;
            return longZones != null && longZones.TryGetValue(GetZoneKey(zoneCenter, isBid), out z) ? z : null;
        }
        private bool HMHasPriceTouchedLevel(double price, bool isBid)
        {
            if (TickSize <= 0 || CurrentBar < 0) return false;
            double tolerance = Math.Max(TickSize, HeatmapCompressionTicks * TickSize);
            if (isBid) return Low[0] <= price + tolerance;
            return High[0] >= price - tolerance;
        }
        private string GetHMHeatmapKey(double price, bool isBid) { return (isBid ? "HB:" : "HA:") + GetHMHeatmapZoneCenter(price).ToString(CultureInfo.InvariantCulture); }
        private double GetHMHeatmapZoneCenter(double price)
        {
            double zoneSize = Math.Max(TickSize, HeatmapCompressionTicks * TickSize);
            return Math.Round(price / zoneSize, 0, MidpointRounding.AwayFromZero) * zoneSize;
        }
        private void TrimHMHeatmapUnsafe()
        {
            if (hmAllCells == null) return;
            int minBar = CurrentBar - Math.Max(20, HeatmapLookbackBars + 50);
            for (int i = hmAllCells.Count - 1; i >= 0; i--)
            {
                HMHeatmapCell c = hmAllCells[i];
                if (c == null || (!c.Active && c.EndBar < minBar)) hmAllCells.RemoveAt(i);
            }
            while (hmAllCells.Count > HeatmapMaxCells)
            {
                int removeIndex = FindHMLowestPriorityRemovableCellIndex();
                if (removeIndex < 0) removeIndex = 0;
                hmAllCells.RemoveAt(removeIndex);
            }
        }
        private int FindHMLowestPriorityRemovableCellIndex()
        {
            int idx = -1;
            double best = double.MaxValue;
            int protectedBar = CurrentBar - Math.Max(20, HeatmapLookbackBars / 4);
            for (int i = 0; i < hmAllCells.Count; i++)
            {
                HMHeatmapCell c = hmAllCells[i];
                if (c == null || c.Active || c.InferredFilled) continue;
                if (c.EndBar >= protectedBar) continue;
                if (c.HighProbabilityScore >= CriticalThresholdPercent / 100.0) continue;
                double s = c.HighProbabilityScore;
                if (s < best)
                {
                    best = s;
                    idx = i;
                }
            }
            return idx;
        }
        private void DrawInfoPanel(int confirmedCount, int candidateCount, int longCount, double di)
        {
            string line = "DOM OrderFlow V1 [" + InstrumentPreset.ToString() + "]  Walls: " + confirmedCount.ToString(CultureInfo.InvariantCulture) + "  Cand: " + candidateCount.ToString(CultureInfo.InvariantCulture) + "  LR: " + longCount.ToString(CultureInfo.InvariantCulture) + "  DI(" + DepthImbalanceLevels.ToString(CultureInfo.InvariantCulture) + "): " + di.ToString("0.00", CultureInfo.InvariantCulture);
            DxRect r = new DxRect(ChartPanel.X + 12f, ChartPanel.Y + 12f, Math.Min(680f, ChartPanel.W - 24f), 24f);
            if (panelBrush != null) RenderTarget.FillRectangle(r, panelBrush);
            if (borderBrush != null) RenderTarget.DrawRectangle(r, borderBrush, 1f);
            DrawText(line, new DxRect(r.Left + 8f, r.Top, r.Width - 16f, r.Height), fontTiny, mutedBrush, TextAlignment.Leading);
        }

        private double ComputeDepthImbalanceUnsafe(int levels)
        {
            int n = Math.Max(1, Math.Min(10, levels));
            long bid = SumTopLevelsUnsafe(bidBook, n);
            long ask = SumTopLevelsUnsafe(askBook, n);
            long total = bid + ask;
            return total <= 0 ? 0.0 : (bid - ask) / (double)total;
        }

        private long SumTopLevelsUnsafe(Dictionary<string, DomLevel> book, int levels)
        {
            if (book == null || book.Count == 0) return 0;
            long sum = 0;
            foreach (KeyValuePair<string, DomLevel> kv in book)
            {
                DomLevel s = kv.Value;
                if (s != null && s.Volume > 0 && s.Position >= 0 && s.Position < levels) sum += s.Volume;
            }
            return sum;
        }

        private double GetAdjustedDi(bool isBid, double di) { return isBid ? di : -di; }
        private double GetPresetFlickerDecay() { return InstrumentPreset == DOMBrickInstrumentPresetOrderFlowV1.NQ ? 0.26 : 0.34; }
        private double GetPresetVolatilityPenaltyWeight() { return InstrumentPreset == DOMBrickInstrumentPresetOrderFlowV1.NQ ? 0.16 : 0.22; }

        private double ComputeCredibility(DateTime firstSeenUtc, DateTime nowUtc, int flickerCount, long peakVolume, long currentVolume, int position, double adjustedDi, double volatilityRegime)
        {
            double ageMs = Math.Max(0.0, (nowUtc - firstSeenUtc).TotalMilliseconds);
            double persistenceNorm = Math.Max(250.0, InstitutionalPersistenceMs);
            double persistence = Clamp01(Math.Log(1.0 + ageMs / 250.0) / Math.Log(1.0 + persistenceNorm / 250.0));
            double retention = peakVolume <= 0 ? 1.0 : Clamp01(currentVolume / (double)Math.Max(1, peakVolume));
            double queue = 0.55 + 0.45 * Clamp01(1.0 - (Math.Max(0, position) / Math.Max(1.0, DomMaxPosition + 1.0)));
            double alignment = 0.50 + 0.50 * Clamp01((adjustedDi + 1.0) * 0.5);
            double flickerPenalty = Math.Exp(-GetPresetFlickerDecay() * Math.Max(0, flickerCount));
            double volPenalty = volatilityRegime <= 1.0 ? 1.0 : Clamp01(1.0 / Math.Sqrt(volatilityRegime));
            double volWeight = GetPresetVolatilityPenaltyWeight();
            return Clamp01(persistence * (0.55 + 0.45 * retention) * queue * alignment * flickerPenalty * ((1.0 - volWeight) + volWeight * volPenalty));
        }

        private double ComputeSpoofSuspicion(DateTime firstSeenUtc, DateTime nowUtc, int flickerCount, long peakVolume, long currentVolume, double adjustedDi, bool removed)
        {
            double ageSec = Math.Max(0.001, (nowUtc - firstSeenUtc).TotalSeconds);
            double flicker = Clamp01(flickerCount / (double)Math.Max(1, MaxFlickerCount));
            double retentionLoss = peakVolume <= 0 ? 0.0 : Clamp01(1.0 - currentVolume / (double)Math.Max(1, peakVolume));
            double shortLife = removed ? Clamp01(1.0 - ageSec / Math.Max(1.0, MinDurationSeconds)) : 0.0;
            double againstBook = Clamp01((-adjustedDi + 1.0) * 0.5);
            double removeBoost = removed ? 0.22 : 0.0;
            double nqTightener = InstrumentPreset == DOMBrickInstrumentPresetOrderFlowV1.NQ ? 0.03 : 0.00;
            return Clamp01(0.34 * flicker + 0.24 * retentionLoss + 0.18 * shortLife + 0.13 * againstBook + removeBoost + nqTightener);
        }

        private double ComputeLiquidityQuality(double credibility, double spoof, double adjustedDi)
        {
            double alignment = Clamp01((adjustedDi + 1.0) * 0.5);
            return Clamp01(0.55 * credibility + 0.25 * alignment + 0.20 * (1.0 - spoof));
        }

        private void UpdateMagnetState(DomBrick b, long latestVolume)
        {
            double distanceTicks = GetDistanceTicks(b.Price);
            bool priceApproaching = distanceTicks <= b.LastDistanceTicks;
            bool volumeNotFleeing = latestVolume >= Math.Max(1, (long)(b.PeakVolume * (VolumeRetentionPercent / 100.0)));
            double dynamicCredibility = MagnetCredibilityPercent / 100.0;
            if (b.VolatilityRegime > 1.25) dynamicCredibility = Math.Min(0.90, dynamicCredibility + 0.08);
            double minAdjustedDi = InstrumentPreset == DOMBrickInstrumentPresetOrderFlowV1.NQ ? -0.04 : -0.10;
            bool diAligned = b.AdjustedDepthImbalance >= minAdjustedDi;
            bool spoofOk = b.SpoofSuspicionScore <= Math.Min(0.65, MaxSpoofSuspicionPercent / 100.0);
            b.IsMagnet = b.Active && !b.IsSpoofing && b.CredibilityScore >= dynamicCredibility && distanceTicks <= Math.Max(1, MagnetDistanceTicks) && priceApproaching && volumeNotFleeing && diAligned && spoofOk;
            b.LastDistanceTicks = distanceTicks;
        }

        private double GetDistanceTicks(double price)
        {
            if (TickSize <= 0 || Close == null || Close.Count <= 0) return double.MaxValue;
            return Math.Abs(price - Close[0]) / TickSize;
        }

        private double GetVolatilityRegime()
        {
            if (Bars == null || CurrentBar < 20) return 1.0;
            double current = Math.Max(TickSize, High[0] - Low[0]);
            double sum = 0;
            int count = Math.Min(20, CurrentBar + 1);
            for (int i = 0; i < count; i++) sum += Math.Max(TickSize, High[i] - Low[i]);
            double avg = sum / Math.Max(1, count);
            return avg > 0 ? Clamp(current / avg, 0.50, 3.00) : 1.0;
        }

        private string GetZoneKey(double price, bool isBid)
        {
            return (isBid ? "LB:" : "LA:") + GetZoneCenter(price).ToString(CultureInfo.InvariantCulture);
        }

        private double GetZoneCenter(double price)
        {
            double zoneSize = Math.Max(TickSize, ZoneMergeTicks * TickSize);
            return Math.Round(price / zoneSize, 0, MidpointRounding.AwayFromZero) * zoneSize;
        }

        private void TrimWallsUnsafe()
        {
            int max = Math.Max(100, MaxStoredWalls);
            while (confirmed.Count > max) confirmed.RemoveAt(0);
        }

        private void TrimLongZonesUnsafe(DateTime nowUtc)
        {
            if (longZones.Count <= MaxLongRangeZones) return;
            List<string> remove = new List<string>();
            foreach (KeyValuePair<string, LiquidityZone> kv in longZones)
            {
                LiquidityZone z = kv.Value;
                if (z == null || (nowUtc - z.LastSeenUtc).TotalMinutes > MemoryWindowMinutes || z.MemoryScore < 0.05) remove.Add(kv.Key);
                if (longZones.Count - remove.Count <= MaxLongRangeZones) break;
            }
            for (int i = 0; i < remove.Count; i++) longZones.Remove(remove[i]);
        }

        private void CreateTextFormats()
        {
            DisposeTextFormats();
            if (dwFactory == null) dwFactory = new SharpDX.DirectWrite.Factory();
            fontTiny = new TextFormat(dwFactory, "Segoe UI", SharpDX.DirectWrite.FontWeight.Normal, SharpDX.DirectWrite.FontStyle.Normal, 10f);
        }

        private void DisposeTextFormats()
        {
            if (fontTiny != null) fontTiny.Dispose();
            fontTiny = null;
        }

        private void DisposeDx()
        {
            DisposeBrush(ref bidLineBrush); DisposeBrush(ref askLineBrush); DisposeBrush(ref magnetBrush); DisposeBrush(ref textBrush); DisposeBrush(ref mutedBrush); DisposeBrush(ref panelBrush); DisposeBrush(ref borderBrush); DisposeBrush(ref spoofBrush);
        }

        private void DisposeBrush(ref DxSolidColorBrush b)
        {
            if (b != null) b.Dispose();
            b = null;
        }

        private void DrawText(string text, DxRect rect, TextFormat format, DxBrush brush, TextAlignment align)
        {
            if (string.IsNullOrEmpty(text) || rect.Width <= 1 || rect.Height <= 1 || format == null || brush == null || RenderTarget == null || dwFactory == null) return;
            format.TextAlignment = align;
            format.ParagraphAlignment = ParagraphAlignment.Center;
            using (TextLayout layout = new TextLayout(dwFactory, text, format, Math.Max(1f, rect.Width), Math.Max(1f, rect.Height)))
                RenderTarget.DrawTextLayout(new Vector2(rect.Left, rect.Top), layout, brush);
        }

        private bool IsRemoveOperation(string op)
        {
            return !string.IsNullOrEmpty(op) && (op.Equals("Remove", StringComparison.OrdinalIgnoreCase) || op.Equals("Delete", StringComparison.OrdinalIgnoreCase));
        }

        private string GetKey(double price, bool isBid) { return (isBid ? "B:" : "A:") + price.ToString(CultureInfo.InvariantCulture); }

        private double RoundToTick(double price)
        {
            if (TickSize <= 0) return price;
            return Math.Round(price / TickSize, 0, MidpointRounding.AwayFromZero) * TickSize;
        }

        private int ClampInt(int v, int min, int max) { if (v < min) return min; if (v > max) return max; return v; }
        private double Clamp(double v, double min, double max) { if (v < min) return min; if (v > max) return max; return v; }
        private double Clamp01(double v) { return Clamp(v, 0.0, 1.0); }

        private string FormatVol(long v)
        {
            if (Math.Abs(v) >= 1000000) return (v / 1000000.0).ToString("0.0", CultureInfo.InvariantCulture) + "M";
            if (Math.Abs(v) >= 1000) return (v / 1000.0).ToString("0.0", CultureInfo.InvariantCulture) + "K";
            return v.ToString(CultureInfo.InvariantCulture);
        }

        private string FormatState(double price, bool isBid, long volume, int position, double credibility, double spoof, double adi)
        {
            return string.Format(CultureInfo.InvariantCulture, "{0} {1} vol={2} pos={3} C={4:0.00} S={5:0.00} ADI={6:0.00}", isBid ? "BID" : "ASK", price, volume, position, credibility, spoof, adi);
        }

        private void DebugPrint(string msg)
        {
            if (!DebugOutput) return;
            Print((CurrentBar >= 0 ? Time[0].ToString("yyyy-MM-dd HH:mm:ss.fff") : DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss.fff")) + " | DOMBrickStandaloneOrderFlowV1 | " + msg);
        }
    }
}


